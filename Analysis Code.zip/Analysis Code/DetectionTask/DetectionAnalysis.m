CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analysis Code\DetectionTask'; 
DataPath = 'D:\Brooke\Data\Detection Task\Cued Detection'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles
    
    i; 
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), 1); 
    NameAndDate = cell((NumDateFiles-2), 2); 
    
    for x = 3:NumDateFiles
        
        DateFile = MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
           
    %sort files in order of date 
        
    FirstComma = findstr(DateFilePath, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = findstr(DateFilePath, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = findstr(DateFilePath, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = DateFilePath(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates((x-2), 1) = DateNum; 
    
    DateCell = cellstr(DateNumString); 
    NameCell = cellstr(DateFile); 
    
    NameAndDate((x-2), 1) = DateCell; 
    NameAndDate((x-2), 2) = NameCell;
     
    end
   
    AscendDates = sort(Dates); 
    NumDates = length(Dates); 
    AscendFiles = cell(NumDates, 1); 
    
    for x = 1:NumDates 
        
        FindIt = find(Dates == AscendDates(x));
        AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
    end
    
    AscendFiles = char(AscendFiles);
    ItNums = zeros(NumDates, 1);
     cd(MouseFolderDataPath); 
    
    for x = 1:NumDates 
                  
        FirstChar = AscendFiles(x, 1); 
        SecondChar = AscendFiles(x, 2);
        IsNum = str2num(FirstChar);
        IsNumTwo = str2num(SecondChar);
        
        if isempty(IsNumTwo) == 0
            
            TwoDigits = strcat(FirstChar, SecondChar); 
            IsNum = str2num(TwoDigits); 
            
        end 

        if isempty(IsNum) == 0 
        
            if IsNum ~= x
                
                OldName = AscendFiles(x, :); 
                OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                AscendFiles(x, 1) = num2str(x); 
                RevisedName = AscendFiles(x, :);
                RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                movefile(OldNamePath, RevisedName);
            end 
        
        else 
            
        OldName = AscendFiles(x, :); 
        OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
        ItString = num2str(x); 
        NewName = strcat(ItString, AscendFiles(x, :));
        NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 
       
        movefile(OldNamePath, NewNamePath);            

        end
        
    end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = findstr(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRewards = single.empty(500000, 0); 
 AllLicks = single.empty(500000, 0); 
  AllTime = single.empty(500000, 0); 
 AllRZ = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
AllContrastLevel = single.empty(500000, 0);
AllFlashes = single.empty(500000, 0);
 
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(10*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 10*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,10*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimInfo = zeros(movnu, 10);   

for y = 1:movnu
    
    Stiminfo = fread(movfile, 10 ,'single',0,'ieee-be');  
    Info = Stiminfo';
    StimInfo(y, 1:10)= Info;
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end 


TotalDist = StimInfo(:, 1);
RandDist = StimInfo(:, 2); 
Stims = StimInfo(:, 3); 
Licks = StimInfo(:, 4); 
Rewards = StimInfo(:, 5);
LickTime = StimInfo(:, 6);
StimSize = StimInfo(:, 7); 
CueSide = StimInfo(:, 8);
Flashes = StimInfo(:, 9);
ContrastLevel = StimInfo(:, 10);

if x == StartIt
    
    AllDist(1:movnu) = TotalDist; 
    AllStims(1:movnu) = Stims;
    AllLicks(1:movnu) = Licks;
    AllReward(1:movnu) = Rewards;
    AllTime(1:movnu) = Timer;
    AllRZ(1:movnu) = LickTime;
    AllStimSizes(1:movnu) = StimSize;
    AllCueSide(1:movnu) = CueSide;
    AllContrastLevel(1:movnu) = ContrastLevel;
    AllFlashes(1:movnu) = Flashes;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
    
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims;    
    AllDist(StartFill: (StartFill+movnu) - 1) = TotalDist; 
    AllRewards(StartFill: (StartFill+movnu) - 1) = Rewards;   
    AllLicks(StartFill: (StartFill+movnu) - 1) = Licks;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
    AllRZ(StartFill: (StartFill+movnu) - 1) = LickTime;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllContrastLevel(StartFill: (StartFill+movnu) - 1) = ContrastLevel;
    AllFlashes(StartFill: (StartFill+movnu) - 1) = Flashes;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
CueSide = AllCueSide'; 
ContrastLevel = AllContrastLevel'; 
Flashes = AllFlashes'; 
LickTime = round(AllRZ)'; 
Stims = AllStims';
Licks = AllLicks';
Rewards = AllRewards';
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

%find deriv/change in value of licks 

derivLicks = diff(Licks); 
NumDiffLicks = length(derivLicks); 

DerivLicks  = abs(derivLicks); 
DerivLicks = [0; DerivLicks]; 
%Licks = DerivLicks; 


%finds occurences of  stimuli
StimNum = find((Stims(:, 1) ~= 0));   
NumStim = length(StimNum); 
AllStim = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        AllStim(i, 1) = StimNum(i);  

    else
        if StimNum(i)-StimNum(i-1) < 10
        AllStim(i, 1) = 0; 
    else 
        AllStim(i, 1) = StimNum(i);
    end 
    end 
end 

AllStim = nonzeros(AllStim);   
NumStim = length(AllStim); 



WasCued = find(CueSide > 0); 

if isempty(WasCued) == 1 %was not cued, separate by contrast versions
    
    NumContrasts = max(ContrastLevel);    
    
    FullContrast = zeros(NumStim, 1); 
    ContrastOne = zeros(NumStim, 1); 
    ContrastTwo = zeros(NumStim, 1);
    ContrastThree = zeros(NumStim, 1);
    ContrastFour = zeros(NumStim, 1);
    ContrastFive = zeros(NumStim, 1);
    ContrastSix = zeros(NumStim, 1);
    
    if NumContrasts > 6
        
        ContrastSeven = zeros(NumStim, 1);
        ContrastEight = zeros(NumStim, 1);
        NoContrast = zeros(NumStim, 1);
        
    end 
    
    for i = 2:NumStim
    
    StimIt = AllStim(i); 
    
    ContrastVersion = ContrastLevel(StimIt-10:StimIt); 
    Contrast = mode(ContrastVersion); 
    
    if Contrast == 0 
        
        FullContrast(i, 1) = StimIt; 
        
    end 
    
    if Contrast == 1
        
        ContrastOne(i, 1) = StimIt; 
        
    end 
        
    if Contrast == 2
        
        ContrastTwo(i, 1) = StimIt; 
        
    end
    
    if Contrast == 3
        
        ContrastThree(i, 1) = StimIt; 
        
    end
    
    if Contrast == 4
        
        ContrastFour(i, 1) = StimIt; 
        
    end
    
    if Contrast == 5
        
        ContrastFive(i, 1) = StimIt; 
        
    end
    
    if Contrast == 6
        
        ContrastSix(i, 1) = StimIt; 
        
    end
    
    if NumContrasts > 6 
        
        if Contrast == 7
        
        ContrastSeven(i, 1) = StimIt; 
        
        end
         
        if Contrast == 8
        
        ContrastEight(i, 1) = StimIt; 
        
        end
         
        if Contrast == 9
        
         NoContrast(i, 1) = StimIt; 
        
        end
        
        
    end 
    
    end
   
    FullContrast = nonzeros(FullContrast); 
    ContrastOne = nonzeros(ContrastOne); 
    ContrastTwo = nonzeros(ContrastTwo); 
    ContrastThree = nonzeros(ContrastThree); 
    ContrastFour =  nonzeros(ContrastFour); 
    ContrastFive = nonzeros(ContrastFive); 
    ContrastSix =  nonzeros(ContrastSix); 
    
    NumFullCon = length(FullContrast);  
    NumConOne = length(ContrastOne); 
    NumConTwo = length(ContrastTwo); 
    NumConThree = length(ContrastThree); 
    NumConFour = length(ContrastFour); 
    NumConFive = length(ContrastFive); 
    NumConSix = length(ContrastSix);
    
    AllHitRates = zeros(7, 1); 
    AllLatencies = zeros(7, 1);
    
     if NumContrasts > 6
         
        ContrastSeven =  nonzeros(ContrastSeven); 
        ContrastEight = nonzeros(ContrastEight); 
        NoContrast =  nonzeros(NoContrast); 
        
        NumConSeven = length(ContrastSeven); 
        NumConEight = length(ContrastEight); 
        NumNoCon = length(NoContrast); 
        
        AllHitRates = zeros(10, 1); 
        AllLatencies = zeros(10, 1); 
         
     end 
    
    
    FullConHits = zeros(NumFullCon, 1);
    FullConLatency = zeros(NumFullCon, 1);
    
    for i = 1:NumFullCon
        
        Stim = FullContrast(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            FullConHits(i, 1) = Stim;  
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            FullConLatency(i, 1) = Latency; 
        end        
    end 
    
    FullConHits = nonzeros(FullConHits); 
    NumFullConHits = length(FullConHits); 
    FullConHitRate = (NumFullConHits/NumFullCon)
    FullConLatency = nonzeros(FullConLatency); 
    FullConAvgLatency = mean(FullConLatency) 
    
    AllHitRates(1) = FullConHitRate; 
    AllLatencies(1) = FullConAvgLatency; 
    
    
    
    ConOneHits = zeros(NumConOne, 1); 
    ConOneLatency = zeros(NumConOne, 1);
    
    for i = 1:NumConOne
        
        Stim = ContrastOne(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConOneHits(i, 1) = Stim;   
            
             FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConOneLatency(i, 1) = Latency; 
        end        
    end 
    
    ConOneHits = nonzeros(ConOneHits); 
    NumConOneHits = length(ConOneHits); 
    ConOneHitRate = (NumConOneHits/NumConOne)
    ConOneLatency = nonzeros(ConOneLatency); 
    ConOneAvgLatency = mean(ConOneLatency)
    
     AllHitRates(2) = ConOneHitRate; 
    AllLatencies(2) = ConOneAvgLatency; 
    
    
    
    
    
    ConTwoHits = zeros(NumConTwo, 1);
    ConTwoLatency = zeros(NumConTwo, 1);
    
    for i = 1:NumConTwo
        
        Stim = ContrastTwo(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConTwoHits(i, 1) = Stim;  
            
             FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConTwoLatency(i, 1) = Latency;
        end        
    end 
    
    ConTwoHits = nonzeros(ConTwoHits); 
    NumConTwoHits = length(ConTwoHits); 
    ConTwoHitRate = (NumConTwoHits/NumConTwo)
    ConTwoLatency = nonzeros(ConTwoLatency); 
    ConTwoAvgLatency = mean(ConTwoLatency) 
    
    AllHitRates(3) = ConTwoHitRate; 
    AllLatencies(3) = ConTwoAvgLatency;
    
    
    
    ConThreeHits = zeros(NumConThree, 1); 
    ConThreeLatency = zeros(NumConThree, 1);
    
    for i = 1:NumConThree
        
        Stim = ContrastThree(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConThreeHits(i, 1) = Stim;    
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConThreeLatency(i, 1) = Latency;
        end        
    end 
    
    ConThreeHits = nonzeros(ConThreeHits); 
    NumConThreeHits = length(ConThreeHits); 
    ConThreeHitRate = (NumConThreeHits/NumConThree)
    ConThreeLatency = nonzeros(ConThreeLatency); 
    ConThreeAvgLatency = mean(ConThreeLatency) 
    
    AllHitRates(4) = ConThreeHitRate; 
    AllLatencies(4) = ConThreeAvgLatency;
    
    
    
    
    
    
    ConFourHits = zeros(NumConFour, 1);
    ConFourLatency = zeros(NumConFour, 1);
    
    for i = 1:NumConFour
        
        Stim = ContrastFour(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStimTime) == 1); 
        
        if isempty(Licked) == 0            
            ConFourHits(i, 1) = Stim;  
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConFourLatency(i, 1) = Latency;
        end        
    end 
    
    ConFourHits = nonzeros(ConFourHits); 
    NumConFourHits = length(ConFourHits); 
    ConFourHitRate = (NumConFourHits/NumConFour)
    ConFourLatency = nonzeros(ConFourLatency); 
    ConFourAvgLatency = mean(ConFourLatency)
    
     AllHitRates(5) = ConFourHitRate; 
    AllLatencies(5) = ConFourAvgLatency;
    
    
      
    
    
     ConFiveHits = zeros(NumConFive, 1); 
     ConFiveLatency = zeros(NumConFive, 1);
     
    for i = 1:NumConFive
        
        Stim = ContrastFive(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConFiveHits(i, 1) = Stim;   
            
             FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConFiveLatency(i, 1) = Latency;
        end        
    end 
    
    ConFiveHits = nonzeros(ConFiveHits); 
    NumConFiveHits = length(ConFiveHits); 
    ConFiveHitRate = (NumConFiveHits/NumConFive)
    ConFiveLatency = nonzeros(ConFiveLatency); 
    ConFiveAvgLatency = mean(ConFiveLatency) 
    
       AllHitRates(6) = ConFiveHitRate; 
    AllLatencies(6) = ConFiveAvgLatency;
    
    
    
    
    
    ConSixHits = zeros(NumConSix, 1); 
    ConSixLatency = zeros(NumConSix, 1);
    
    for i = 1:NumConSix
        
        Stim = ContrastSix(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConSixHits(i, 1) = Stim; 
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConSixLatency(i, 1) = Latency;
        end        
    end 
    
    ConSixHits = nonzeros(ConSixHits); 
    NumConSixHits = length(ConSixHits); 
    ConSixHitRate = (NumConSixHits/NumConSix)
    ConSixLatency = nonzeros(ConSixLatency); 
    ConSixAvgLatency = mean(ConSixLatency)
    
    AllHitRates(7) = ConSixHitRate; 
    AllLatencies(7) = ConSixAvgLatency;
    
    
    
    if NumContrasts > 6 
        
            
    ConSevenHits = zeros(NumConSeven, 1); 
    ConSevenLatency = zeros(NumConSeven, 1);
    
    for i = 1:NumConSeven
        
        Stim = ContrastSeven(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConSevenHits(i, 1) = Stim; 
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConSevenLatency(i, 1) = Latency;
        end        
    end 
    
    ConSevenHits = nonzeros(ConSevenHits); 
    NumConSevenHits = length(ConSevenHits); 
    ConSevenHitRate = (NumConSevenHits/NumConSeven)
    ConSevenLatency = nonzeros(ConSevenLatency); 
    ConSevenAvgLatency = mean(ConSevenLatency)
    
    AllHitRates(8) = ConSevenHitRate; 
    AllLatencies(8) = ConSevenAvgLatency;
        
        
              
                     
    ConEightHits = zeros(NumConEight, 1); 
    ConEightLatency = zeros(NumConEight, 1);
    
    for i = 1:NumConEight
     
        Stim = ContrastEight(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            ConEightHits(i, 1) = Stim; 
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            ConEightLatency(i, 1) = Latency;
        end        
    end 
    
    ConEightHits = nonzeros(ConEightHits); 
    NumConEightHits = length(ConEightHits); 
    ConEightHitRate = (NumConEightHits/NumConEight)
    ConEightLatency = nonzeros(ConEightLatency); 
    ConEightAvgLatency = mean(ConEightLatency)
    
    AllHitRates(9) = ConEightHitRate; 
    AllLatencies(9) = ConEightAvgLatency;  
    
    
    
        
    NoConHits = zeros(NumNoCon, 1); 
    NoConLatency = zeros(NumNoCon, 1);
    
    for i = 1:NumNoCon
        
        Stim = NoContrast(i); 
        StimTime = Timer(Stim); 
        EndStimTime = find(Timer >= StimTime + 0.8); %presentation time 
        EndStim = EndStimTime(1); 
        
        Licked = find(Licks(Stim:EndStim) == 1); 
        
        if isempty(Licked) == 0            
            NoConHits(i, 1) = Stim; 
            
            FirstLick = Licked(1); 
            FirstLickIt = (Stim + FirstLick) - 1; 
            LickTime = Timer(FirstLickIt); 
            
            Latency = LickTime - StimTime; 
            NoConLatency(i, 1) = Latency;
        end        
    end 
    
    NoConHits = nonzeros(NoConHits); 
    NumNoConHits = length(NoConHits); 
    NoConHitRate = (NumNoConHits/NumNoCon)
    NoConLatency = nonzeros(NoConLatency); 
    NoConAvgLatency = mean(NoConLatency)
    
    AllHitRates(10) = NoConHitRate; 
    AllLatencies(10) = NoConAvgLatency;
        
        
        
        
    end
    
    
    
    CurrentDir = pwd; 
    FindStart = findstr(CurrentDir, 'BH'); 
    SaveString = CurrentDir(FindStart:end); 
    MouseName = CurrentDir(FindStart:FindStart+4);
    Date = CurrentDir(FindStart+6:end);

    AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Detection Task';
    cd(AnalyzedPath);
    MousePath = strcat(AnalyzedPath, '\', MouseName); 

    if exist(MousePath, 'dir') == 0 

        mkdir('Detection Task', MouseName); 

    end 

    MousePath = strcat(AnalyzedPath, '\', MouseName); 
    DatePath = strcat(MousePath, '\', Date); 

    if exist(DatePath, 'dir') == 0 

        mkdir(MouseName, Date); 
    end 

    SavePath = strcat(AnalyzedPath, '\', SaveString); 
    cd(SavePath); 

    FindSeshNum = findstr(SavePath, '\'); 
    FindSeshNum = FindSeshNum(end); 
    SeshNumIt = FindSeshNum + 1; 
    SeshNum = strcat('Session', SavePath(SeshNumIt)); 

    
   AllHits = figure('name','Hit Rates for Each Contrast Level');  
   plot(AllHitRates); 
    
   Title = strcat(MouseName, '-', SeshNum, ':', 'Hit Rates for Each Contrast Level'); 
    title(Title);
    xlabel('Contrast Level'); 
    ylabel('Hit Rate');

    FigureSaveName = 'Contrast_Level_Hit_Rates.fig'; 
    savefig(gcf, FigureSaveName); 
    close(AllHits);
    
    
    
    AllContrastLatencies = figure('name','Lick Latencies for Each Contrast Level');  
   plot(AllLatencies); 
    
   Title = strcat(MouseName, '-', SeshNum, ':', 'Lick Latencies for Each Contrast Level'); 
    title(Title);
    xlabel('Contrast Level'); 
    ylabel('Lick Latency');

    FigureSaveName = 'Contrast_Level_Lick_Latencies.png'; 
    saveas(gcf, FigureSaveName); 
    close(AllContrastLatencies);
    
    
    
    
    StimIt =  AllStim(3); %iteration of each reward
    StimTime = round(Timer(StimIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  StimIt - ItBefore;   
     

     RevAnalysisSpan = 5; %seconds  % 2 iterations = 1 millisecond 
     FwdAnalysisSpan = 5; 
     RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;


     NumBlocks = 10; %10 blocks per 1000ms
     IterationsPerSpan = NumBlocks*ItPerMs; 
     RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;

     RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
     FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;

     StartSpan=   StimIt- (RevAnalysisLength);
     EndSpan = StimIt+ (FwdAnalysisLength);

     SpanLength = EndSpan - StartSpan; 


    %peristimulus and reward lick behavior for all vert 

    LicksinSpan = zeros(SpanLength, NumStim-2); 
    TimeofSpan = zeros(SpanLength,NumStim-2); 
    SpeedinSpan = zeros(SpanLength,NumStim-2); 

    for i = 2:NumStim-1 %ignore first and last trial 

        Stim = AllStim(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        LicksinSpan(:, i) = Licks((StartSpan+1):EndSpan);
        SpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(y, i) = TimeofSpan(y, i) - StimTime; 
        end 

        TimeofSpan(:, i) ;

    end

    LicksinSpan = LicksinSpan';  
    [r c] = size(LicksinSpan); 
    TimeofSpan = TimeofSpan';  
    SpeedinSpan = SpeedinSpan';
    
    
    
    
    %peristimulus and reward lick behavior for full contrast

    FullConLicks = zeros(NumFullCon, SpanLength);
    TimeofSpan = zeros(NumFullCon, SpanLength); 
    FullConSpeed = zeros(NumFullCon, SpanLength);

    for i = 1:NumFullCon %ignore first and last trial 

        Stim =FullContrast(i);  

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        FullConLicks(i, :) = Licks((StartSpan+1):EndSpan);
       FullConSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    
        
    %peristimulus and reward lick behavior for contrast one

    ConOneLicks = zeros(NumConOne, SpanLength);
    TimeofSpan = zeros(NumConOne, SpanLength); 
    ConOneSpeed = zeros(NumConOne, SpanLength);

    for i = 1:NumConOne %ignore first and last trial 

        Stim = ContrastOne(i);  

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConOneLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConOneSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    
        %peristimulus and reward lick behavior for contrast two

    ConTwoLicks = zeros(NumConTwo-1, SpanLength);
    TimeofSpan = zeros(NumConTwo-1, SpanLength); 
    ConTwoSpeed = zeros(NumConTwo-1, SpanLength);

    for i = 2:NumConTwo %ignore first and last trial 

        Stim = ContrastTwo(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConTwoLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConTwoSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
  
      
      %peristimulus and reward lick behavior for contrast three

    ConThreeLicks = zeros(NumConThree, SpanLength);
    TimeofSpan = zeros(NumConThree, SpanLength); 
    ConThreeSpeed = zeros(NumConThree, SpanLength);

    for i = 1:NumConThree %ignore first and last trial 

        Stim = ContrastThree(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConThreeLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConThreeSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    
    %peristimulus and reward lick behavior for contrast four

    ConFourLicks = zeros(NumConFour, SpanLength);
    TimeofSpan = zeros(NumConFour, SpanLength); 
    ConFourSpeed = zeros(NumConFour, SpanLength);

    for i = 1:NumConFour %ignore first and last trial 

        Stim = ContrastFour(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConFourLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConFourSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 
    end
    
   
          %peristimulus and reward lick behavior for contrast five

    ConFiveLicks = zeros(NumConFive, SpanLength);
    TimeofSpan = zeros(NumConFive, SpanLength); 
    ConFiveSpeed = zeros(NumConFive, SpanLength);

    for i = 1:NumConFive %ignore first and last trial 

        Stim = ContrastFive(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConFiveLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConFiveSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    
    %peristimulus and reward lick behavior for contrast six

    ConSixLicks = zeros(NumConSix, SpanLength);
    TimeofSpan = zeros(NumConSix, SpanLength); 
    ConSixSpeed = zeros(NumConSix, SpanLength);

    for i = 1:NumConSix %ignore first and last trial 

        Stim = ContrastSix(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConSixLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConSixSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    if NumContrasts > 6
    
        
     %peristimulus and reward lick behavior for contrast Seven

    ConSevenLicks = zeros(NumConSeven, SpanLength);
    TimeofSpan = zeros(NumConSeven, SpanLength); 
    ConSevenSpeed = zeros(NumConSeven, SpanLength);

    for i = 1:NumConSeven %ignore first and last trial 

        Stim = ContrastSeven(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConSevenLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConSevenSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    
         %peristimulus and reward lick behavior for contrast Eight

    ConEightLicks = zeros(NumConEight, SpanLength);
    TimeofSpan = zeros(NumConEight, SpanLength); 
    ConEightSpeed = zeros(NumConEight, SpanLength);

    for i = 1:NumConEight %ignore first and last trial 

        Stim = ContrastEight(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        ConEightLicks(i, :) = Licks((StartSpan+1):EndSpan);
        ConEightSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
         %peristimulus and reward lick behavior for contrast Seven

    NoConLicks = zeros(NumNoCon, SpanLength);
    TimeofSpan = zeros(NumNoCon, SpanLength); 
    NoConSpeed = zeros(NumNoCon, SpanLength);

    for i = 1:NumNoCon %ignore first and last trial 

        Stim = NoContrast(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        NoConLicks(i, :) = Licks((StartSpan+1):EndSpan);
        NoConSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
    
    end 
    
   
    x = TimeofSpan(2, :); 
    
    AvgFullConLicks = smooth(mean(FullConLicks)); 
     AvgConOneLicks = smooth(mean(ConOneLicks)); 
      AvgConTwoLicks = smooth(mean(ConTwoLicks));
      AvgConThreeLicks = smooth(mean(ConThreeLicks));
     AvgConFourLicks = smooth(mean(ConFourLicks));
    AvgConFiveLicks = smooth(mean(ConFiveLicks));
    AvgConSixLicks = smooth(mean(ConSixLicks));
    
  AvgLicksPerStim = figure('name','PeriStimulus Licking for Each Contrast');  
   plot(x, AvgFullConLicks, 'LineWidth',1);
   hold on; 
    plot(x, AvgConOneLicks, 'LineWidth',1);
    hold on; 
    plot(x, AvgConTwoLicks, 'LineWidth',1);
    hold on; 
    plot(x, AvgConThreeLicks, 'LineWidth',1);
    hold on; 
    plot(x, AvgConFourLicks, 'LineWidth',1);
    hold on; 
    plot(x, AvgConFiveLicks, 'LineWidth',1);
    hold on; 
    plot(x, AvgConSixLicks, 'LineWidth',1);
    hold on; 
    
    if NumContrasts > 6 
        
        AvgConSevenLicks = smooth(mean(ConSevenLicks));
        AvgConEightLicks = smooth(mean(ConEightLicks));
        AvgNoConLicks = smooth(mean(NoConLicks));
        
        plot(x, AvgConSevenLicks, 'LineWidth',1);
        hold on;
        
        plot(x, AvgConEightLicks, 'LineWidth',1);
        hold on;
        
        plot(x, AvgNoConLicks, 'LineWidth',1);
        hold on;
        
    end 
    
   Title = strcat(MouseName, '-', SeshNum, ':', 'PeriStimulus Licking for Each Contrast'); 
    title(Title);
    xlabel('Peristimulus Time'); 
    ylabel('Avg Licking');
    legend('Full Contrast', 'Contrast One', 'Contrast Two', 'Contrast Three', 'Contrast Four', 'Contrast Five', 'Contrast Six'); 
    
    if NumContrasts > 6 
        
        legend('Full Contrast', 'Contrast One', 'Contrast Two', 'Contrast Three', 'Contrast Four', 'Contrast Five', 'Contrast Six', 'Contrast Seven','Contrast Eight', 'No Contrast'); 
        
    end

    FigureSaveName = 'PeriStimulus_Licking_for_Each_Contrast.png'; 
    saveas(gcf, FigureSaveName); 
    close(AvgLicksPerStim);
    
    
    

    CurrentDir = pwd; 
    FindStart = findstr(CurrentDir, 'BH'); 
    SaveString = CurrentDir(FindStart:end); 
    MouseName = CurrentDir(FindStart:FindStart+4);
    Date = CurrentDir(FindStart+6:end);
% 
% 
%     MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName);     
% 
%     cd(MousePath); 
%     fileID = fopen('AllDPrime.txt','a');
%     formatSpec = '%s\n';
%     fprintf(fileID, formatSpec , Date);
%     dlmwrite('AllDPrime.txt',NoConHitRate, '-append');
%     dlmwrite('AllDPrime.txt',NoConAvgLatency, '-append');
%     dlmwrite('AllDPrime.txt',ConEightHitRate, '-append');
%     dlmwrite('AllDPrime.txt',ConEightAvgLatency, '-append');
%     dlmwrite('AllDPrime.txt',ConSevenHitRate, '-append');
%     dlmwrite('AllDPrime.txt',ConSevenAvgLatency,'-append');
%     dlmwrite('AllDPrime.txt',ConSixHitRate,'-append');
%     dlmwrite('AllDPrime.txt',ConSixAvgLatency, '-append');
%     fclose(fileID);

    
end 

%separate according to left or right cue or no cue side -- if cued version 


if isempty(WasCued) == 0

RightCued = zeros(NumStim, 1); 
LeftCued = zeros(NumStim, 1);
NotCued = zeros(NumStim, 1); 

for i = 1:NumStim
    
    StimIt = AllStim(i) ; 
    
    StimCueSide = CueSide(StimIt:StimIt+5); 
    StimCueSide = mode(StimCueSide); 
    
    if StimCueSide == 2 %left side 
        
        LeftCued(i, 1) = StimIt; 
        
    end 
        
    if StimCueSide == 1 %right side 
            
           RightCued(i, 1) = StimIt;
            
    end 
    
      if StimCueSide == 3 %right side 
            
           NotCued(i, 1) = StimIt;
            
    end 
end 

RightCued = nonzeros(RightCued); 
LeftCued = nonzeros(LeftCued); 
NotCued = nonzeros(NotCued); 

NumRCued = length(RightCued)
NumLCued = length(LeftCued)
NumNotCued = length(NotCued) 



%separate into contrast level -- place into one matrix 

    
    FullContrast = zeros(NumStim, 1); 
    ContrastOne = zeros(NumStim, 1); 
    ContrastTwo = zeros(NumStim, 1);
    ContrastThree = zeros(NumStim, 1);
    ContrastFour = zeros(NumStim, 1);
    ContrastFive = zeros(NumStim, 1);
    ContrastSix = zeros(NumStim, 1);        
    ContrastSeven = zeros(NumStim, 1);
    ContrastEight = zeros(NumStim, 1);
    NoContrast = zeros(NumStim, 1);
      

for i = 1: NumStim
    
   StimIt = AllStim(i);
   
    ContrastVersion = ContrastLevel(StimIt-10:StimIt); 
    Contrast = mode(ContrastVersion); 
    
        if Contrast == 0 
            FullContrast(i, 1) = StimIt; 
        end 

        if Contrast == 1
            ContrastOne(i, 1) = StimIt; 
        end 

        if Contrast == 2
            ContrastTwo(i, 1) = StimIt; 
        end

        if Contrast == 3
            ContrastThree(i, 1) = StimIt; 
        end

        if Contrast == 4
            ContrastFour(i, 1) = StimIt; 
        end

        if Contrast == 5
            ContrastFive(i, 1) = StimIt; 
        end

        if Contrast == 6
            ContrastSix(i, 1) = StimIt; 
        end
        
        if Contrast == 7       
        ContrastSeven(i, 1) = StimIt;        
        end
         
        if Contrast == 8      
        ContrastEight(i, 1) = StimIt;        
        end
         
        if Contrast == 9       
         NoContrast(i, 1) = StimIt;         
        end      
end 

    FullContrast = nonzeros(FullContrast); 
    ContrastOne = nonzeros(ContrastOne); 
    ContrastTwo = nonzeros(ContrastTwo); 
    ContrastThree = nonzeros(ContrastThree); 
    ContrastFour =  nonzeros(ContrastFour); 
    ContrastFive = nonzeros(ContrastFive); 
    ContrastSix =  nonzeros(ContrastSix); 
    ContrastSeven =  nonzeros(ContrastSeven); 
    ContrastEight = nonzeros(ContrastEight); 
    NoContrast =  nonzeros(NoContrast); 
    
     NumFullCon = length(FullContrast);  
    NumConOne = length(ContrastOne); 
    NumConTwo = length(ContrastTwo); 
    NumConThree = length(ContrastThree); 
    NumConFour = length(ContrastFour); 
    NumConFive = length(ContrastFive); 
    NumConSix = length(ContrastSix);
    NumConSeven = length(ContrastSeven); 
    NumConEight = length(ContrastEight); 
    NumNoCon = length(NoContrast); 
    
AllContrasts = [NumFullCon; NumConOne; NumConTwo; NumConThree; NumConFour; NumConFive; NumConSix; NumConSeven; NumConEight; NumNoCon];
MaxAllCon = max(AllContrasts); 
NumAllContrasts = length(nonzeros(AllContrasts)); 

StimByContrast = zeros(MaxAllCon, 10); 

StimByContrast(1:NumFullCon, 1)= FullContrast; 
StimByContrast(1:NumConOne, 2) = ContrastOne; 
StimByContrast(1:NumConTwo, 3) = ContrastTwo; 
StimByContrast(1:NumConThree, 4) = ContrastThree; 
StimByContrast(1:NumConFour, 5) = ContrastFour; 
StimByContrast(1:NumConFive, 6) = ContrastFive; 
StimByContrast(1:NumConSix, 7) = ContrastSix; 
StimByContrast(1:NumConSeven, 8) = ContrastSeven; 
StimByContrast(1:NumConEight, 9) = ContrastEight; 
StimByContrast(1:NumNoCon, 10) = NoContrast; 

%separate into right and left cued 

RightCuedHits = zeros(MaxAllCon, 10);
RightHitLatencies  = zeros(MaxAllCon, 10);
LeftCuedHits = zeros(MaxAllCon, 10);
LeftHitLatencies  = zeros(MaxAllCon, 10);
NotCuedHits = zeros(MaxAllCon, 10);
NotHitLatencies  = zeros(MaxAllCon, 10);

for i = 1:10 
    
    ContrastLevel = StimByContrast(:, i); 
    ContrastLevel = nonzeros(ContrastLevel);
    
    if isempty(ContrastLevel) == 0 
        
        NumStims = length(ContrastLevel); 
    
    for x = 1:NumStims
        
        StimIt = ContrastLevel(x, 1); 
        
        StimCueSide = CueSide(StimIt:StimIt+5); 
        StimCueSide = mode(StimCueSide); 

        if StimCueSide == 2 %left side 

             StimTime = Timer(StimIt); 
            EndWindowTime = StimTime + 0.5; 
            EndWindowIt = find(Timer <= EndWindowTime); 
            EndWindowIt = EndWindowIt(end); 

            Licked = find(Licks(StimIt:EndWindowIt) == 1); 

            if isempty(Licked) == 0

                LeftCuedHits(x, i) = StimIt; 

                FirstLick = Licked(1); 
                LickIt = (StimIt + FirstLick) - 1; 
                LickTime = Timer(LickIt); 

                LickLatency = LickTime - StimTime; 
                LeftHitLatencies(x, i) = LickLatency; 

            end   

        end 

        if StimCueSide == 1 %right side 

            StimTime = Timer(StimIt); 
            EndWindowTime = StimTime + 0.5; 
            EndWindowIt = find(Timer <= EndWindowTime); 
            EndWindowIt = EndWindowIt(end); 

            Licked = find(Licks(StimIt:EndWindowIt) == 1); 

            if isempty(Licked) == 0

                RightCuedHits(x, i) = StimIt; 

                FirstLick = Licked(1); 
                LickIt = (StimIt + FirstLick) - 1; 
                LickTime = Timer(LickIt); 

                LickLatency = LickTime - StimTime; 
                RightHitLatencies(x, i) = LickLatency; 

            end    

        end 

          if StimCueSide == 3 %right side 

            StimTime = Timer(StimIt); 
            EndWindowTime = StimTime + 0.5; 
            EndWindowIt = find(Timer <= EndWindowTime); 
            EndWindowIt = EndWindowIt(end); 

            Licked = find(Licks(StimIt:EndWindowIt) == 1); 

            if isempty(Licked) == 0

                NotCuedHits(x, i) = StimIt; 

                FirstLick = Licked(1); 
                LickIt = (StimIt + FirstLick) - 1; 
                LickTime = Timer(LickIt); 

                LickLatency = LickTime - StimTime; 
                NotHitLatencies(x, i) = LickLatency; 

            end    
          end 
    end 
    end 
end 

for i = 1:10 
    
     RCuedHits = nonzeros(RightCuedHits(:, i)); 
     RHitLatencies = nonzeros(RightHitLatencies(:, i)); 
     
      LCuedHits = nonzeros(LeftCuedHits(:, i)); 
     LHitLatencies = nonzeros(LeftHitLatencies(:, i)); 
     
     NoCuedHits = nonzeros(NotCuedHits(:, i)); 
     NoCuedHitLatencies = nonzeros(NotHitLatencies(:, i));
    
     if isempty(RCuedHits) == 0 
         
         if i == 9            
             RCuedConEightHits = RCuedHits;
             NumREightHits = length(RCuedConEightHits); 
             
             RCuedConEightLatencies = RHitLatencies;
             NumREightLatencies = length(RCuedConEightLatencies); 
             
             LCuedConEightHits = LCuedHits;
             NumLEightHits = length(LCuedConEightHits); 
             
             LCuedConEightLatencies = LHitLatencies;
             NumLEightLatencies = length(LCuedConEightLatencies); 
             
             NoCueConEightHits = NoCuedHits;
             NumNoEightHits = length(NoCueConEightHits); 
             
             NoCueConEightLatencies = NoCuedHitLatencies;
             NumNoEightLatencies = length(NoCueConEightLatencies); 
             
             ContrastUsed = 8; 
         end 
         
         if i == 8            
             RCuedConSevenHits = RCuedHits;
             NumRSevenHits = length(RCuedConSevenHits); 
             
             RCuedConSevenLatencies = RHitLatencies;
             NumRSevenLatencies = length(RCuedConSevenLatencies); 
             
             LCuedConSevenHits = LCuedHits;
             NumLSevenHits = length(LCuedConSevenHits); 
             
             LCuedConSevenLatencies = LHitLatencies;
             NumLSevenLatencies = length(LCuedConSevenLatencies); 
             
             NoCueConSevenHits = NoCuedHits;
             NumNoSevenHits = length(NoCueConSevenHits); 
             
             NoCueConSevenLatencies = NoCuedHitLatencies;
             NumNoSevenLatencies = length(NoCueConSevenLatencies); 
             
             ContrastUsed = 7; 
         end 
%          
%          if i == 7            
%              RCuedConSix = RCuedStims;  
%              NumRightSixHits = length(RCuedConSix); 
%          end
         
     end 
    
    
end 



Flashes = find(AllFlashes ~= 0); 
NumFlashes = length(Flashes); 
AllFakeCues = zeros(NumFlashes, 1); 

for i = 1:NumFlashes 
    
    if i == 1 
        AllFakeCues(i, 1) = Flashes(i);  

    else
        if Flashes(i)-Flashes(i-1) < 10
        AllFakeCues(i, 1) = 0; 
    else 
       AllFakeCues(i, 1) = Flashes(i);
    end 
    end 
end 

AllFakeCues = nonzeros(AllFakeCues);   
NumFlashes = length(AllFakeCues); 

RightFlashes = zeros(NumFlashes, 1);
LeftFlashes = zeros(NumFlashes, 1); 

for i = 1:NumFlashes 
    
    Flash = AllFakeCues(i); 
    FlashSide = AllFlashes(Flash:Flash+5); 
    
    if FlashSide == 1        
        RightFlashes(i, 1) = Flash;         
    end 
    
     if FlashSide == 2       
        LeftFlashes(i, 1) = Flash; 
     end 
    
end 

RightFlashes = nonzeros(RightFlashes); 
LeftFlashes = nonzeros(LeftFlashes); 
NumRFlashes = length(RightFlashes); 
NumLFlashes = length(LeftFlashes); 


  
    VertIt =  AllStim(3); %iteration of each reward
    StimTime = round(Timer(VertIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  VertIt - ItBefore;   
     

 RevAnalysisSpan = 3; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 3; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;

 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;
 
 StartSpan=   VertIt-RevAnalysisLength;
 EndSpan = VertIt+FwdAnalysisLength;
  
 SpanLength = EndSpan - StartSpan; 
 
 
 RFlashLicks = zeros(NumRFlashes, SpanLength);
LFlashLicks = zeros(NumLFlashes, SpanLength);
  
    for i = 2:NumRFlashes %ignore first and last trial 

        Stim = RightFlashes(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        RFlashLicks(i, :) = Licks((StartSpan+1):EndSpan);

    end
    
        for i = 2:NumLFlashes %ignore first and last trial 

        Stim = LeftFlashes(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        LFlashLicks(i, :) = Licks((StartSpan+1):EndSpan);

    end

AvgRFlashLicks = smooth(mean(RFlashLicks));
AvgLFlashLicks = smooth(mean(LFlashLicks));




    
    CurrentDir = pwd; 
    FindStart = findstr(CurrentDir, 'BH'); 
    SaveString = CurrentDir(FindStart:end); 
    MouseName = CurrentDir(FindStart:FindStart+4);
    Date = CurrentDir(FindStart+6:end);

    AnalyzedPath = strcat(CodePath, '\', 'Analyzed');
    cd(AnalyzedPath);
    MousePath = strcat(AnalyzedPath, '\', MouseName); 

    if exist(MousePath, 'dir') == 0 

        mkdir('Analyzed', MouseName); 

    end 

    MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
    DatePath = strcat(MousePath, '\', Date); 

    if exist(DatePath, 'dir') == 0 

        mkdir(MouseName, Date); 
    end 

    SavePath = strcat(CodePath, '\', 'Analyzed', '\', SaveString); 
    cd(SavePath); 

if exist('NumREightHits', 'var')

if NumREightHits > 0
    
    NumRCuedEight = 0; 
    NumLCuedEight = 0; 
    NumNotCuedEight = 0; 
    ContrastLevel = StimByContrast(:, 9); 
    ContrastLevel = nonzeros(ContrastLevel);
      
    NumStims = length(ContrastLevel); 
    RCuedEight = zeros(NumStims, 1); 
    LCuedEight = zeros(NumStims, 1); 
    NotCuedEight = zeros(NumStims, 1); 
    
    for i = 1:NumStims
        
        StimIt = ContrastLevel(i, 1); 
        
        StimCueSide = CueSide(StimIt:StimIt+5); 
        StimCueSide = mode(StimCueSide); 

        if StimCueSide == 1 %left side            
            NumRCuedEight = NumRCuedEight + 1;    
            RCuedEight(i, 1) = StimIt; 
        end 
        
         if StimCueSide == 2 %left side            
            NumLCuedEight = NumLCuedEight + 1;
            LCuedEight(i, 1) = StimIt; 
         end
        
         if StimCueSide == 3 %left side            
            NumNotCuedEight = NumNotCuedEight + 1;
            NotCuedEight(i, 1) = StimIt; 
         end    
         
         
        
    end   
    
    REightHitRate =  NumREightHits/NumRCuedEight 
    LEightHitRate =  NumLEightHits/NumLCuedEight 
    NoEightHitRate =  NumNoEightHits/NumNotCuedEight 
           
    RHitRate =  REightHitRate;  
    LHitRate =  LEightHitRate;   
    NoHitRate =  NoEightHitRate; 
    
    AvgREightHitTime = mean(RCuedConEightLatencies) * 1000
    AvgLEightHitTime = mean(LCuedConEightLatencies) * 1000
    AvgNoCueEightHitTime = mean(NoCueConEightLatencies) * 1000
    
      AvgRHitTime = AvgREightHitTime; 
    AvgLHitTime = AvgLEightHitTime; 
    AvgNoCueHitTime = AvgNoCueEightHitTime; 

    RCuedEightLicks = zeros(NumRCuedEight, SpanLength);
    LCuedEightLicks = zeros(NumLCuedEight, SpanLength);
    NotCuedEightLicks = zeros(NumNotCuedEight, SpanLength);
    
    TimeofSpan = zeros(NumRCuedEight, SpanLength); 
    
    RCuedEightSpeed = zeros(NumRCuedEight, SpanLength);
    LCuedEightSpeed = zeros(NumLCuedEight, SpanLength);
    NotCuedEightSpeed = zeros(NumNotCuedEight, SpanLength);
    
    RCuedEight = nonzeros(RCuedEight); 
    LCuedEight = nonzeros(LCuedEight); 
    NotCuedEight = nonzeros(NotCuedEight); 

    for i = 1:NumRCuedEight %ignore first and last trial 

        Stim = RCuedEight(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        RCuedEightLicks(i, :) = Licks((StartSpan+1):EndSpan);
        RCuedEightSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
       for i = 2:NumLCuedEight-1 %ignore first and last trial 

        Stim = LCuedEight(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        LCuedEightLicks(i, :) = Licks((StartSpan+1):EndSpan);
        LCuedEightSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
 
       end
       
        for i = 1:NumNotCuedEight %ignore first and last trial 

        Stim = NotCuedEight(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        NotCuedEightLicks(i, :) = Licks((StartSpan+1):EndSpan);
        NotCuedEightSpeed(i, :) = Velocity((StartSpan+1):EndSpan);


        end
       
    AvgRCuedEightLicks = smooth(mean(RCuedEightLicks));
    AvgLCuedEightLicks = smooth(mean(LCuedEightLicks));
    AvgNotCuedEightLicks = smooth(mean(NotCuedEightLicks));
    
    Version = 'Eight'; 
    AvgLicksPerStim = figure('name','PeriStimulus Licking for Each Contrast');    
    x = TimeofSpan(2, :); 
        
    plot(x, AvgRCuedEightLicks, 'LineWidth',1);
    hold on;
    plot(x, AvgLCuedEightLicks, 'LineWidth',1);
    hold on;
    plot(x, AvgNotCuedEightLicks, 'LineWidth',1);
    hold on;
    plot(x, AvgRFlashLicks, 'LineWidth',1);
    hold on;
    plot(x, AvgLFlashLicks, 'LineWidth',1);
    hold on;
        
    end 
    
   Title = strcat(MouseName, '-', SeshNum, ':', 'PeriStimulus Licking for Contrast', Version); 
    title(Title);
    xlabel('Peristimulus Time'); 
    ylabel('Avg Licking');
    legend('Same Side Cue', 'Opposite Side Cue', 'No Cue', 'Right Flash', 'Left Flash'); 


    FigureSaveName = 'PeriStimulus_Licking_for_Each_Cue.png'; 
    saveas(gcf, FigureSaveName); 
    close(AvgLicksPerStim);
    
end 



if exist('NumRSevenHits', 'var')

if NumRSevenHits > 20
    
    NumRCuedSeven = 0; 
    NumLCuedSeven = 0; 
    NumNotCuedSeven = 0; 
    ContrastLevel = StimByContrast(:, 8); 
    ContrastLevel = nonzeros(ContrastLevel);
      
    NumStims = length(ContrastLevel); 
    RCuedSeven = zeros(NumStims, 1); 
    LCuedSeven = zeros(NumStims, 1); 
    NotCuedSeven = zeros(NumStims, 1);
    
    for x = 1:NumStims
        
        StimIt = ContrastLevel(x, 1); 
        
        StimCueSide = CueSide(StimIt:StimIt+5); 
        StimCueSide = mode(StimCueSide); 

        if StimCueSide == 1             
            NumRCuedSeven = NumRCuedSeven + 1; 
            RCuedSeven(i, 1) = StimIt; 
        end 
        
         if StimCueSide == 2 %left side            
            NumLCuedSeven = NumLCuedSeven + 1; 
            LCuedSeven(i, 1) = StimIt; 
         end
        
         if StimCueSide == 3 %          
            NumNotCuedSeven = NumNotCuedSeven + 1;   
            NotCuedSeven(i, 1) = StimIt; 
         end       
        
    end
    
    NumRSevenHits
    RSevenHitRate =  NumRSevenHits/NumRCuedSeven
    NumLSevenHits
    LSevenHitRate =  NumLSevenHits/NumLCuedSeven 
    NumNoSevenHits
    NoSevenHitRate =  NumNoSevenHits/NumNotCuedSeven 
    
    RHitRate =  RSevenHitRate;  
    LHitRate =  LSevenHitRate;   
    NoHitRate =  NoSevenHitRate; 
    
    AvgRSevenHitTime = mean(RCuedConSevenLatencies) * 1000
    AvgLSevenHitTime = mean(LCuedConSevenLatencies) * 1000
    AvgNoCueSevenHitTime = mean(NoCueConSevenLatencies) * 1000
    
    AvgRHitTime = AvgRSevenHitTime; 
    AvgLHitTime = AvgLSevenHitTime; 
    AvgNoCueHitTime = AvgNoCueSevenHitTime; 
    
    
    TimeofSpan = zeros(NumRCuedSeven, SpanLength); 
    
    RCuedSevenSpeed = zeros(NumRCuedSeven, SpanLength);
    LCuedSevenSpeed = zeros(NumLCuedSeven, SpanLength);
    NotCuedSevenSpeed = zeros(NumNotCuedSeven, SpanLength);
    
    RCuedSeven = nonzeros(RCuedSeven); 
    LCuedSeven = nonzeros(LCuedSeven); 
    NotCuedSeven = nonzeros(NotCuedSeven); 

    for i = 1:NumRCuedSeven %ignore first and last trial 

        Stim = RCuedSeven(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        RCuedSevenLicks(i, :) = Licks((StartSpan+1):EndSpan);
        RCuedSevenSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
        TimeofSpan(i, :) = Timer((StartSpan+1):EndSpan);  

        for y = 1:SpanLength
             TimeofSpan(i, y) = TimeofSpan(i, y) - StimTime; 
        end 

    end
    
       for i = 1:NumLCuedSeven %ignore first and last trial 

        Stim = LCuedSeven(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        LCuedSevenLicks(i, :) = Licks((StartSpan+1):EndSpan);
        LCuedSevenSpeed(i, :) = Velocity((StartSpan+1):EndSpan);
 
       end
       
        for i = 1:NumNotCuedSeven %ignore first and last trial 

        Stim = NotCuedSeven(i); 

        StimTime = Timer(Stim); 

        StartSpan=   Stim- (RevAnalysisLength);
        EndSpan =  Stim+ (FwdAnalysisLength); 

        SpanLength = EndSpan - StartSpan;   %span of iterations before and after

        NotCuedSevenLicks(i, :) = Licks((StartSpan+1):EndSpan);
        NotCuedSevenSpeed(i, :) = Velocity((StartSpan+1):EndSpan);


        end
       
    AvgRCuedSevenLicks = smooth(mean(RCuedSevenLicks));
    AvgLCuedSevenLicks = smooth(mean(LCuedSevenLicks));
    AvgNotCuedSevenLicks = smooth(mean(NotCuedSevenLicks));
    x = TimeofSpan(2, :); 
    
    Version = 'Seven'; 
    AvgLicksPerStim = figure('name','PeriStimulus Licking for Each Contrast');        
        
    plot(x, AvgRCuedSevenLicks, 'LineWidth',1);
    hold on;
    plot(x, AvgLCuedSevenLicks, 'LineWidth',1);
    hold on;
    plot(x, AvgNotCuedSevenLicks, 'LineWidth',1);
    hold on;
          
     Title = strcat(MouseName, '-', SeshNum, ':', 'PeriStimulus Licking for Contrast', Version); 
    title(Title);
    xlabel('Peristimulus Time'); 
    ylabel('Avg Licking');
    legend('Same Side Cue', 'Opposite Side Cue', 'No Cue'); 


    FigureSaveName = 'PeriStimulus_Licking_for_Each_Cue.png'; 
    saveas(gcf, FigureSaveName); 
    close(AvgLicksPerStim);
    
    end 
   
end


    
cd(MousePath); 
fileID = fopen('AllDPrime.txt','a');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',Spacer, '-append');
dlmwrite('AllDPrime.txt',ContrastUsed, '-append');
dlmwrite('AllDPrime.txt',RHitRate, '-append');
dlmwrite('AllDPrime.txt',LHitRate, '-append');
dlmwrite('AllDPrime.txt',NoHitRate,'-append');
dlmwrite('AllDPrime.txt',AvgRHitTime,'-append');
dlmwrite('AllDPrime.txt',AvgLHitTime, '-append');
dlmwrite('AllDPrime.txt',AvgNoCueHitTime,'-append');
fclose(fileID);



end

cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 
    
end 


% 
%     CurrentDir = pwd; 
%     FindStart = findstr(CurrentDir, 'BH'); 
%     SaveString = CurrentDir(FindStart:end); 
%     MouseName = CurrentDir(FindStart:FindStart+4);
%     Date = CurrentDir(FindStart+6:end);
% 
%     AnalyzedPath = strcat(CodePath, '\', 'Analyzed');
%     cd(AnalyzedPath);
%     MousePath = strcat(AnalyzedPath, '\', MouseName); 
% 
%     if exist(MousePath, 'dir') == 0 
% 
%         mkdir('Analyzed', MouseName); 
% 
%     end 
% 
%     MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
%     DatePath = strcat(MousePath, '\', Date); 
% 
%     if exist(DatePath, 'dir') == 0 
% 
%         mkdir(MouseName, Date); 
%     end 
% 
%     SavePath = strcat(CodePath, '\', 'Analyzed', '\', SaveString); 
%     cd(SavePath); 
% 
%     FindSeshNum = findstr(SavePath, '\'); 
%     FindSeshNum = FindSeshNum(end); 
%     SeshNumIt = FindSeshNum + 1; 
%     SeshNum = strcat('Session', SavePath(SeshNumIt)); 
%     
%     if NumREightHits > 0
%         
%         ContrastVersion = 'Eight'; 
%         
%     end 
% 
%     
%    AllHits = figure('name','Hit Rates for All Cues');  
%    plot(REightHitRate); 
%    hold on; 
%     plot(LEightHitRate);
%     hold on; 
%     plot(NoEightHitRate); 
%     
%    Title = strcat(MouseName, '-', SeshNum, ':', 'Hit Rates Contrast Level', ContrastVersion);
%    legend('Same Side Cued', 'Opposite Side Cue', 'No Cue'); 
%     title(Title);
%     xlabel('Contrast Level'); 
%     ylabel('Hit Rate');
% 
%     FigureSaveName = 'Hit_Rates_for_All_Cues.png'; 
%     saveas(gcf, FigureSaveName); 
%     close(AllHits);
%     
%     
%     
%     AllContrastLatencies = figure('name','Lick Latencies for All Cues');  
%    plot(AvgREightHitTime); 
%    hold on; 
%     plot(AvgLEightHitTime); 
%    hold on;
%     plot(AvgNoCueEightHitTime); 
%    hold on;
%     
%    Title = strcat(MouseName, '-', SeshNum, ':', 'Lick Latencies for All Cues'); 
%     title(Title);
%     legend('Same Side Cued', 'Opposite Side Cue', 'No Cue'); 
%     xlabel('Contrast Level'); 
%     ylabel('Lick Latency');
% 
%     FigureSaveName = 'Lick_Latencies_for_All_Cues.png'; 
%     saveas(gcf, FigureSaveName); 
%     close(AllContrastLatencies);
   



