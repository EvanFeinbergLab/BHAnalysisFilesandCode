CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analysis Code'; 
DataPath = 'D:\Brooke\Data\Forced Choice Task\3Alt Corr Panel'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles
    
    i; 
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = strfind(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), 1); 
    NameAndDate = cell((NumDateFiles-2), 2); 
    
    for x = 3:NumDateFiles
        
        DateFile = MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
           
    %sort files in order of date 
        
    FirstComma = strfind(DateFilePath, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = strfind(DateFilePath, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = strfind(DateFilePath, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = DateFilePath(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates((x-2), 1) = DateNum; 
    
    DateCell = cellstr(DateNumString); 
    NameCell = cellstr(DateFile); 
    
    NameAndDate((x-2), 1) = DateCell; 
    NameAndDate((x-2), 2) = NameCell;
     
    end
   
    AscendDates = sort(Dates); 
    NumDates = length(Dates); 
    AscendFiles = cell(NumDates, 1); 
    
    for x = 1:NumDates 
        
        FindIt = find(Dates == AscendDates(x));
        AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
    end
    
    AscendFiles = char(AscendFiles);
    ItNums = zeros(NumDates, 1);
     cd(MouseFolderDataPath); 
    
    for x = 1:NumDates 
                  
        FirstChar = AscendFiles(x, 1); 
        SecondChar = AscendFiles(x, 2);
        IsNum = str2num(FirstChar);
        IsNumTwo = str2num(SecondChar);
        
        if isempty(IsNumTwo) == 0
            
            TwoDigits = strcat(FirstChar, SecondChar); 
            IsNum = str2num(TwoDigits); 
            
        end 

        if isempty(IsNum) == 0 
        
            if IsNum ~= x
                
                OldName = AscendFiles(x, :); 
                OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                AscendFiles(x, 1) = num2str(x); 
                RevisedName = AscendFiles(x, :);
                RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                movefile(OldNamePath, RevisedName);
            end 
        
        else 
            
        OldName = AscendFiles(x, :); 
        OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
        ItString = num2str(x); 
        NewName = strcat(ItString, AscendFiles(x, :));
        NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 
       
        movefile(OldNamePath, NewNamePath);            

        end
        
    end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = strfind(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = strfind(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRightRewards = single.empty(500000, 0); 
 AllRightLicks = single.empty(500000, 0); 
  AllRightDistTime = single.empty(500000, 0); 
  AllLeftRewards = single.empty(500000, 0); 
 AllLeftLicks = single.empty(500000, 0); 
  AllLeftDistTime = single.empty(500000, 0); 
 AllTime = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(14*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 14*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,14*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 14);  
Zeros = zeros(1, 14); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 14 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:14)= StimInfo;
     
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end


TotalDist= StimPos(:, 1); 
Stims = StimPos(:, 3);
RightLicks = StimPos(:, 4); 
RightRewards = StimPos(:, 5);
RightRZDist = StimPos(:, 6);
LeftLicks = StimPos(:, 7); 
LeftRewards = StimPos(:, 8);
LeftRZDist = StimPos(:, 9);
StimSize = StimPos(:, 10); 
StimSide = StimPos(:, 11);
CueSide = StimPos(:, 12);
StimMotion = StimPos(:, 13);
FlashSide = StimPos(:, 14);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllRightLicks(1:movnu) = RightLicks;
    AllRightReward(1:movnu) = RightRewards;    
    AllRightDistTime(1:movnu) = RightRZDist;
    AllLeftLicks(1:movnu) = LeftLicks;
    AllLeftReward(1:movnu) = LeftRewards;    
    AllLeftDistTime(1:movnu) = LeftRZDist;
    AllDist(1:movnu) = TotalDist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    AllTime(1:movnu) = Timer;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
   
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims;     
    AllRightRewards(StartFill: (StartFill+movnu) - 1) = RightRewards;   
    AllRightLicks(StartFill: (StartFill+movnu) - 1) = RightLicks;  
    AllRightDistTime(StartFill: (StartFill+movnu) - 1) = RightRZDist;
    AllLeftRewards(StartFill: (StartFill+movnu) - 1) = LeftRewards;   
    AllLeftLicks(StartFill: (StartFill+movnu) - 1) = LeftLicks;  
    AllLeftDistTime(StartFill: (StartFill+movnu) - 1) = LeftRZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = TotalDist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
Stims = AllStims';
RightLicks = AllRightLicks';
RightRewards = AllRightRewards';
RightRZDist = round(AllRightDistTime)'; 
LeftLicks = AllLeftLicks';
LeftRewards = AllLeftRewards';
LeftRZDist = round(AllLeftDistTime)'; 
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 1));   
NumVertStim = length(VertStimNum); 
VertStim = zeros(NumVertStim, 1); 

for i = 1:NumVertStim 
    
    if i == 1 
        VertStim(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        VertStim(i, 1) = 0; 
    else 
        VertStim(i, 1) = VertStimNum(i);
    end 
    end 
end 

VertStim = nonzeros(VertStim);  
NumVertStim = length(VertStim); 

VertCorridors = zeros(NumVertStim, 1); 
VertPanels = zeros(NumVertStim, 1); 


for i = 2: NumVertStim-1 
    
    StimIt = VertStim(i); 
    
    StimType = StimLength(StimIt:StimIt+10); 
    StimType = mode(StimType); 
    
    if StimType == 1 %corridor
        
       VertCorridors(i, 1) = StimIt;  
        
    end 
    
    if StimType == 2 %panel 
        
        VertPanels(i, 1) = StimIt;
        
    end 
    
end 

VertCorridors = nonzeros(VertCorridors);
NumVertCorridors = length(VertCorridors); 
VertPanels = nonzeros(VertPanels); 
NumVertPanels = length(VertPanels);



% VertCorrEnds = zeros(NumVertCorridors, 1); 
% 
% for i = 1:NumVertCorridors
%       
%     CorrIt = VertCorridors(i); 
%     ItInVertStim = find(VertStim == CorrIt); 
%     NextVert = ItInVertStim + 1; 
%     
%     RZValues = RightRZDist(VertCorridors(i): VertStim(NextVert)-1);
% 
%     SearchCorrEnd = find(RZValues >= 70); 
%     
%     if isempty(SearchCorrEnd) == 0 
%         
%     End = SearchCorrEnd(1); 
%     CorrEnd = VertCorridors(i)+(End-1);
%     VertCorrEnds(i, 1) = CorrEnd; 
%     
%     end
%     
% end 
% 
% VertCorrEnds = nonzeros(VertCorrEnds); 
% NumVertEnds = length(VertCorrEnds);

VertCorrEnds = zeros(NumVertCorridors, 1); 

for i = 1:NumVertCorridors
      
    CorrIt = VertCorridors(i); 
    CorrStartDist = TotalDist(CorrIt); 
    CorrEndDist = CorrStartDist + 69; 

    SearchCorrEnd = find(TotalDist >= CorrEndDist); 
    
    if isempty(SearchCorrEnd) == 0 
        
    CorrEnd = SearchCorrEnd(1);
    VertCorrEnds(i, 1) = CorrEnd; 
    
    end
    
end 

VertCorrEnds = nonzeros(VertCorrEnds); 
NumVertEnds = length(VertCorrEnds);

%finds occurences of vert reward
VertCorridorRewards = zeros(NumVertCorridors, 1); 
VertEarnedCorrRewards = zeros(NumVertCorridors, 1);
VertCorrFAs = zeros(NumVertCorridors, 1);
VertCorrMisses = zeros(NumVertCorridors, 1);
VertCorrLatency = zeros(NumVertCorridors, 1);

VertCorrRewards = zeros(NumVertCorridors, 1); 

for i = 1: NumVertCorridors
     
    StimStart = VertCorridors(i); 
    EndRZ = VertCorrEnds(i); 
    StimTime = Timer(StimStart); 

    
    RightLickSpan = RightLicks(StimStart:EndRZ); 
    RightLickWithin = find(RightLickSpan == 1); 
   
    LeftLickSpan = LeftLicks(StimStart:EndRZ); 
    LeftLickWithin = find(LeftLickSpan == 1);
    
    if isempty(RightLickWithin) == 0 %if there was a vert lick 
        
         RightLick = RightLickWithin(1); 
           
        if isempty(LeftLickWithin) == 0 %if there was also a diag lick 
            
            LeftLick = LeftLickWithin(1); 
            
             if RightLick < LeftLick %if vert lick first 

                FirstLick = RightLick;
                FirstLickIt = (FirstLick - 1) + StimStart; 
                FirstLickTime = Timer(FirstLickIt); 
                VertCorrLatency(i, 1) = FirstLickTime - StimTime; 
                VertEarnedCorrRewards(i, 1) = StimStart;
                
             else 
                 
                 VertCorrFAs(i, 1) = StimStart; 
                   
            end 
             
        else %if there was only a vert lick 
            
                FirstLick = RightLick;
                FirstLickIt = (FirstLick - 1) + StimStart; 
                VertEarnedCorrRewards(i, 1) = StimStart;
                FirstLickTime = Timer(FirstLickIt); 
                VertCorrLatency(i, 1) = FirstLickTime - StimTime; 
            
        end 
        
    else 
        
        if isempty(LeftLickWithin) == 0
            
            VertCorrFAs(i, 1) = StimStart;
            
        else 
            
            VertCorrMisses(i, 1) = StimStart; 
            
        end 
        
    end 
end 

VertEarnedCorrRewards = nonzeros(VertEarnedCorrRewards); 
NumVertEarnedRewards = length(VertEarnedCorrRewards); 

VertCorrFAs = nonzeros(VertCorrFAs); 
VertCorrMisses = nonzeros(VertCorrMisses); 

NumVertCorrFAs = length(VertCorrFAs); 
NumVertCorrMisses = length(VertCorrMisses);

VertCorrLatency = nonzeros(VertCorrLatency); 
AvgVertCorrLatency = mean(VertCorrLatency)*1000



VertPanelRewards = zeros(NumVertPanels, 1); 
VertPanelLatency = zeros(NumVertPanels, 1);
VertPanelFAs = zeros(NumVertPanels, 1);
VertPanelMisses = zeros(NumVertPanels, 1);

for i = 1:NumVertPanels 
    
    StimStart = VertPanels(i); 
    StimTime = Timer(StimStart); 
 
    WindowEnd = RightRZDist(StimStart:StimStart+50); 
    EndWindow = max(WindowEnd);
    StimEnd = find(WindowEnd == EndWindow); 
    StimEnd = (StimStart - 1) + StimEnd; 
    
    VertLick = find(RightLicks(StimStart:StimEnd) == 1);    
    WrongLick = find(LeftLicks(StimStart:StimEnd) == 1); 
    
    if isempty(VertLick) == 0 %if there was a vert lick 
        
        if isempty(WrongLick) == 0 %if there was also a diag lick 
            
            if VertLick(1) < WrongLick(1) %if the vert lick was first 
                
                VertPanelRewards(i, 1) = StimStart; 
                
                FirstLick = VertLick(1); 
                VertLickIt = (StimStart - 1) + FirstLick; 
                VertLickTime = Timer(VertLickIt) - StimTime; 
                
                VertPanelLatency(i, 1) = VertLickTime; 
                
            else  %if diag lick first 
                
                VertPanelFAs(i, 1) = StimStart; 
                
            end   
            
        else %if there was only a vert lick 
            
             VertPanelRewards(i, 1) = StimStart; 
                
                FirstLick = VertLick(1); 
                VertLickIt = (StimStart - 1) + FirstLick; 
                VertLickTime = Timer(VertLickIt) - StimTime; 
                
                VertPanelLatency(i, 1) = VertLickTime; 
            
        end   
        
    else %if there was no vert lick 
        
        if isempty(WrongLick) == 0 %if there was only a diag lick 
            
            VertPanelFAs(i, 1) = StimStart; 
            
        else %if there were no licks 
            
            VertPanelMisses(i, 1) = StimStart; 
            
        end 
    end   
end 


VertPanelRewards = nonzeros(VertPanelRewards); 
NumVertPanelRewards = length(VertPanelRewards); 

VertPanelLatency = nonzeros(VertPanelLatency); 
AvgVertPanelLatency = mean(VertPanelLatency)*1000 

VertPanelFAs = nonzeros(VertPanelFAs); 
VertPanelMisses = nonzeros(VertPanelMisses); 

NumVertPanelFAs = length(VertPanelFAs); 
NumVertPanelMisses = length(VertPanelMisses);




%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 2));   
NumDiagStim = length(DiagStimNum); 
DiagStim = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStim(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStim(i, 1) = 0; 
    else 
        DiagStim(i, 1) = DiagStimNum(i);
    end 
    end 
end 

DiagStim = nonzeros(DiagStim);  
NumDiagStim = length(DiagStim); 

DiagCorridors = zeros(NumDiagStim, 1); 
DiagPanels = zeros(NumDiagStim, 1); 


for i = 2: NumDiagStim-1 
    
    StimIt = DiagStim(i); 
    
    StimType = StimLength(StimIt:StimIt+10); 
    StimType = mode(StimType); 
    
    if StimType == 1 %corridor
        
       DiagCorridors(i, 1) = StimIt;  
        
    end 
    
    if StimType == 2 %panel 
        
        DiagPanels(i, 1) = StimIt;
        
    end 
    
end 

DiagCorridors = nonzeros(DiagCorridors);
NumDiagCorridors = length(DiagCorridors); 
DiagPanels = nonzeros(DiagPanels); 
NumDiagPanels = length(DiagPanels);


% DiagCorrEnds = zeros(NumDiagCorridors, 1); 
% 
% for i = 1:NumDiagCorridors
%     
%     CorrIt = DiagCorridors(i); 
%     ItInDiagStim = find(DiagStim == CorrIt); 
%     NextDiag = ItInDiagStim + 1; 
%     
%     RZValues = LeftRZDist(CorrIt: DiagStim(NextDiag)-1);
%    
%     SearchCorrEnd = find(RZValues >= 70); 
%     
%     if isempty(SearchCorrEnd) == 0 
%         
%     End = SearchCorrEnd(1); 
%     CorrEnd = DiagCorridors(i)+(End-1);
%     DiagCorrEnds(i, 1) = CorrEnd; 
%     
%     end
%     
% end 
% 
% DiagCorrEnds = nonzeros(DiagCorrEnds); 
% NumDiagEnds = length(DiagCorrEnds);

VertCorrEnds = zeros(NumVertCorridors, 1); 

for i = 1:NumDiagCorridors
      
    CorrIt = DiagCorridors(i); 
    CorrStartDist = TotalDist(CorrIt); 
    CorrEndDist = CorrStartDist + 69; 

    SearchCorrEnd = find(TotalDist >= CorrEndDist); 
    
    if isempty(SearchCorrEnd) == 0 
        
    CorrEnd = SearchCorrEnd(1);
    DiagCorrEnds(i, 1) = CorrEnd; 
    
    end
    
end 

DiagCorrEnds = nonzeros(DiagCorrEnds); 
NumDiagEnds = length(DiagCorrEnds);

%finds occurences of Diag reward
DiagEarnedCorrRewards = zeros(NumDiagCorridors, 1); 
DiagCorrFAs = zeros(NumDiagCorridors, 1); 
DiagCorrMisses = zeros(NumDiagCorridors, 1); 

for i = 1: NumDiagCorridors
     
    StimStart = DiagCorridors(i); 
    EndRZ = DiagCorrEnds(i); 
    StimTime = Timer(StimStart); 
    
    RightLickSpan = RightLicks(StimStart:EndRZ); 
    RightLickWithin = find(RightLickSpan == 1); 
   
    LeftLickSpan = LeftLicks(StimStart:EndRZ); 
    LeftLickWithin = find(LeftLickSpan == 1);
    
    if isempty(LeftLickWithin) == 0 %if there was a Diag lick 
        
         LeftLick = LeftLickWithin(1); 
           
        if isempty(RightLickWithin) == 0 %if there was also a vert lick 
            
           RightLick = RightLickWithin(1); 
            
             if LeftLick < RightLick %if Diag lick first 
               
            FirstLick = LeftLick;
            FirstLickIt = (FirstLick - 1) + StimStart; 
            DiagEarnedCorrRewards(i, 1) = StimStart;
            DiagLickTime = Timer(FirstLickIt) - StimTime;                 
            DiagCorrLatency(i, 1) = DiagLickTime; 
            
             else %if vert lick first 
                 
                  DiagCorrFAs(i, 1) = StimStart; 
                   
            end 
             
        else %if there was only a Diag lick 
            
            FirstLick = LeftLick;
            FirstLickIt = (FirstLick - 1) + StimStart; 
            DiagEarnedCorrRewards(i, 1) = StimStart;
            DiagLickTime = Timer(FirstLickIt) - StimTime;                 
            DiagCorrLatency(i, 1) = DiagLickTime; 
            
        end 
        
    else %if there was no diag lick 
        
        if isempty(RightLickWithin) == 0 %but there was a vert lick 
            
            DiagCorrFAs(i, 1) = StimStart; 
            
        else %there were no licks 
            
            DiagCorrMisses(i, 1) = StimStart; 
            
        end 
   
    end 
end 

DiagEarnedCorrRewards = nonzeros(DiagEarnedCorrRewards); 
NumDiagEarnedRewards = length(DiagEarnedCorrRewards); 

DiagCorrFAs = nonzeros(DiagCorrFAs); 
DiagCorrMisses = nonzeros(DiagCorrMisses); 

NumDiagCorrFAs = length(DiagCorrFAs); 
NumDiagCorrMisses = length(DiagCorrMisses); 

DiagCorrLatency = nonzeros(DiagCorrLatency); 
AvgDiagCorrLatency = mean(DiagCorrLatency)*1000


DiagPanelRewards = zeros(NumDiagPanels, 1); 
DiagPanelLatency = zeros(NumDiagPanels, 1); 
DiagPanelMisses = zeros(NumDiagPanels, 1); 
DiagPanelFAs = zeros(NumDiagPanels, 1); 

for i = 1:NumDiagPanels 
    
    StimStart = DiagPanels(i); 
    StimTime = Timer(StimStart); 
 
    WindowEnd = LeftRZDist(StimStart:StimStart+50); 
    EndWindow = max(WindowEnd);
    StimEnd = find(WindowEnd == EndWindow); 
    StimEnd = (StimStart - 1) + StimEnd; 
    
    DiagLick = find(LeftLicks(StimStart:StimEnd) == 1);  
    WrongLick = find(RightLicks(StimStart:StimEnd) == 1); 
    
    if isempty(DiagLick) == 0 %if there was a Diag lick 
        
        if isempty(WrongLick) == 0 %if there was also a diag lick 
            
            if DiagLick(1) < WrongLick(1) %if the Diag lick was first 
                
                DiagPanelRewards(i, 1) = StimStart; 
                
                FirstLick = DiagLick(1); 
                DiagLickIt = (StimStart - 1) + FirstLick; 
                DiagLickTime = Timer(DiagLickIt) - StimTime; 
                
                DiagPanelLatency(i, 1) = DiagLickTime; 
                
            else %vert lick first 
                
                DiagPanelFAs(i, 1) = StimStart; 
                
            end   
            
        else %if there was only a diag lick 
            
             DiagPanelRewards(i, 1) = StimStart; 
                
                FirstLick = DiagLick(1); 
                DiagLickIt = (StimStart - 1) + FirstLick; 
                DiagLickTime = Timer(DiagLickIt) - StimTime; 
                
                DiagPanelLatency(i, 1) = DiagLickTime; 
            
        end   
        
    else %there was no diag lick        
        
        if isempty(WrongLick) == 0 % but there was a vert lick 
            
             DiagPanelFAs(i, 1) = StimStart; 
             
        else %there were no licks 
            
             DiagPanelMisses(i, 1) = StimStart; 
            
        end 
        
    end   
end 

DiagPanelRewards = nonzeros(DiagPanelRewards); 
NumDiagPanelRewards = length(DiagPanelRewards); 

DiagPanelFAs = nonzeros(DiagPanelFAs); 
DiagPanelMisses = nonzeros(DiagPanelMisses); 

NumDiagPanelFAs = length(DiagPanelFAs); 
NumDiagPanelMisses = length(DiagPanelMisses); 

DiagPanelLatency = nonzeros(DiagPanelLatency); 
AvgDiagPanelLatency = mean(DiagPanelLatency)*1000


AllVertFAs = [VertPanelFAs;VertCorrFAs]; 
AllDiagFAs = [DiagPanelFAs;DiagCorrFAs]; 
AllFAs = [AllVertFAs; AllDiagFAs];
AllFAs = sort(AllFAs, 'ascend');

AllVertMisses = [VertPanelMisses;VertCorrMisses]; 
AllDiagMisses = [DiagPanelMisses;DiagCorrMisses]; 
AllMisses = [AllVertMisses; AllDiagMisses];
AllMisses = sort(AllMisses, 'ascend');

VertUnRewarded = [AllVertFAs; AllVertMisses]; 
VertUnRewarded = sort(VertUnRewarded, 'ascend');
NumVertUnRewarded = length(VertUnRewarded); 
DiagUnRewarded = [AllDiagFAs; AllDiagMisses]; 
DiagUnRewarded = sort(DiagUnRewarded, 'ascend');
NumDiagUnRewarded = length(DiagUnRewarded); 

VertRewarded = [VertEarnedCorrRewards; VertPanelRewards];
VertRewarded = sort(VertRewarded, 'ascend');
NumVertRewarded = length(VertRewarded); 
DiagRewarded = [DiagEarnedCorrRewards; DiagPanelRewards];
DiagRewarded = sort(DiagRewarded, 'ascend');
NumDiagRewarded = length(DiagRewarded); 



VertStim = VertStim(1:NumVertStim - 1); 
DiagStim = DiagStim(1:NumDiagStim - 1); 
AllStim = [VertStim; DiagStim]; 
AllStim = sort(AllStim, 'ascend'); 
NumAllStim = length(AllStim); 

PeriStimProbVertBeforeVertRewarded = zeros(NumVertRewarded-9, 11);

for i = 5:NumVertRewarded-5 
    
    VertIt = VertRewarded(i); 
    TotalIt = find(AllStim == VertIt); 
    PeriStimSpan = AllStim(TotalIt-5:TotalIt+5); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Vert = find(VertStim == StimType); 
        
        if isempty(Vert) == 0 
            
            PeriStimProbVertBeforeVertRewarded(i-4, x) = 1;  
            
        end 
               
    end    
end 

PeriStimulusProbVertBeforeVertRewarded = mean(PeriStimProbVertBeforeVertRewarded) ;


PeriStimProbDiagBeforeVertUnRewarded = zeros(NumVertUnRewarded-9, 11);

for i = 5:NumVertUnRewarded-5 
    
    VertIt = VertUnRewarded(i); 
    TotalIt = find(AllStim == VertIt); 
    PeriStimSpan = AllStim(TotalIt-5:TotalIt+5); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Diag = find(DiagStim == StimType); 
        
        if isempty(Diag) == 0 
            
            PeriStimProbDiagBeforeVertUnRewarded(i-4, x) = 1;  
            
        end 
               
    end    
end 

PeriStimulusProbDiagBeforeVertUnRewarded = mean(PeriStimProbDiagBeforeVertUnRewarded); 



PeriStimProbDiagBeforeDiagRewarded = zeros(NumDiagRewarded-9, 11);

for i = 5:NumDiagRewarded-5 
    
    DiagIt = DiagRewarded(i); 
    TotalIt = find(AllStim == DiagIt); 
    PeriStimSpan = AllStim(TotalIt-5:TotalIt+5); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Diag = find(DiagStim == StimType); 
        
        if isempty(Diag) == 0 
            
            PeriStimProbDiagBeforeDiagRewarded(i-4, x) = 1;  
            
        end 
               
    end    
end 

PeriStimulusProbDiagBeforeDiagRewarded = mean(PeriStimProbDiagBeforeDiagRewarded); 




PeriStimProbVertBeforeDiagUnRewarded = zeros((NumDiagUnRewarded-9), 11);

for i = 5:NumDiagUnRewarded-5 
    
    VertIt = DiagUnRewarded(i); 
    TotalIt = find(AllStim == VertIt); 
    PeriStimSpan = AllStim(TotalIt-5:TotalIt+5); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Vert = find(VertStim == StimType); 
        
        if isempty(Vert) == 0 
            
            PeriStimProbVertBeforeDiagUnRewarded(i-4, x) = 1;  
            
        end 
               
    end    
end 

PeriStimulusProbVertBeforeDiagUnRewarded = mean(PeriStimProbVertBeforeDiagUnRewarded); 




%test for # iterations per 1 ms 
  
VertIt =  VertStim(2); %iteration of each reward
    StimTime = round(Timer(VertIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  VertIt - ItBefore;   
     

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 10; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;

 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;
 
 StartSpan=   VertIt- (RevAnalysisLength);
 EndSpan = VertIt+ (FwdAnalysisLength);
  
 SpanLength = EndSpan - StartSpan; 
  
  
%peristimulus and reward lick behavior for all vert 

VertLicksinSpan = zeros(SpanLength, NumVertCorridors); 
LeftLicksDuring = zeros(SpanLength, NumVertCorridors); 
VertTimeofSpan = zeros(SpanLength, NumVertCorridors); 
VertSpeedinSpan = zeros(SpanLength, NumVertCorridors); 

for i = 2:NumVertCorridors-1
    
    VertIt =  VertCorridors(i);
    StimTime = Timer(VertIt); 
   
    StartSpan=   VertIt- (RevAnalysisLength);
    EndSpan =  VertIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after
    Blocks = SpanLength/ItPerMs;

    VertLicksinSpan(:, i) = RightLicks((StartSpan+1):EndSpan);
    LeftLicksDuring(:, i) = LeftLicks((StartSpan+1):EndSpan);
    VertSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
    VertTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
    
    for y = 1:SpanLength
         VertTimeofSpan(y, i) = VertTimeofSpan(y, i) - StimTime; 
    end 
    
    VertTimeofSpan(:, i) ;
end


VertLicksinSpan = VertLicksinSpan';  
VertTimeofSpan = VertTimeofSpan';  
VertSpeedinSpan = VertSpeedinSpan';
LeftLicksDuring = LeftLicksDuring'; 



%peristimulus and reward lick behavior for diag stim 

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 10; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan; 
 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;

DiagLicksinSpan = zeros(SpanLength, NumDiagCorridors); 
DiagTimeofSpan = zeros(SpanLength, NumDiagCorridors); 
DiagSpeedinSpan = zeros(SpanLength, NumDiagCorridors); 
RightLicksDuring = zeros(SpanLength, NumDiagCorridors); 

for i = 2:NumDiagCorridors-1
    
    DiagIt = DiagCorridors(i);   
    DiagStimTime = Timer(DiagIt);          
   
    StartSpan=  DiagIt- (RevAnalysisLength);
    EndSpan = DiagIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

         DiagLicksinSpan(:, i) = LeftLicks((StartSpan+1):EndSpan);
         RightLicksDuring(:, i) = RightLicks((StartSpan+1):EndSpan);
         DiagSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
         DiagTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);   
         
         for y = 1:SpanLength
            
         DiagTimeofSpan(y, i) = DiagTimeofSpan(y, i) - DiagStimTime; 
         
         end 
 
end

DiagLicksinSpan = DiagLicksinSpan';
DiagTimeofSpan = DiagTimeofSpan'; 
DiagSpeedinSpan = DiagSpeedinSpan'; 
RightLicksDuring =  RightLicksDuring'; 






CurrentDir = pwd; 
FindStart = strfind(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Forced Choice Task';
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(AnalyzedPath, '\', SaveString); 
cd(SavePath); 

FindSeshNum = strfind(SavePath, '\'); 
FindSeshNum = FindSeshNum(end); 
SeshNumIt = FindSeshNum + 1; 
SeshNum = strcat('Session', SavePath(SeshNumIt))




XLabel = 'Peristimulus Time (s)';
YLabel = 'Average Licks'; 

AvgLicksinSpanForVert = smooth(mean(VertLicksinSpan, 1));
AvgLeftLicksDuring = smooth(mean(LeftLicksDuring, 1)); 

x = VertTimeofSpan(2, :); 

VertAvgLicks = figure('name', 'Average Licks For Vert Stim In Session'); 
plot(x, AvgLicksinSpanForVert, x, AvgLeftLicksDuring); 
hold on; 
Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Vert Stim In Session'); 
title(Title); 
legend('Right(Correct) Licks', 'Left(False) Licks'); 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Average_Licks_For_Vert_Stim_In_Session.png'; 
saveas(gcf, FigureSaveName); 
close(VertAvgLicks); 




AvgLicksinSpanForDiag = smooth(mean(DiagLicksinSpan, 1));
AvgRightLicksDuring = smooth(mean(RightLicksDuring, 1)); 

x = DiagTimeofSpan(2, :); 

DiagAvgLicks = figure('name', 'Average Licks For Diag Stim In Session'); 
plot(x, AvgLicksinSpanForDiag, x, AvgRightLicksDuring); 
hold on; 
Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Diag Stim In Session'); 
title(Title); 
legend('Left(Correct) Licks', 'Right(False) Licks'); 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Average_Licks_For_Diag_Stim_In_Session.png'; 
saveas(gcf, FigureSaveName); 
close(DiagAvgLicks); 




EarnedVertCorrRewardRate = NumVertEarnedRewards/NumVertCorridors; 
EarnedDiagRewardRate = NumDiagEarnedRewards/NumDiagCorridors; 

EarnedRewardRates = figure('name', 'Earned Reward Rate For Corridors'); 
bar(1, EarnedVertCorrRewardRate);
hold on;
bar(2, EarnedDiagRewardRate, 'r');
legend('Vertical Stim', 'Diagonal Stim'); 

FigureSaveName = 'Corridor_Reward_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(EarnedRewardRates);




EarnedVertPanelRewardRate = NumVertPanelRewards/NumVertPanels; 
EarnedDiagPanelRewardRate = NumDiagPanelRewards/NumDiagPanels; 

EarnedRewardRates = figure('name', 'Earned Reward Rate For Panels'); 
bar(1, EarnedVertPanelRewardRate);
hold on;
bar(2, EarnedDiagPanelRewardRate, 'r');
legend('Vertical Stim', 'Diagonal Stim'); 

FigureSaveName = 'Panel_Reward_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(EarnedRewardRates);


NumVertRewarded = length(VertRewarded); 
NumDiagRewarded = length(DiagRewarded); 
VertRewardRate = NumVertRewarded/NumVertStim; 
DiagRewardRate = NumDiagRewarded/NumDiagStim; 

AllRewardRates = figure('name', 'All Reward Rates'); 
bar(1, VertRewardRate);
hold on;
bar(2, DiagRewardRate, 'r');
legend('Vertical Stim', 'Diagonal Stim'); 

FigureSaveName = 'All_Reward_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(AllRewardRates);



LickLatencies = figure('name', 'Lick Latencies'); 
bar(1, AvgVertCorrLatency);
hold on;
bar(2, AvgVertPanelLatency, 'r');
hold on;
bar(3, AvgDiagCorrLatency, 'g');
hold on;
bar(4, AvgDiagPanelLatency, 'm');
legend('Vert Corridors', 'Vert Panels','Diag Corridors', 'Diag Panels', 'Location', 'NorthOutside'); 

FigureSaveName = 'Lick_Latencies.png'; 
saveas(gcf, FigureSaveName); 
close(LickLatencies);



PeriStimProb = figure('name', 'Peristimulus Probabilities'); 
subplot(2,2,1); 
bar(PeriStimulusProbVertBeforeVertRewarded);
legend('Vert Around Vert Rewarded', 'Location', 'NorthOutside'); 
hold on;
subplot(2,2,2);
bar(PeriStimulusProbDiagBeforeVertUnRewarded, 'r');
legend('Diag Around Vert UnRewarded', 'Location', 'NorthOutside'); 
hold on; 
subplot(2,2,3);
bar(PeriStimulusProbDiagBeforeDiagRewarded, 'g');
legend('Diag Around Diag Rewarded', 'Location', 'NorthOutside'); 
hold on; 
subplot(2,2,4);
bar(PeriStimulusProbVertBeforeDiagUnRewarded, 'b');
legend('Vert Around Diag UnRewarded', 'Location', 'NorthOutside'); 

FigureSaveName = 'Peristimulus_Probabilities.png'; 
saveas(gcf, FigureSaveName); 
close(PeriStimProb);




VertHitsFrac = NumVertRewarded/NumVertStim; 
DiagHitsFrac = NumDiagRewarded/NumDiagStim;

if VertHitsFrac == 0
    VertHitsFrac = 0.01
end
if VertHitsFrac == 1
    VertHitsFrac = 0.99
end

if DiagHitsFrac == 0
    DiagHitsFrac = 0.01
end
if DiagHitsFrac == 1
    DiagHitsFrac = 0.99
end

NumVertFAs = length(AllVertFAs); 
VertFAFrac = NumVertFAs/NumVertStim; 
NumDiagFAs = length(AllDiagFAs); 
DiagFAFrac = NumDiagFAs/NumDiagStim;

if VertFAFrac == 0
    VertFAFrac = 0.01
end
if VertFAFrac == 1
    VertFAFrac = 0.99
end

if DiagFAFrac == 0
    DiagFAFrac = 0.01
end
if DiagFAFrac == 1
    DiagFAFrac = 0.99
end

VertHitNormInv = norminv(VertHitsFrac,0,1)
VertFANormInv = norminv(VertFAFrac,0,1)
VertDPrime = VertHitNormInv - VertFANormInv
DiagHitNormInv = norminv(DiagHitsFrac,0,1)
DiagFANormInv = norminv(DiagFAFrac,0,1)
DiagDPrime = DiagHitNormInv - DiagFANormInv



NumVertCorrHits = length(VertEarnedCorrRewards); 
VertCorrHitFrac = NumVertCorrHits/NumVertCorridors; 
NumDiagCorrHits = length(DiagEarnedCorrRewards); 
DiagCorrHitFrac = NumDiagCorrHits/NumDiagCorridors;

if VertCorrHitFrac == 0
    VertCorrHitFrac = 0.01
end
if VertCorrHitFrac == 1
    VertCorrHitFrac = 0.99
end

if DiagCorrHitFrac == 0
    DiagCorrHitFrac = 0.01
end
if DiagCorrHitFrac == 1
    DiagCorrHitFrac = 0.99
end

NumVertCorrFAs = length(VertCorrFAs); 
VertCorrFAFrac = NumVertCorrFAs/NumVertCorridors; 
NumDiagCorrFAs = length(DiagCorrFAs); 
DiagCorrFAFrac = NumDiagCorrFAs/NumDiagCorridors;

if VertCorrFAFrac == 0
    VertCorrFAFrac = 0.01
end
if VertCorrFAFrac == 1
    VertCorrFAFrac = 0.99
end

if DiagCorrFAFrac == 0
    DiagCorrFAFrac = 0.01
end
if DiagCorrFAFrac == 1
    DiagCorrFAFrac = 0.99
end


VertCorrHitNormInv = norminv(VertCorrHitFrac,0,1)
VertCorrFANormInv = norminv(VertCorrFAFrac,0,1)
VertCorrDPrime = VertCorrHitNormInv - VertCorrFANormInv
DiagCorrHitNormInv = norminv(DiagCorrHitFrac,0,1)
DiagCorrFANormInv = norminv(DiagCorrFAFrac,0,1)
DiagCorrDPrime = DiagCorrHitNormInv - DiagCorrFANormInv



NumVertPanelHits = length(VertPanelRewards); 
VertPanelHitFrac = NumVertPanelHits/NumVertPanels; 
NumDiagPanelHits = length(DiagPanelRewards); 
DiagPanelHitFrac = NumDiagPanelHits/NumDiagPanels;

if VertPanelHitFrac == 0
    VertPanelHitFrac = 0.01
end
if VertPanelHitFrac == 1
    VertPanelHitFrac = 0.99
end

if DiagPanelHitFrac == 0
    DiagPanelHitFrac = 0.01
end
if DiagPanelHitFrac == 1
    DiagPanelHitFrac = 0.99
end

NumVertPanelFAs = length(VertPanelFAs); 
VertPanelFAFrac = NumVertPanelFAs/NumVertPanels; 
NumDiagPanelFAs = length(DiagPanelFAs); 
DiagPanelFAFrac = NumDiagPanelFAs/NumDiagPanels;

if VertPanelFAFrac == 0
    VertPanelFAFrac = 0.01
end
if VertPanelFAFrac == 1
    VertPanelFAFrac = 0.99
end

if DiagPanelFAFrac == 0
    DiagPanelFAFrac = 0.01
end
if DiagPanelFAFrac == 1
    DiagPanelFAFrac = 0.99
end

VertPanelHitNormInv = norminv(VertPanelHitFrac,0,1)
VertPanelFANormInv = norminv(VertPanelFAFrac,0,1)
VertPanelDPrime = VertPanelHitNormInv - VertPanelFANormInv
DiagPanelHitNormInv = norminv(DiagPanelHitFrac,0,1)
DiagPanelFANormInv = norminv(DiagPanelFAFrac,0,1)
DiagPanelDPrime = DiagPanelHitNormInv - DiagPanelFANormInv




AllDPrimes = figure('name', 'D Primes for All Stim'); 
bar(1, VertDPrime, 'k');
hold on;
bar(2, VertCorrDPrime, 'r');
hold on; 
bar(3, VertPanelDPrime, 'b');
hold on;
bar(4, DiagDPrime, 'k');
hold on; 
bar(5, DiagCorrDPrime, 'm');
hold on;
bar(6, DiagPanelDPrime, 'c');

legend('All Vert', 'Vert Corridors', 'Vert Panels', 'All Diag', 'Diag Corridors', 'Diag Panels'); 

FigureSaveName = 'All_D_Primes.png'; 
saveas(gcf, FigureSaveName); 
close(AllDPrimes);




% YLabel = 'Trial'; 
% 
% Trials = (1:NumVertStim);
% VertTrialsOne = figure('name','Vertical Trials Part1'); 
% 
% for i = 1:(round(NumVertStim/2)) 
%     
%     i; 
%     x = VertTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%       
%     hold on; 
%        
%     VertIt = VertStim(i);
%     StimTime = Timer(VertIt);
%      
%      EndRZ = VertCorrEnds(i);
%      RZEndTime = Timer(EndRZ)-StimTime;  
%      
%      StartRZ = VertRZStarts(i);
%      RZStartTime = Timer(StartRZ)-StimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y]; 
%      
%      plot(RZSpan, Ys, 'Color', [0 0.75 0], 'LineWidth', 6);
%      Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part1'); 
%      title(Title); 
%      xlabel(XLabel); 
%      ylabel(YLabel); 
%      
%   hold on; 
%     
%     for a = 1:SpanLength
%                
%         LickPresent = VertLicksinSpan(i, a);  
%         
%         if LickPresent == 1
%             
%             LickTime = VertTimeofSpan(i, a); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%     end  
%     
%     hold on; 
%     
%      RewardIt = VertCorridorRewards(i); 
%      
%      if RewardIt ~=0
%      
%      RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
%      plot(RewardTime, y, 'r.', 'MarkerSize', 16); 
%      
%      else
%          
%        plot(RZEndTime, y, 'r.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%      end
%     
% end  
% 
% FigureSaveName = 'Vert_Trials_Part1.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertTrialsOne); 
% 
% 
% 
% 
% VertTrialTwo = figure('name','Vert Trials Part2'); 
% 
% for i = round((NumVertStim/2))+1 : NumVertStim-1 
%     
% 
%     x = VertTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%     hold on; 
%        
%     VertIt = VertStim(i);
%     StimTime = Timer(VertIt);
%      
%      EndRZ = VertCorrEnds(i);
%      RZEndTime = Timer(EndRZ)-StimTime;  
%      
%      StartRZ = VertRZStarts(i);
%      RZStartTime = Timer(StartRZ)-StimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y]; 
%      
%      plot(RZSpan, Ys, 'Color', [0 0.75 0], 'LineWidth', 6);
%      Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part2'); 
%      title(Title); 
%      xlabel(XLabel); 
%      ylabel(YLabel);
%      
%   hold on; 
%     
%     for a = 1:SpanLength
%                
%         LickPresent = VertLicksinSpan(i, a);  
%         
%         if LickPresent == 1
%             
%             LickTime = VertTimeofSpan(i, a); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%     end  
%     
%     hold on; 
%     
%      RewardIt = VertCorridorRewards(i);
%      
%      if RewardIt ~= 0
%      
%      RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
%      plot(RewardTime, y, 'r.', 'MarkerSize', 16); 
%      
%       else
%          
%        plot(RZEndTime, y, 'r.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%      
%      end
%     
% end 
% 
% FigureSaveName = 'Vert_Trials_Part2.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertTrialTwo); 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% Trials = (1:NumDiagStim);
% YLabel = 'Trial'; 
% 
% DiagTrialsOne = figure('name','Diag Trials Part1'); 
% 
% for i = 1:round((NumDiagStim/2)) 
%     
%    
%     x = DiagTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%        
%     hold on;     
%      
%     DiagStimIt = DiagStim(i); 
%     DiagStimTime = Timer(DiagStimIt); 
%      
%      EndRZ = DiagRZEnds(i);
%      RZEndTime = Timer(EndRZ)-DiagStimTime;  
%      
%      StartRZ = DiagRZStarts(i);
%      RZStartTime = Timer(StartRZ)-DiagStimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y]; 
%     
%     plot(RZSpan, Ys, 'r', 'LineWidth', 6);
%     Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
% 
%     hold on; 
%     
%         for z = 1:SpanLength
%         
%         LickPresent = DiagLicksinSpan (i, z);  
%         
%         if LickPresent == 1
%             
%             LickTime = DiagTimeofSpan(i, z); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%         end  
%     
%         hold on; 
%         
%          RewardIt = DiagRewards(i); 
%          
%          if RewardIt ~=0
%          
%          RewardTime = Timer(RewardIt)-DiagStimTime; %time at that reward occurrence
%          plot(RewardTime, y, 'b.', 'MarkerSize', 16); 
%          
%          else
%          
%         plot(RZEndTime, y, 'b.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%          
%          end
%     
% end 
% 
% FigureSaveName = 'Diag_Trials_Part1.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagTrialsOne); 
% 
% 
% 
% DiagTrialsTwo = figure('name','DiagTrials Part2'); 
% 
% for i = round((NumDiagStim/2))+1 : NumDiagStim-1 
% 
%       x = DiagTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%        
%     hold on;     
%      
%     DiagStimIt = DiagStim(i); 
%     DiagStimTime = Timer(DiagStimIt); 
%     
%      EndRZ = DiagRZEnds(i);
%      RZEndTime = Timer(EndRZ)-DiagStimTime;  
%      
%      StartRZ = DiagRZStarts(i);
%      RZStartTime = Timer(StartRZ)-DiagStimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y];    
%     
%     plot(RZSpan, Ys, 'r', 'LineWidth', 6);
%     Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part2'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
%     
%     hold on; 
%     
%         for z = 1:SpanLength
%         
%         LickPresent = DiagLicksinSpan (i, z);  
%         
%         if LickPresent == 1
%             
%             LickTime = DiagTimeofSpan(i, z); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%         end 
%     
%         hold on;
%         
%         RewardIt = DiagRewards(i); 
%         
%         if RewardIt ~=0
%         
%         RewardTime = Timer(RewardIt)- DiagStimTime; %time at that reward occurrence
%         plot(RewardTime, y, 'b.', 'MarkerSize', 16);
%         
%          else
%          
%        plot(RZEndTime, y, 'b.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%      
%         end
%        
% end  
% 
% FigureSaveName = 'Diag_Trials_Part2.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagTrialsTwo); 




cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 


end 



   




