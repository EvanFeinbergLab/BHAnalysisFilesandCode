CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analysis Code'; 
DataPath = 'D:\Brooke\Data\Self Initiated 2AFC'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); %lists the files in a directory
NumMiceFiles = length(MiceFiles);   %number of files in the data path 
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles %for each BH data folder -- for each mouse 
    
    i; 
    cd(DataPath); 
    MouseFolder = MiceFiles(i).name; %get name of file in data path 
    BHfile = strfind(MouseFolder, 'BH'); %find out if its a BH file -- searches name for BH
    
    if isempty(BHfile) == 0  %if it is a BH file -- if the BH string has been found 

        addpath(MouseFolder); %adds folder to path so it can be acted upon -- need to do this every time for some reason 
        MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
        cd(MouseFolderDataPath); %makes the BH folder the current directory so that the dir function can be used on that folder
        MouseFolderFiles = dir(MouseFolderDataPath); %files in the BH folder 
        NumDateFiles = length(MouseFolderFiles); 
        Dates = zeros((NumDateFiles-2), 1); %intialize matrix   
        NameAndDate = cell((NumDateFiles-2), 2); %intialize cell

        for x = 3:NumDateFiles %for each date folder in the mouse folder 

            DateFile = MouseFolderFiles(x).name; %get name in string form 
            DateFilePath = strcat(MouseFolderDataPath, '\', DateFile); %concatenate string

            %parses out name/full date of the folder
            %puts into format that matlab can read 

            FirstChar = DateFile(1); 
            IsNum = str2num(FirstChar); 

      

            FirstComma = strfind(DateFilePath, ','); %find comma in string 
                
            if isempty(FirstComma) == 0 
                
                StartDateString = FirstComma(1) + 2; %starts the place in the string that is the beginning of the month 

                FindEnd = strfind(DateFilePath, 'PM'); %find end of string

                if isempty(FindEnd) == 1
                     FindEnd = strfind(DateFilePath, 'AM'); %if not AM then PM
                end 

                EndDateString = FindEnd-5; %take away AM/PM and seconds 
                DateString = DateFilePath(StartDateString:EndDateString); 

                Minutes= DateString(end-1:end); %parse out string
                Hour = DateString(end-3:end-2); 

                if Hour(1) == ' ' %if date is single digit then add zero in front

                    Hour(1) = '0'; 
                    DayYr = DateString(end-11:end-4);

                else 
                    DayYr = DateString(end-12:end-5);

                end 

                Time = strcat(Hour, ':', Minutes); 
                Month = DateString(1:3); 
                DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
                Date = strcat(Month, '.', DayYr); 
                Date = [Date, ' ', Time]; %places all the pieces together to fit the format below 

                format = 'mmm.dd,yyyy HH:MM'; 
                DateNum = datenum(Date); %matlab gives number specific to that exact time -- numerical = chronological order 
                DateNumString = num2str(DateNum); %turns number into string 

                Dates((x-2), 1) = DateNum; %places dates in array 

                DateCell = cellstr(DateNumString); 
                NameCell = cellstr(DateFile); %use cellstr because strings are different sizes  

                NameAndDate((x-2), 1) = DateCell; 
                NameAndDate((x-2), 2) = NameCell; %2x2 array of date numbers and date strings

            end 
        end
        
        Dates = nonzeros(Dates); 
        AscendDates = sort(Dates); %sort date numbers into ascending order 
        NumDates = length(Dates); 
        AscendFiles = cell(NumDates, 1); 

        for x = 1:NumDates %places dates strings in the same order as date numbers 

            FindIt = find(Dates == AscendDates(x));
            AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
        end

        AscendFiles = char(AscendFiles);
        ItNums = zeros(NumDates, 1);
         cd(MouseFolderDataPath); 

        for x = 1:NumDates 

            FirstChar = AscendFiles(x, 1); 
            SecondChar = AscendFiles(x, 2);
            IsNum = str2num(FirstChar);
            IsNumTwo = str2num(SecondChar);

            if isempty(IsNumTwo) == 0

                TwoDigits = strcat(FirstChar, SecondChar); 
                IsNum = str2num(TwoDigits); 

            end 

            if isempty(IsNum) == 0 

                if IsNum ~= x

                    OldName = AscendFiles(x, :); 
                    OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                    AscendFiles(x, 1) = num2str(x); 
                    RevisedName = AscendFiles(x, :);
                    RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                    movefile(OldNamePath, RevisedName);
                end 

            else 

            OldName = AscendFiles(x, :); 
            OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
            ItString = num2str(x); 
            NewName = strcat(ItString, AscendFiles(x, :));
            NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 

            movefile(OldNamePath, NewNamePath);            

            end

        end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = strfind(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    DataFile = dir('*.txt'); 
    
    if isempty(DataFile) == 0 
        
        NumTextFiles = length(DataFile); 
        NumDateFiles = NumDateFiles - NumTextFiles; 
        
    end
    
    for i = 3:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = strfind(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

FindSession = findstr(AnalysisPath, 'BH'); 
FindFirstNumber = AnalysisPath(FindSession + 6);
FindSecondNumber = AnalysisPath(FindSession + 7);
SecondNumber = str2num(FindSecondNumber);

if isempty(SecondNumber) == 0
    
    Session = strcat(FindFirstNumber, FindSecondNumber);
    SessionNumber = Session;
    
else
   
    SessionNumber = FindFirstNumber;
    
end
 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllDist = single.empty(500000, 0); 
 AllModes= single.empty(500000, 0); 
 AllStims = single.empty(500000, 0); 
 AllCenterLicks = single.empty(500000, 0); 
 AllRightLicks = single.empty(500000, 0); 
 AllLeftLicks = single.empty(500000, 0); 
 AllFixTimes = single.empty(500000, 0); 
 AllInitiated = single.empty(500000, 0); 
 AllITI = single.empty(500000, 0); 
 AllCorrectFree = single.empty(500000, 0); 
 AllCorrectEarned  = single.empty(500000, 0); 
 AllCompletes = single.empty(500000, 0); 
% AllStimSide(1:movnu) = StimSide;
%  AllCueSide(1:movnu) = CueSide;   
  AllTime = single.empty(500000, 0); 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(12*4+8);

if rem(movnu, 1) == 0 

fseek(movfile, 12*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile, 12*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 12);  
Zeros = zeros(1, 12); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 12 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:12)= StimInfo;
     
    fseek(movfile, 8 ,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end


DistTraveled = StimPos(:, 1);
TaskMode = StimPos(:, 2);
Stim = StimPos(:, 3);
CenterLicks = StimPos(:, 4); 
RightLicks = StimPos(:, 5);
LeftLicks = StimPos(:, 6);
ITI = StimPos(:, 7); 
SelfInitiated = StimPos(:, 8);
CenterFixTime = StimPos(:, 9);
CorrectFree = StimPos(:, 10);
CorrectEarned = StimPos(:, 11);
ITIComplete = StimPos(:, 12);
% StimSide = StimPos(:, 13);
% CueSide = StimPos(:, 14);
Time = Timer;



if x == StartIt
    
    AllDist(1:movnu) = DistTraveled;
    AllModes(1:movnu) = TaskMode;
    AllStims(1:movnu) = Stim;
    AllCenterLicks(1:movnu) = CenterLicks;
    AllRightLicks(1:movnu) = RightLicks;
    AllLeftLicks(1:movnu) = LeftLicks;
    AllFixTimes(1:movnu) = CenterFixTime;    
    AllInitiated(1:movnu) = SelfInitiated;
    AllITI(1:movnu) = ITI;    
    AllCorrectFree(1:movnu) = CorrectFree;
    AllCorrectEarned (1:movnu) = CorrectEarned;
    AllCompletes(1:movnu) = ITIComplete;
%     AllStimSide(1:movnu) = StimSide;
%     AllCueSide(1:movnu) = CueSide;   
    AllTime(1:movnu) = Time;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
   
    AllDist(StartFill: (StartFill+movnu) - 1) = DistTraveled;
    AllModes(StartFill: (StartFill+movnu) - 1) = TaskMode;
    AllStims(StartFill: (StartFill+movnu) - 1) = Stim;       
    AllCenterLicks(StartFill: (StartFill+movnu) - 1) = CenterLicks;  
    AllRightLicks(StartFill: (StartFill+movnu) - 1) = RightLicks; 
    AllLeftLicks(StartFill: (StartFill+movnu) - 1) = LeftLicks; 
    AllFixTimes(StartFill: (StartFill+movnu) - 1) = CenterFixTime;
    AllInitiated(StartFill: (StartFill+movnu) - 1) =  SelfInitiated;   
    AllITI(StartFill: (StartFill+movnu) - 1) = ITI;  
    AllCorrectFree(StartFill: (StartFill+movnu) - 1) = CorrectFree;
    AllCorrectEarned(StartFill: (StartFill+movnu) - 1) = CorrectEarned;
    AllCompletes(StartFill: (StartFill+movnu) - 1) = ITIComplete;
%     AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
%     AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllTime(StartFill: (StartFill+movnu) - 1) = Time;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

DistTraveled = AllDist';
TaskMode = AllModes'; 
Stim = AllStims';
RightLicks = AllRightLicks';
LeftLicks = AllLeftLicks';
CenterLicks = AllCenterLicks';
CenterFixTime = AllFixTimes'; 
SelfInitiated = AllInitiated'; 
ITI = AllITI'; 
CorrectFree = AllCorrectFree'; 
CorrectEarned = AllCorrectEarned'; 
ITIComplete = AllCompletes'; 
% StimSide = AllStimSide'; 
% CueSide = AllCueSide';  
Time = AllTime';
[r c] = size(DistTraveled); 


TotalLength = length(Stim);

TaskVersion = mode(TaskMode); 




if TaskVersion == 0 %center lick training
    
AvgITI = mean(ITI); 


FindCompleteITIs = find((ITIComplete(:, 1) == 1));   
NumITIs = length(FindCompleteITIs); 
CompleteITIs = zeros(NumITIs, 1); 

for i = 1:NumITIs
    
    if i == 1 
        CompleteITIs(i, 1) = FindCompleteITIs(i);  

    else
        if FindCompleteITIs(i)-FindCompleteITIs(i-1) < 10
        CompleteITIs(i, 1) = 0; 
    else 
        CompleteITIs(i, 1) = FindCompleteITIs(i);
    end 
    end 
end 

CompleteITIs = nonzeros(CompleteITIs);  
NumCompleteITIs = length(CompleteITIs); 




FindCorrectTrials = find((CorrectFree(:, 1) == 1));   
NumCorrect = length(FindCorrectTrials ); 
CorrectTrials = zeros(NumCorrect, 1); 

for i = 1:NumCorrect
    
    if i == 1 
        CorrectTrials(i, 1) = FindCorrectTrials(i);  

    else
        if FindCorrectTrials(i)-FindCorrectTrials(i-1) < 20
        CorrectTrials(i, 1) = 0; 
    else 
        CorrectTrials(i, 1) = FindCorrectTrials(i);
    end 
    end 
end 

CorrectTrials = nonzeros(CorrectTrials);  
NumCorrectTrials = length(CorrectTrials); 

EarnedCenterTrial = zeros(NumCorrectTrials, 1); 
AbortedTrials = zeros(NumCorrectTrials, 1);
InitiationLatencies = zeros(NumCorrectTrials, 1);
FixationLickRates = zeros(NumCorrectTrials, 1);

for i = 1:NumCompleteITIs-1
    
    %Check to make sure that Correct Trials were actually correct 
    FirstCenterLick = find(CenterLicks(CompleteITIs(i): CompleteITIs(i+1)) == 1); 
    
    if isempty(FirstCenterLick) == 0 
    
    FirstCenterLick = FirstCenterLick(1); 
    InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; 
    InitiationTime = Time(InitiationLick); 
    
    Fixation = CenterFixTime(InitiationLick)/1000; 
    EndFixationTime = InitiationTime + Fixation; 
    EndFixation = find(Time >= EndFixationTime); 
    EndFixation = EndFixation(1); 
    
    if Fixation > 0
    
         FixationLicks = CenterLicks(InitiationLick: EndFixation);
         NumFixLicks = length(nonzeros(FixationLicks)); 
         Rate = NumFixLicks/Fixation; 
         FixationLickRates(i) = Rate; 
    
    end
    
    RightAbortLick = find(RightLicks(InitiationLick:EndFixation)); 
    LeftAbortLick =  find(LeftLicks(InitiationLick:EndFixation)); 
    
    if isempty(RightAbortLick) == 1 ||  isempty(LeftAbortLick) == 1
        
         SelfInitiatedLick = find(CenterLicks(EndFixation: CompleteITIs(i+1)) == 1);
         
         if isempty(SelfInitiatedLick) == 0 
             
             SelfInitiatedLick = SelfInitiatedLick(1); 
             SelfLick = EndFixation + SelfInitiatedLick - 1; 
             Correct = find(CorrectTrials >= SelfLick); 

             if isempty(Correct) == 0

                 Correct = Correct(1); 

                if SelfLick <= CorrectTrials(Correct)

                    EarnedCenterTrial(i, 1) = CorrectTrials(Correct); 
                    
                    EndITITime = Time(CompleteITIs(i)); 
                    TimeToStartInitiation = InitiationTime - EndITITime; 
                    InitiationLatencies(i) = TimeToStartInitiation; 

                end 

             else

                  EarnedCenterTrial(i, 1) = 0; 

             end
         end
         
    else 
         
         AbortedTrials(i) = CompleteITIs(i); 
        
    end 
    
    else

        UnInitiatedTrials(i) = CompleteITIs(i);
        
    end
    
end 

EarnedCenterTrials = nonzeros(EarnedCenterTrial); 
NumEarnedCenterTrials = length(EarnedCenterTrials); 

AbortedTrials = nonzeros(AbortedTrials);
NumAbortedTrials = length(AbortedTrials); 

FixationLickRates = nonzeros(FixationLickRates); 
AvgFixLickRate = mean(FixationLickRates)

InitiationLatencies = nonzeros(InitiationLatencies); %does not include outlier trial where latency was 0
AvgInitiationLatency = mean(InitiationLatencies); 
NumLatencies = length(InitiationLatencies); 

CurrentDir = pwd; 
FindStart = strfind(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Forced Choice Task';
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

DirectoryExist = exist(DatePath, 'dir'); 

if DirectoryExist == 0 
    
    mkdir(MouseName, Date); 
    x = 1
    
end 

SavePath = strcat(AnalyzedPath, '\', SaveString); 
cd(SavePath); 

MouseDataPath = strcat(AnalyzedPath, '\', MouseName); 

AvgInitiateLickLatency = figure('name', 'Latency to Initiate Over Trials');
x = [1:NumLatencies]; 
x = x'; 
y = InitiationLatencies; 
plot(x, y); 
MeanLine = refline(0, AvgInitiationLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 
Fit = polyfit(x, y, 1);
plot(polyval(Fit, x))
hold on; 
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Latency to Initiate Over Trials'); 
title(Title); 
AvgLatency = num2str(AvgInitiationLatency); 
MeanLatency = strcat('Mean Latency = ', AvgLatency); 
legend('Latency Over Time', MeanLatency, 'Best Fit'); 
XLabel = 'Trials'; 
YLabel = 'Time'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Latency_to_Initiate_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgInitiateLickLatency); 


% 
% DataPath = 'D:\Brooke\Data\Self Initiated 2AFC'; 
% MousePath = strcat(DataPath, '\', MouseName); 
 cd(MouseDataPath);

Sesh = strcat('Session', SessionNumber); 

MouseDataFile = dir('*.txt'); 

if isempty(MouseDataFile) == 1
    
    fileID = fopen('MouseData.txt','a');
     formatSpec = '%s\n';
    fprintf(fileID, formatSpec, Sesh)
    dlmwrite('MouseData.txt', AvgInitiationLatency, '-append');
    fclose(fileID);
        
else 
    
     fileID = fopen('MouseData.txt','r'); 
    [MouseData Count] = fscanf(fileID, '%c'); 
    SessionsPresent = findstr(MouseData, 'Session')
    NumSessions = length(SessionsPresent);
    SeshNum = str2num(SessionNumber); 
    
    if NumSessions < SeshNum 
      
        fileID = fopen('MouseData.txt','a');
        formatSpec = '%s\n';
        fprintf(fileID, formatSpec, Sesh)
        dlmwrite('MouseData.txt', AvgInitiationLatency, '-append');
        fclose(fileID);
    
    end 
       
end 
    

end 



if TaskVersion == 1

AvgITI = mean(ITI); 


FindCompleteITIs = find((ITIComplete(:, 1) == 1));   
NumITIs = length(FindCompleteITIs); 
CompleteITIs = zeros(NumITIs, 1); 

for i = 1:NumITIs
    
    if i == 1 
        CompleteITIs(i, 1) = FindCompleteITIs(i);  

    else
        if FindCompleteITIs(i)-FindCompleteITIs(i-1) < 10
        CompleteITIs(i, 1) = 0; 
    else 
        CompleteITIs(i, 1) = FindCompleteITIs(i);
    end 
    end 
end 

CompleteITIs = nonzeros(CompleteITIs);  
NumCompleteITIs = length(CompleteITIs); 


NumITIs = length(ITI);
ITIs = zeros(NumITIs, 1);
NewITICreated = zeros(NumITIs, 1);


for i = 1:NumITIs
    
    if i == 1 
        ITIs(i, 1) = ITI(1);  

    else
        if ITI(i)- ITI(i-1) == 0 
            ITIs(i, 1) = 0; 
        else 
            ITIs(i, 1) = ITI(i);
            NewITICreated(i,1) = i; 
        end 
    end 
end 

ITIs = nonzeros(ITIs);  
NumITIs = length(ITIs); 
NewITICreated = nonzeros(NewITICreated); 



FindSelfInitiated = find((SelfInitiated(:, 1) == 1));   
NumInitiated= length(FindSelfInitiated); 
SelfInitiations = zeros(NumInitiated, 1); 

for i = 1:NumInitiated
    
    if i == 1 
        SelfInitiations(i, 1) = FindSelfInitiated(i);  

    else
        if FindSelfInitiated(i)-FindSelfInitiated(i-1) < 10
        SelfInitiations(i, 1) = 0; 
    else 
        SelfInitiations(i, 1) = FindSelfInitiated(i);
    end 
    end 
end 

SelfInitiations = nonzeros(SelfInitiations);  
NumInitiations = length(SelfInitiations); 



SelfInitiatedITIs = zeros(NumInitiations, 1); 

for i = 1: NumInitiations 

    SelfInitiatedITIs(i, 1) = ITI(SelfInitiations(i)); 

end 

NumInitiatedITIs = length(SelfInitiatedITIs); 



FindEarned = find((CorrectEarned(:, 1) == 1));   
NumEarned = length(FindEarned); 
EarnedTrials = zeros(NumEarned, 1); 

for i = 1:NumEarned
    
    if i == 1 
        EarnedTrials(i, 1) = FindEarned(i);  

    else
        if FindEarned(i)-FindEarned(i-1) < 100
        EarnedTrials(i, 1) = 0; 
    else 
        EarnedTrials(i, 1) = FindEarned(i);
    end 
    end 
end 

EarnedTrials = nonzeros(EarnedTrials);  
NumEarnedTrials = length(EarnedTrials); 


FindFree = find((CorrectFree(:, 1) == 1));   
NumFree = length(FindFree); 
FreeTrials = zeros(NumFree, 1); 

for i = 1:NumFree
    
    if i == 1 
        FreeTrials(i, 1) = FindFree(i);  

    else
        if FindFree(i)-FindFree(i-1) < 100
        FreeTrials(i, 1) = 0; 
    else 
        FreeTrials(i, 1) = FindFree(i);
    end 
    end 
end 

FreeTrials = nonzeros(FreeTrials);  
NumFreeTrials = length(FreeTrials); 

% SelfInitiatedITIs = SelfInitiatedITIs(2:end); 
% NumSelfInitiatedITIs = length(SelfInitiatedITIs); 
% SelfInitiations = SelfInitiations(2:end); 
% NumSelfInitiations = length(SelfInitiations); 

SuccessfulCenterTrial = zeros(NumCompleteITIs, 1); 
AbortedTrials = zeros(NumCompleteITIs, 1);
InitiationLatencies = zeros(NumCompleteITIs, 1);
FixationLickRates = zeros(NumCompleteITIs, 1);
UnInitiatedTrials =  zeros(NumCompleteITIs, 1);

if isempty(SelfInitiatedITIs) == 0

x = 0; 

for i = 1:NumCompleteITIs-1 %categorize ITIs into completed, uninitiated, or aborted
    
    CurrentITI = ITI(CompleteITIs(i));     
     WasITIInitiated = find(SelfInitiatedITIs == CurrentITI); 
    
    if isempty(WasITIInitiated) == 0 
        
        x = x + 1; 
        FindWhenITIComplete = find(CompleteITIs < SelfInitiations(x)); 
        Complete =  FindWhenITIComplete(end);
        ITIComplete = CompleteITIs(Complete); 
        SuccessfulCenterTrial(i) =  SelfInitiations(x); 
        ITITime = Time(CompleteITIs(i)); 

        CenterLicking = find(CenterLicks(ITIComplete: SelfInitiations(x)) == 1);
        FirstCenterLick = CenterLicking(1);  %first center lick      
        InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; %iteration of the lick 
        InitiationTime = Time(InitiationLick); %lick time
        InitiationLatency = InitiationTime - ITITime; 
        InitiationLatencies(i) = InitiationLatency;

        Fixation = CenterFixTime(InitiationLick)/1000; 
        EndFixationTime = InitiationTime + Fixation; 
        EndFixation = find(Time >= EndFixationTime); 
        EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)

        FixationLicks = CenterLicks(InitiationLick: EndFixation);
        NumFixLicks = length(nonzeros(FixationLicks)); 
        Rate = NumFixLicks/Fixation; 
        FixationLickRates(i) = Rate; 
        
    else 
        
        FirstCenterLick = find(CenterLicks(CompleteITIs(i): CompleteITIs(i+1)) == 1); %find licks after trial onset 
        FirstRightLick = find(RightLicks(CompleteITIs(i): CompleteITIs(i+1)) == 1); 
        FirstLeftLick = find(LeftLicks(CompleteITIs(i): CompleteITIs(i+1)) == 1); 

        if isempty(FirstCenterLick) == 0 %if licked at center after the ITI

            FirstCenterLick = FirstCenterLick(1);  %first center lick      
            InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; %iteration of the lick 
            InitiationTime = Time(InitiationLick); %lick time 

            Fixation = CenterFixTime(InitiationLick)/1000; 
            EndFixationTime = InitiationTime + Fixation; 
            EndFixation = find(Time >= EndFixationTime); 
            EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)

             if isempty(FirstRightLick) == 0  %if there was a right lick 

                 FirstRightLick =  FirstRightLick(1); 
                 RightLick = FirstRightLick+ CompleteITIs(i) - 1; 

                 if RightLick < InitiationLick    %did it occur before the center lick           
                      AbortedTrials(i) = CompleteITIs(i);                                  
                 else

                     if RightLick < EndFixation   %if it occurred after, did it occur before the end of the fixation period                
                         AbortedTrials(i) = CompleteITIs(i);                   
                     end 
                 end 
             end 

             if  isempty(FirstLeftLick) == 0  %if there was a left lick, same analysis 

                FirstLeftLick =  FirstLeftLick(1); 
                LeftLick = FirstLeftLick+ CompleteITIs(i) - 1;  

                 if LeftLick < InitiationLick                
                      AbortedTrials(i) = CompleteITIs(i);                                  
                 else

                     if LeftLick < EndFixation                      
                         AbortedTrials(i) = CompleteITIs(i);                   
                     end 
                 end 
             end 

             if AbortedTrials(i) == 0   %if there were no side licks 

                SelfInitiatedLicks = find(CenterLicks(EndFixation: CompleteITIs(i+1)) == 1); %find the lick that confirmed self initiation
                RightAbortLicks =  find(RightLicks(EndFixation: CompleteITIs(i+1)) == 1);
                LeftAbortLicks =  find(LeftLicks(EndFixation: CompleteITIs(i+1)) == 1);

                 if isempty(SelfInitiatedLicks) == 0 %if there was a confirming lick 

                     SelfInitiatedLick = SelfInitiatedLicks(1); 
                     SelfLick = EndFixation + SelfInitiatedLick - 1; %iteration of the lick 

                      if isempty(RightAbortLicks) == 0 

                            RightAbortLick = RightAbortLicks(1); 

                            if RightAbortLick < SelfLick                          
                                AbortedTrials(i) = CompleteITIs(i);                            
                            end 
                      end 

                      if isempty(LeftAbortLicks) == 0 

                            LeftAbortLick = LeftAbortLicks(1); 

                            if LeftAbortLick < SelfLick                          
                                AbortedTrials(i) = CompleteITIs(i);                            
                            end 
                      end 

                 else 
                     UnInitiatedTrials(i) = CompleteITIs(i);
                 end
             end 
        else 

            if isempty(FirstLeftLick) == 0 || isempty(FirstRightLick) == 0
                AbortedTrials(i) = CompleteITIs(i); 

            else 
                 UnInitiatedTrials(i) = CompleteITIs(i); 

            end
        end                            
    end  
end 

else 
    
    AllTrials = [FreeTrials; EarnedTrials]; 
    AllTrials = sort(AllTrials, 'ascend'); 
    NumAllTrials = length(AllTrials); 
    
    for i = 1:NumAllTrials 
        
        if i == 1 
        AllTrials(i, 1) = AllTrials(i);  

        else
            if AllTrials(i)-AllTrials(i-1) < 50
            AllTrials(i, 1) = 0; 
        else 
            AllTrials(i, 1) = AllTrials(i);
        end 
        end 
    end 
    
    AllTrials = nonzeros(AllTrials); 
    NumAllTrials = length(AllTrials); 
    

    SuccessfulITIs = zeros(NumAllTrials, 1); 

    for i = 1:NumAllTrials

       SuccessfulITIs(i) = ITI(AllTrials(i));      
    end 
    
    ITIsCompleted = zeros(NumCompleteITIs, 1); 
    
    for i = 1:NumCompleteITIs-1
        
        ITIsCompleted(i) = ITI(CompleteITIs(i)); 
        
    end 

    x = 0; 
    
    for i= 1:NumCompleteITIs-1
        
        
        Interval = ITIsCompleted(i); 
        WasSuccessful = find(SuccessfulITIs == Interval); 
        
        if isempty(WasSuccessful) == 0 
            
            TrialComplete = AllTrials(WasSuccessful); 
            CenterLicking = find(CenterLicks(CompleteITIs(i): TrialComplete));
            ITITime = Time(CompleteITIs(i)); 
            
            FirstCenterLick = CenterLicking(1);  %first center lick      
            InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; %iteration of the lick 
            InitiationTime = Time(InitiationLick); %lick time
            InitiationLatency = InitiationTime - ITITime; 
            InitiationLatencies(i) = InitiationLatency;

            Fixation = CenterFixTime(InitiationLick)/1000; 
            EndFixationTime = InitiationTime + Fixation; 
            EndFixation = find(Time >= EndFixationTime); 
            EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)

            FixationLicks = CenterLicks(InitiationLick: EndFixation);
            NumFixLicks = length(nonzeros(FixationLicks)); 
            Rate = NumFixLicks/Fixation; 
            FixationLickRates(i) = Rate; 
            
            SelfInitiatedLick = find(CenterLicks(EndFixation:TrialComplete)); 
            SelfInitiatedLick =  SelfInitiatedLick(1); 
            SelfInitiated = SelfInitiatedLick + EndFixation - 1; 
            SuccessfulCenterTrial(i) = SelfInitiated; 
                        
        else
            
            CenterLicking = find(CenterLicks(CompleteITIs(i): CompleteITIs(i+1)));
            RightLicking = find(RightLicks(CompleteITIs(i): CompleteITIs(i+1)));
            LeftLicking = find(LeftLicks(CompleteITIs(i): CompleteITIs(i+1)));
            
            if isempty(CenterLicking) == 0
                
                if isempty(RightLicking) == 0 || isempty(LeftLicking) == 0
                  
                    AbortedTrials(i) = CompleteITIs(i);                
                end                                             
            else 
                
                 if isempty(RightLicking) == 0 || isempty(LeftLicking) == 0
                  
                    AbortedTrials(i) = CompleteITIs(i);  
                    
                 else
                     
                     UnInitiatedTrials(i) = CompleteITIs(i);     
                     
                 end                                                           
            end                       
        end        
    end 
    
end


SuccessfulCenterTrials = nonzeros(SuccessfulCenterTrial); 
NumSuccessfulCenterTrials = length(SuccessfulCenterTrials); 

AbortedTrials = nonzeros(AbortedTrials);
NumAbortedTrials = length(AbortedTrials); 

UnInitiatedTrials = nonzeros(UnInitiatedTrials); 
NumUnInitiatedTrials = length(UnInitiatedTrials); 

FixationLickRates = nonzeros(FixationLickRates); 
AvgFixLickRate = mean(FixationLickRates)

InitiationLatencies = nonzeros(InitiationLatencies); %does not include outlier trial where latency was 0
AvgInitiationLatency = mean(InitiationLatencies); 
NumLatencies = length(InitiationLatencies); 

CurrentDir = pwd; 
FindStart = strfind(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Forced Choice Task';
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(AnalyzedPath, '\', SaveString); 
cd(SavePath); 

AvgInitiateLickLatency = figure('name', 'Latency to Initiate Over Trials');
x = [1:NumLatencies]; 
x = x'; 
y = InitiationLatencies; 
plot(x, y); 
MeanLine = refline(0, AvgInitiationLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 
Fit = polyfit(x, y, 1);
plot(polyval(Fit, x))
hold on
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Latency to Initiate Over Trials'); 
title(Title); 
MeanLatency = num2str(AvgInitiationLatency); 
MeanLatency = strcat('Mean Latency = ', MeanLatency); 
legend('Latency Over Time', MeanLatency); 
XLabel = 'Time'; 
YLabel = 'Trial'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Latency_to_Initiate_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgInitiateLickLatency); 




DiagStim = zeros(NumSuccessfulCenterTrials, 1); 
VertStim = zeros(NumSuccessfulCenterTrials, 1); 
VertLickLatencies =  zeros(NumSuccessfulCenterTrials, 1); 
DiagLickLatencies = zeros(NumSuccessfulCenterTrials, 1);

DiagFreeMiss = zeros(NumSuccessfulCenterTrials, 1);
VertFreeMiss = zeros(NumSuccessfulCenterTrials, 1);
DiagFreeHits = zeros(NumSuccessfulCenterTrials, 1);
VertFreeHits = zeros(NumSuccessfulCenterTrials, 1);

DiagEarnedMiss = zeros(NumSuccessfulCenterTrials, 1);
VertEarnedMiss = zeros(NumSuccessfulCenterTrials, 1);
DiagEarnedHits = zeros(NumSuccessfulCenterTrials, 1);
VertEarnedHits = zeros(NumSuccessfulCenterTrials, 1);

VertCorrectFirstChoice = zeros(NumSuccessfulCenterTrials, 1);
DiagCorrectFirstChoice = zeros(NumSuccessfulCenterTrials, 1);


for i = 1:NumSuccessfulCenterTrials
    
   TrialIt = SuccessfulCenterTrials(i); 
   StimType = Stim(TrialIt:TrialIt + 10); 
   StimType = mode(StimType); 
   
   if StimType == 0 %diagonal 
       
       DiagStim(i) = TrialIt;
       StimTime = Time(TrialIt);      
       
       LickWindow = find(Time >= StimTime + 2); 
       EndWindow = LickWindow(1); 
       DiagLicks = LeftLicks(TrialIt: EndWindow); 
       
       CorrectLick = find(DiagLicks == 1); 
       
       if isempty(CorrectLick) == 0 
       
           CorrectLick = CorrectLick(1); 
           LickIt = TrialIt + CorrectLick - 1; 
           LickTime = Time(LickIt); 
           LickLatency = LickTime - StimTime; 

           DiagLickLatencies(i) = LickLatency;
           OtherLicks = RightLicks(TrialIt: EndWindow); 
           OtherLick = find(OtherLicks == 1); 

                       if isempty(OtherLick) == 0  

                           OtherLick = OtherLick(1);
                           OtherLickIt = TrialIt + OtherLick - 1; 

                           if OtherLickIt > LickIt

                               DiagCorrectFirstChoice(i) = EarnedIt; 

                           end 

                       else 

                           DiagCorrectFirstChoice(i) = EarnedIt; 

                       end                                
           
            
        IsFree = find(FreeTrials > TrialIt); 
           
           if isempty(IsFree) == 0 
               
               IsFree = IsFree(1);
               FreeIt = FreeTrials(IsFree);
               FreeIt - TrialIt;

               if FreeIt - TrialIt < 100 

                   DiagFreeHits(i) = FreeIt;                                    
                   
               end
               
           end 
           if  DiagFreeHits(i) == 0
               
               IsEarned = find(EarnedTrials > TrialIt); 
               
               if isempty(IsEarned) == 0 
                   
                   IsEarned = IsEarned(1); 
                   EarnedIt = EarnedTrials(IsEarned); 
                   EarnedIt - TrialIt;

                   if EarnedIt - TrialIt < 100 

                       DiagEarnedHits(i) = EarnedIt;
                                        
                   end   
               end 
           end 
           
       else 
           
            IsFree = find(FreeTrials > TrialIt); 
           
           if isempty(IsFree) == 0 
               
               IsFree = IsFree(1);
               FreeIt = FreeTrials(IsFree); 
               FreeIt - TrialIt;

               if FreeIt - TrialIt < 100 

                   DiagFreeMiss(i) = FreeIt;
                   
               end              
           end 
           
           if DiagFreeMiss(i) == 0 

               DiagEarnedMiss(i) = EarnedIt;
                          
           end 
           
       end 
       
   end 
    
   if StimType == 1 %vertical 
       
       VertStim(i) = TrialIt; 
       
       StimTime = Time(TrialIt); 
       LickWindow = find(Time >= StimTime + 2); 
       EndWindow = LickWindow(1); 
       VertLicks = RightLicks(TrialIt: EndWindow); 
       
       CorrectLick = find(VertLicks == 1); 
       
       if isempty(CorrectLick) == 0 
                    
           CorrectLick = CorrectLick(1); 
           LickIt = TrialIt + CorrectLick - 1; 
           LickTime = Time(LickIt); 
           LickLatency = LickTime - StimTime; 

           VertLickLatencies(i) = LickLatency; 
           
            
                   OtherLicks = LeftLicks(TrialIt: EndWindow); 
                   OtherLick = find(OtherLicks == 1); 
                   
                   if isempty(OtherLick) == 0  
                       
                       OtherLick = OtherLick(1);
                       OtherLickIt = TrialIt + OtherLick - 1; 

                       if OtherLickIt > LickIt
                           
                           VertCorrectFirstChoice(i) = EarnedIt; 
                           
                       end 
                   
                   else 
                       
                       VertCorrectFirstChoice(i) = EarnedIt; 
                       
                   end           
           
           IsFree = find(FreeTrials > TrialIt); 
           
           if isempty(IsFree) == 0 
               
               IsFree = IsFree(1);
               FreeIt = FreeTrials(IsFree); 
               FreeIt - TrialIt;

               if FreeIt - TrialIt < 110 

                   VertFreeHits(i) = FreeIt;
                   
               end               
           
           end 
           
            if  VertFreeHits(i) == 0
               
               IsEarned = find(EarnedTrials > TrialIt); 
               
               if isempty(IsEarned) == 0 
               IsEarned = IsEarned(1); 
               EarnedIt = EarnedTrials(IsEarned); 
               EarnedIt - TrialIt;

               if EarnedIt - TrialIt < 100 

                   VertEarnedHits(i) = EarnedIt;
                                                               
               end  
               
               end 
           end 
           
       else
           
           IsFree = find(FreeTrials > TrialIt); 
           
           if isempty(IsFree) == 0 
               
                IsFree = IsFree(1);
               FreeIt = FreeTrials(IsFree); 
               FreeIt - TrialIt;

                if FreeIt - TrialIt  < 100 

                   VertFreeMiss(i) = FreeIt;
                   

                end 
           end 
            
           if VertFreeMiss(i) == 0
               
                IsEarned = find(EarnedTrials > TrialIt);              
               
               if isempty(IsEarned) == 0
                   
                   IsEarned = IsEarned(1); 
                   EarnedIt = EarnedTrials(IsEarned);
                   EarnedIt - TrialIt;

                   if EarnedIt - TrialIt < 100 

                       VertEarnedMiss(i) = EarnedIt; 

                   end   
               end
           end 
       end 
       
   end 
    
end 

DiagStim = nonzeros(DiagStim); 
NumDiagStim = length(DiagStim); 

DiagFreeMiss = nonzeros(DiagFreeMiss); 
NumDiagFreeMiss = length(DiagFreeMiss);
DiagFreeHits = nonzeros(DiagFreeHits); 
NumDiagFreeHits = length(DiagFreeHits);
DiagEarnedMiss = nonzeros(DiagEarnedMiss); 
NumDiagEarnedMiss = length(DiagEarnedMiss);
DiagEarnedHits = nonzeros(DiagEarnedHits); 
NumDiagEarnedHits = length(DiagEarnedHits);

VertStim = nonzeros(VertStim); 
NumVertStim = length(VertStim);

VertFreeMiss = nonzeros(VertFreeMiss); 
NumVertFreeMiss = length(VertFreeMiss);
VertFreeHits = nonzeros(VertFreeHits); 
NumVertFreeHits = length(VertFreeHits);
VertEarnedMiss = nonzeros(VertEarnedMiss); 
NumVertEarnedMiss = length(VertEarnedMiss);
VertEarnedHits = nonzeros(VertEarnedHits); 
NumVertEarnedHits = length(VertEarnedHits);

VertLickLatencies = nonzeros(VertLickLatencies); 
AvgVertLatency = mean(VertLickLatencies); 
NumVertLatencies = length(VertLickLatencies); 

DiagLickLatencies = nonzeros(DiagLickLatencies); 
AvgDiagLatency = mean(DiagLickLatencies); 
NumDiagLatencies = length(DiagLickLatencies); 

DiagCorrectFirstChoice = nonzeros(DiagCorrectFirstChoice); 
NumDiagFirstChoice = length(DiagCorrectFirstChoice); 
VertCorrectFirstChoice = nonzeros(VertCorrectFirstChoice);
NumVertFirstChoice = length(VertCorrectFirstChoice); 

VertFirstChoiceRate = NumVertFirstChoice/NumVertStim; 
DiagFirstChoiceRate = NumDiagFirstChoice/NumDiagStim; 


RewardsVsMisses = figure('name', 'Received Versus Missed Rewards');
VertFree = [NumVertFreeHits NumVertFreeMiss]; 
VertEarned = [NumVertEarnedHits NumVertEarnedMiss]; 
DiagFree = [NumDiagFreeHits NumDiagFreeMiss]; 
DiagEarned = [NumDiagEarnedHits NumDiagEarnedMiss]; 
AllRatios = [VertFree; VertEarned; DiagFree; DiagEarned]; 
bar(AllRatios, 'stacked');
set(gca,'XTickLabel',{'Vert Free', 'Vert Earned', 'Diag Free', 'Diag Earned'})

hold on; 
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Received Versus Missed Rewards'); 
title(Title); 
legend('Reward Received', 'Reward Missed'); 
YLabel = 'Trials';  
ylabel(YLabel);

FigureSaveName = 'Received_Versus_Missed_Rewards.png'; 
saveas(gcf, FigureSaveName); 
close(RewardsVsMisses); 



AvgVertLickLatency = figure('name', 'Vertical Lick Latency Over Trials');
x = [1:NumVertLatencies]; 
plot(x, VertLickLatencies); 
MeanLine = refline(0, AvgVertLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Vertical Lick Latency Over Trials'); 
title(Title); 
MeanVertLatency = num2str(AvgVertLatency); 
MeanLatency = strcat('Mean Latency = ', MeanVertLatency); 
legend('Latency Over Time', MeanLatency); 
XLabel = 'Time'; 
YLabel = 'Trial'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Vertical_Lick_Latency_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgVertLickLatency); 



AvgDiagLickLatency = figure('name', 'Diagonal Lick Latency Over Trials');
x = [1:NumDiagLatencies]; 
plot(x, DiagLickLatencies); 
MeanLine = refline(0, AvgDiagLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Diagonal Lick Latency Over Trials'); 
title(Title); 
MeanDiagLatency = num2str(AvgDiagLatency); 
MeanLatency = strcat('Mean Latency = ', MeanDiagLatency); 
legend('Latency Over Time', MeanLatency); 
XLabel = 'Time'; 
YLabel = 'Trial'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Diagonal_Lick_Latency_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgDiagLickLatency); 


FirstChoiceRates = figure('name', 'FirstChoiceRates');
AllRates = [DiagFirstChoiceRate VertFirstChoiceRate]; 
bar(AllRates);
set(gca,'XTickLabel',{'Diagonal Stim', 'Vertical Stim'})
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'First Choice Rates'); 
title(Title); 
legend('First Choice Rate'); 
YLabel = 'Rate'; 
ylabel(YLabel);

FigureSaveName = 'First_Choice_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(FirstChoiceRates); 

VertFirstChoices = num2str(VertFirstChoiceRate); 
DiagFirstChoices = num2str(DiagFirstChoiceRate); 

% DataPath = 'D:\Brooke\Data\Self Initiated 2AFC'; 
% MousePath = strcat(DataPath, '\', MouseName); 
% cd(MousePath);

MouseDataPath = strcat(AnalyzedPath, '\', MouseName); 
cd(MouseDataPath); 
Sesh = strcat('Session', SessionNumber); 

MouseDataFile = dir('*.txt'); 

if isempty(MouseDataFile) == 1
    
    fileID = fopen('MouseData.txt','a');
     formatSpec = '%s\n';
    fprintf(fileID, formatSpec, Sesh)
     fprintf(fileID, formatSpec, AvgInitiationLatency)
        fprintf(fileID, formatSpec, MeanVertLatency)
        fprintf(fileID, formatSpec, MeanDiagLatency)
        fprintf(fileID, formatSpec, VertFirstChoices)
        fprintf(fileID, formatSpec, DiagFirstChoices)
    fclose(fileID);
        
else 
    
     fileID = fopen('MouseData.txt','r'); 
    [MouseData Count] = fscanf(fileID, '%c'); 
    SessionsPresent = findstr(MouseData, 'Session')
    NumSessions = length(SessionsPresent);
    SeshNum = str2num(SessionNumber); 
    fclose(fileID); 
    
    if NumSessions < SeshNum 
      
        fileID = fopen('MouseData.txt','a');
        formatSpec = '%s\n';
        fprintf(fileID, formatSpec, Sesh)
        fprintf(fileID, formatSpec, AvgInitiationLatency)
        fprintf(fileID, formatSpec, MeanVertLatency)
        fprintf(fileID, formatSpec, MeanDiagLatency)
        fprintf(fileID, formatSpec, VertFirstChoices)
        fprintf(fileID, formatSpec, DiagFirstChoices)
        fclose(fileID);
    
    end 
       
end 
    

end 



if TaskVersion == 2
    
AvgITI = mean(ITI); 


FindCompleteITIs = find((ITIComplete(:, 1) == 1));   
NumITIs = length(FindCompleteITIs); 
CompleteITIs = zeros(NumITIs, 1); 

for i = 1:NumITIs
    
    if i == 1 
        CompleteITIs(i, 1) = FindCompleteITIs(i);  

    else
        if FindCompleteITIs(i)-FindCompleteITIs(i-1) < 10
        CompleteITIs(i, 1) = 0; 
    else 
        CompleteITIs(i, 1) = FindCompleteITIs(i);
    end 
    end 
end 

CompleteITIs = nonzeros(CompleteITIs);  
NumCompleteITIs = length(CompleteITIs); 


NumITIs = length(ITI);
ITIs = zeros(NumITIs, 1);
NewITICreated = zeros(NumITIs, 1);


for i = 1:NumITIs
    
    if i == 1 
        ITIs(i, 1) = ITI(1);  

    else
        if ITI(i)- ITI(i-1) == 0 
            ITIs(i, 1) = 0; 
        else 
            ITIs(i, 1) = ITI(i);
            NewITICreated(i,1) = i; 
        end 
    end 
end 

ITIs = nonzeros(ITIs);  
NumITIs = length(ITIs); 
NewITICreated = nonzeros(NewITICreated); 



FindSelfInitiated = find((SelfInitiated(:, 1) == 1));   
NumInitiated= length(FindSelfInitiated); 
SelfInitiations = zeros(NumInitiated, 1); 

for i = 1:NumInitiated
    
    if i == 1 
        SelfInitiations(i, 1) = FindSelfInitiated(i);  

    else
        if FindSelfInitiated(i)-FindSelfInitiated(i-1) < 10
        SelfInitiations(i, 1) = 0; 
    else 
        SelfInitiations(i, 1) = FindSelfInitiated(i);
    end 
    end 
end 

SelfInitiations = nonzeros(SelfInitiations);  
NumInitiations = length(SelfInitiations); 



SelfInitiatedITIs = zeros(NumInitiations, 1); 

for i = 1: NumInitiations 

    SelfInitiatedITIs(i, 1) = ITI(SelfInitiations(i)); 

end 

NumInitiatedITIs = length(SelfInitiatedITIs); 



FindForced = find((CorrectEarned(:, 1) == 1));   
NumForced = length(FindForced); 
ForcedChoiceTrials = zeros(NumForced, 1); 

for i = 1:NumForced
    
    if i == 1 
        ForcedChoiceTrials(i, 1) = FindForced(i);  

    else
        if FindForced(i)-FindForced(i-1) < 100
        ForcedChoiceTrials(i, 1) = 0; 
    else 
        ForcedChoiceTrials(i, 1) = FindForced(i);
    end 
    end 
end 

ForcedChoiceTrials = nonzeros(ForcedChoiceTrials);  
NumEarnedTrials = length(ForcedChoiceTrials); 


FindFreeChoice = find((CorrectFree(:, 1) == 1));   
NumFreeChoice = length(FindFreeChoice); 
FreeChoiceTrials = zeros(NumFreeChoice, 1); 

for i = 1:NumFreeChoice
    
    if i == 1 
        FreeChoiceTrials(i, 1) = FindFreeChoice(i);  

    else
        if FindFreeChoice(i)-FindFreeChoice(i-1) < 100
        FreeTrials(i, 1) = 0; 
    else 
        FreeChoiceTrials(i, 1) = FindFreeChoice(i);
    end 
    end 
end 

FreeChoiceTrials = nonzeros(FreeChoiceTrials);  
NumFreeChoiceTrials = length(FreeChoiceTrials); 
% 
% SelfInitiatedITIs = SelfInitiatedITIs(2:end); 
% NumSelfInitiatedITIs = length(SelfInitiatedITIs); 
% SelfInitiations = SelfInitiations(2:end); 
% NumSelfInitiations = length(SelfInitiations); 

SuccessfulCenterTrial = zeros(NumCompleteITIs, 1); 
AbortedTrials = zeros(NumCompleteITIs, 1);
InitiationLatencies = zeros(NumCompleteITIs, 1);
FixationLickRates = zeros(NumCompleteITIs, 1);
UnInitiatedTrials =  zeros(NumCompleteITIs, 1);

if isempty(SelfInitiatedITIs) == 0

x = 0; 

for i = 1:NumCompleteITIs-1 %categorize ITIs into completed, uninitiated, or aborted
    
    CurrentITI = ITI(CompleteITIs(i));     
     WasITIInitiated = find(SelfInitiatedITIs == CurrentITI); 
    
    if isempty(WasITIInitiated) == 0 
        
        x = x + 1; 
        FindWhenITIComplete = find(CompleteITIs < SelfInitiations(x)); 
        Complete =  FindWhenITIComplete(end);
        ITIComplete = CompleteITIs(Complete); 
        SuccessfulCenterTrial(i) =  SelfInitiations(x); 
        ITITime = Time(CompleteITIs(i)); 

        SelfIt = SelfInitiations(x); 
        CenterLicking = find(CenterLicks(ITIComplete: SelfIt) == 1);
        FirstCenterLick = CenterLicking(1);  %first center lick      
        InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; %iteration of the lick 
        InitiationTime = Time(InitiationLick); %lick time
        InitiationLatency = InitiationTime - ITITime; 
        InitiationLatencies(i) = InitiationLatency;

        Fixation = CenterFixTime(InitiationLick)/1000; 
        EndFixationTime = InitiationTime + Fixation; 
        EndFixation = find(Time >= EndFixationTime); 
        EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)

        FixationLicks = CenterLicks(InitiationLick: EndFixation);
        NumFixLicks = length(nonzeros(FixationLicks)); 
        Rate = NumFixLicks/Fixation; 
        FixationLickRates(i) = Rate; 
        
    else 
        
        FirstCenterLick = find(CenterLicks(CompleteITIs(i): CompleteITIs(i+1)) == 1); %find licks after trial onset 

        if isempty(FirstCenterLick) == 0 %if licked at center after the ITI

            FirstCenterLick = FirstCenterLick(1);  %first center lick      
            InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; %iteration of the lick 
            InitiationTime = Time(InitiationLick); %lick time 

            Fixation = CenterFixTime(InitiationLick)/1000; 
            EndFixationTime = InitiationTime + Fixation; 
            EndFixation = find(Time >= EndFixationTime); 
            EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)
            
            FirstRightLick = find(RightLicks(CompleteITIs(i): EndFixation) == 1); 
            FirstLeftLick = find(LeftLicks(CompleteITIs(i): EndFixation) == 1); 

             if isempty(FirstRightLick) == 0  %if there was a right lick 

                 FirstRightLick =  FirstRightLick(1); 
                 RightLick = FirstRightLick+ CompleteITIs(i) - 1; 

                 if RightLick < InitiationLick    %did it occur before the center lick           
                      AbortedTrials(i) = CompleteITIs(i);                                  
                 else

                     if RightLick < EndFixation   %if it occurred after, did it occur before the end of the fixation period                
                         AbortedTrials(i) = CompleteITIs(i);                   
                     end 
                 end 
             end 

             if  isempty(FirstLeftLick) == 0  %if there was a left lick, same analysis 

                FirstLeftLick =  FirstLeftLick(1); 
                LeftLick = FirstLeftLick+ CompleteITIs(i) - 1;  

                 if LeftLick < InitiationLick                
                      AbortedTrials(i) = CompleteITIs(i);                                  
                 else

                     if LeftLick < EndFixation                      
                         AbortedTrials(i) = CompleteITIs(i);                   
                     end 
                 end 
             end 

             if AbortedTrials(i) == 0   %if there were no side licks 
                 %need to look between end fixation and comfirmed self
                 %initiation separately from between end of ITI and end
                 %fixation (instead of as a whole)
                 %because early aborting licks would have end the trial

                SelfInitiatedLicks = find(CenterLicks(EndFixation: CompleteITIs(i+1)) == 1); %find the lick that confirmed self initiation
                RightAbortLicks =  find(RightLicks(EndFixation: CompleteITIs(i+1)) == 1);
                LeftAbortLicks =  find(LeftLicks(EndFixation: CompleteITIs(i+1)) == 1);

                 if isempty(SelfInitiatedLicks) == 0 %if there was a confirming lick 

                     SelfInitiatedLick = SelfInitiatedLicks(1); 
                     SelfLick = EndFixation + SelfInitiatedLick - 1; %iteration of the lick 

                      if isempty(RightAbortLicks) == 0 

                            RightAbortLick = RightAbortLicks(1); 

                            if RightAbortLick < SelfLick                          
                                AbortedTrials(i) = CompleteITIs(i);                            
                            end 
                      end 

                      if isempty(LeftAbortLicks) == 0 

                            LeftAbortLick = LeftAbortLicks(1); 

                            if LeftAbortLick < SelfLick                          
                                AbortedTrials(i) = CompleteITIs(i);                            
                            end 
                      end 

                 else 
                     UnInitiatedTrials(i) = CompleteITIs(i);
                 end
             end 
        else 

            if isempty(FirstLeftLick) == 0 || isempty(FirstRightLick) == 0
                AbortedTrials(i) = CompleteITIs(i); 

            else 
                 UnInitiatedTrials(i) = CompleteITIs(i); 

            end
        end                            
    end  
end 

else 
    
    AllTrials = [FreeChoiceTrials; ForcedChoiceTrials]; 
    AllTrials = sort(AllTrials, 'ascend'); 
    NumAllTrials = length(AllTrials); 
    
    for i = 1:NumAllTrials 
        
        if i == 1 
        AllTrials(i, 1) = AllTrials(i);  

        else
            if AllTrials(i)-AllTrials(i-1) < 50
            AllTrials(i, 1) = 0; 
        else 
            AllTrials(i, 1) = AllTrials(i);
        end 
        end 
    end 
    
    AllTrials = nonzeros(AllTrials); 
    NumAllTrials = length(AllTrials); 
    

    SuccessfulITIs = zeros(NumAllTrials, 1); 

    for i = 1:NumAllTrials

       SuccessfulITIs(i) = ITI(AllTrials(i));      
    end 
    
    ITIsCompleted = zeros(NumCompleteITIs, 1); 
    
    for i = 1:NumCompleteITIs-1
        
        ITIsCompleted(i) = ITI(CompleteITIs(i)); 
        
    end 

    x = 0; 
    
    for i= 1:NumCompleteITIs-1
        
        
        Interval = ITIsCompleted(i); 
        WasSuccessful = find(SuccessfulITIs == Interval); 
        
        if isempty(WasSuccessful) == 0 
            
            TrialComplete = AllTrials(WasSuccessful); 
            CenterLicking = find(CenterLicks(CompleteITIs(i): TrialComplete));
            ITITime = Time(CompleteITIs(i)); 
            
            FirstCenterLick = CenterLicking(1);  %first center lick      
            InitiationLick = FirstCenterLick + CompleteITIs(i) - 1; %iteration of the lick 
            InitiationTime = Time(InitiationLick); %lick time
            InitiationLatency = InitiationTime - ITITime; 
            InitiationLatencies(i) = InitiationLatency;

            Fixation = CenterFixTime(InitiationLick)/1000; 
            EndFixationTime = InitiationTime + Fixation; 
            EndFixation = find(Time >= EndFixationTime); 
            EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)

            FixationLicks = CenterLicks(InitiationLick: EndFixation);
            NumFixLicks = length(nonzeros(FixationLicks)); 
            Rate = NumFixLicks/Fixation; 
            FixationLickRates(i) = Rate; 
            
            SelfInitiatedLick = find(CenterLicks(EndFixation:TrialComplete)); 
            SelfInitiatedLick =  SelfInitiatedLick(1); 
            SelfInitiated = SelfInitiatedLick + EndFixation - 1; 
            SuccessfulCenterTrial(i) = SelfInitiated; 
                        
        else
            
            CenterLicking = find(CenterLicks(CompleteITIs(i): CompleteITIs(i+1)));
            RightLicking = find(RightLicks(CompleteITIs(i): CompleteITIs(i+1)));
            LeftLicking = find(LeftLicks(CompleteITIs(i): CompleteITIs(i+1)));
            
            if isempty(CenterLicking) == 0
                
                FirstCenterLick = CenterLicking(1); 
                InitiationLick = FirstCenterLick + CompleteITIs(i) - 1;
                 Fixation = CenterFixTime(InitiationLick)/1000; 
                EndFixationTime = InitiationTime + Fixation; 
                EndFixation = find(Time >= EndFixationTime); 
                EndFixation = EndFixation(1); %iteration of the end of the fixation period (if it wasnt aborted)
                
                if isempty(RightLicking) == 0 || isempty(LeftLicking) == 0
                  
                    AbortedTrials(i) = CompleteITIs(i);                
                end                                             
            else 
                
                 if isempty(RightLicking) == 0 || isempty(LeftLicking) == 0
                  
                    AbortedTrials(i) = CompleteITIs(i);  
                    
                 else
                     
                     UnInitiatedTrials(i) = CompleteITIs(i);     
                     
                 end                                                           
            end                       
        end        
    end 
    
end


SuccessfulCenterTrials = nonzeros(SuccessfulCenterTrial); 
NumSuccessfulCenterTrials = length(SuccessfulCenterTrials); 

AbortedTrials = nonzeros(AbortedTrials);
NumAbortedTrials = length(AbortedTrials); 

UnInitiatedTrials = nonzeros(UnInitiatedTrials); 
NumUnInitiatedTrials = length(UnInitiatedTrials); 

FixationLickRates = nonzeros(FixationLickRates); 
AvgFixLickRate = mean(FixationLickRates)

InitiationLatencies = nonzeros(InitiationLatencies); %does not include outlier trial where latency was 0
AvgInitiationLatency = mean(InitiationLatencies); 
NumLatencies = length(InitiationLatencies); 

CurrentDir = pwd; 
FindStart = strfind(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Forced Choice Task';
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(AnalyzedPath, '\', SaveString); 
cd(SavePath); 


AvgInitiateLickLatency = figure('name', 'Latency to Initiate Over Trials');
x = [1:NumLatencies]; 
x = x'; 
y = InitiationLatencies; 
plot(x, y); 
MeanLine = refline(0, AvgInitiationLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 
Fit = polyfit(x, y, 1);
plot(polyval(Fit, x))
hold on; 
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Latency to Initiate Over Trials'); 
title(Title); 
MeanLatency = num2str(AvgInitiationLatency); 
MeanLatency = strcat('Mean Latency = ', MeanLatency); 
legend('Latency Over Time', MeanLatency, 'Best Fit'); 
XLabel = 'Trials'; 
YLabel = 'Time'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Latency_to_Initiate_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgInitiateLickLatency); 


D = 0; 
V = 0; 

NumForcedChoiceTrials = length(ForcedChoiceTrials); 

for i = 1: NumForcedChoiceTrials 
StimType = Stim(ForcedChoiceTrials(i)); 

if StimType == 0 
    
    D = D + 1; 
    
end 

if StimType == 1
    
    V = V + 1; 
    
end 


end 



DiagStim = zeros(NumSuccessfulCenterTrials, 1); 
VertStim = zeros(NumSuccessfulCenterTrials, 1); 
VertLickLatencies =  zeros(NumSuccessfulCenterTrials, 1); 
DiagLickLatencies = zeros(NumSuccessfulCenterTrials, 1);

DiagFreeHits = zeros(NumSuccessfulCenterTrials, 1);
VertFreeHits = zeros(NumSuccessfulCenterTrials, 1);

DiagEarnedHits = zeros(NumSuccessfulCenterTrials, 1);
VertEarnedHits = zeros(NumSuccessfulCenterTrials, 1);

VertMissedTrials = zeros(NumSuccessfulCenterTrials, 1);
DiagMissedTrials = zeros(NumSuccessfulCenterTrials, 1);

DiagWrongChoice = zeros(NumSuccessfulCenterTrials, 1);
VertWrongChoice = zeros(NumSuccessfulCenterTrials, 1);

VertCorrectFirstChoice = zeros(NumSuccessfulCenterTrials, 1);
DiagCorrectFirstChoice = zeros(NumSuccessfulCenterTrials, 1);


for i = 1:NumSuccessfulCenterTrials-2 %88
    
   TrialIt = SuccessfulCenterTrials(i); %iteration of a successfully completed center fixation 
   StimType = Stim(TrialIt:TrialIt + 10); 
   StimType = mode(StimType); %classifies if it is vert or diag 
   
   if StimType == 0 %diagonal 
       
       DiagStim(i) = TrialIt;
       StimTime = Time(TrialIt);  %time at which stim occurred     
       
       LickWindow = find(Time >= StimTime + 2); %find 2 seconds into the future     
       EndWindow = LickWindow(1); %find end of the lick window 
       DiagLicks = LeftLicks(TrialIt: EndWindow); %left licking within the lick window 
       VertLicks = RightLicks(TrialIt: EndWindow); %right licking within the lick window 
       
       CorrectLick = find(DiagLicks == 1);  %searches of left licks within the lick window   
       WrongLicks = find(VertLicks == 1); %searches of right licks within the lick window 
       
       
       if isempty(CorrectLick) == 0 %if there were correct licks
       
           CorrectLick = CorrectLick(1); %first left lick within window 
           LickIt = TrialIt + CorrectLick - 1; %iteration of lick 
           LickTime = Time(LickIt); %iteration of the lick 
           LickLatency = LickTime - StimTime; %latency to lick 

           DiagLickLatencies(i) = LickLatency;
           
           if isempty(WrongLicks) == 0 
               
              WrongLick = WrongLicks(1);                
           end
           
            
        IsFree = find(FreeChoiceTrials > TrialIt); 
           
           if isempty(IsFree) == 0 
               
               IsFree = IsFree(1);
               FreeIt = FreeChoiceTrials(IsFree);
               FreeIt - TrialIt;

               if FreeIt - TrialIt < 150

                   DiagFreeHits(i) = FreeIt;
                   
                   if isempty(WrongLicks) == 0
                       
                       if CorrectLick < WrongLick                          
                           DiagCorrectFirstChoice(i) = FreeIt;                                               
                       end                       
                   end                    
               end             
           end 
           
           if  DiagFreeHits(i) == 0
               
               IsEarned = find(ForcedChoiceTrials > TrialIt); 
               
               if isempty(IsEarned) == 0 
                   
                   IsEarned = IsEarned(1); 
                   EarnedIt = ForcedChoiceTrials(IsEarned); 
                   EarnedIt - TrialIt;

                   if EarnedIt - TrialIt < 150 
                       
                       if isempty(WrongLicks) == 0

                           if CorrectLick < WrongLick

                                DiagEarnedHits(i) = EarnedIt;
                               DiagCorrectFirstChoice(i) = EarnedIt;
                           end
                           
                        else 
                       
                            DiagEarnedHits(i) = EarnedIt;
                            DiagCorrectFirstChoice(i) = EarnedIt;
                       end                                                                      
                   end   
               end 
           end 
           
           if  DiagFreeHits(i) == 0 &&  DiagEarnedHits(i) == 0 %if it is a wrong lick aborted earned trial there wont be a saved earned iteration 
               
               if isempty(WrongLicks) == 0
                   
                   DiagWrongChoice(i) = TrialIt;
               
               end 
           end
           
       else 
           
          DiagMissedTrials(i) = TrialIt; 
           
       end 
       
   end 
    
   if StimType == 1 %vertical 
       
       VertStim(i) = TrialIt; 
       
       StimTime = Time(TrialIt); 
       LickWindow = find(Time >= StimTime + 2); 
       EndWindow = LickWindow(1); 
       VertLicks = RightLicks(TrialIt: EndWindow); 
       DiagLicks = LeftLicks(TrialIt: EndWindow); 
       
       CorrectLick = find(VertLicks == 1); 
       WrongLicks = find(DiagLicks == 1); 
       
       if isempty(CorrectLick) == 0 
                    
           CorrectLick = CorrectLick(1); 
           LickIt = TrialIt + CorrectLick - 1; 
           LickTime = Time(LickIt); 
           LickLatency = LickTime - StimTime; 

           VertLickLatencies(i) = LickLatency;           
               
           if isempty(WrongLicks) == 0 
               
              WrongLick = WrongLicks(1); 
               
           end
           
           IsFree = find(FreeChoiceTrials > TrialIt); 
           
           if isempty(IsFree) == 0 
               
               IsFree = IsFree(1);
               FreeIt = FreeChoiceTrials(IsFree); 
               FreeIt - TrialIt;

               if FreeIt - TrialIt < 150

                   VertFreeHits(i) = FreeIt;                  
                    
                   if isempty(WrongLicks) == 0
                       
                       if CorrectLick < WrongLick                          
                           VertCorrectFirstChoice(i) = FreeIt;  
                       end                       
                   end     
                   
               end               
           
           end 
           
            if  VertFreeHits(i) == 0
               
               IsEarned = find(ForcedChoiceTrials > TrialIt); 
               
               if isempty(IsEarned) == 0
                
               IsEarned = IsEarned(1); 
               EarnedIt = ForcedChoiceTrials(IsEarned); 
               EarnedIt - TrialIt;

                 if EarnedIt - TrialIt < 150
                       
                       if isempty(WrongLicks) == 0

                           if CorrectLick < WrongLick

                                VertEarnedHits(i) = EarnedIt;
                               VertCorrectFirstChoice(i) = EarnedIt;  
                               
                           else 
                               
                                VertWrongChoice(i) = EarnedIt; 
                           end  
                        else 
                       
                        VertEarnedHits(i) = EarnedIt;
                        VertCorrectFirstChoice(i) = EarnedIt;
                        
                       end                                                                      
                 end 
                    
               end
                           
            end 
          
            if  VertFreeHits(i) == 0 &&  VertEarnedHits(i) == 0 %if it is a wrong lick aborted earned trial there wont be a saved earned iteration 
               
               if isempty(WrongLicks) == 0
                   
                   VertWrongChoice(i) = TrialIt;
               
               end 
           end
           
   else
           
         VertMissedTrials(i) = TrialIt;   
   
   end 
    
   end 
   
   
end 

DiagStim = nonzeros(DiagStim); 
NumDiagStim = length(DiagStim); 

DiagFreeHits = nonzeros(DiagFreeHits); 
NumDiagFreeHits = length(DiagFreeHits);
DiagEarnedHits = nonzeros(DiagEarnedHits); 
NumDiagEarnedHits = length(DiagEarnedHits);

VertStim = nonzeros(VertStim); 
NumVertStim = length(VertStim);

VertFreeHits = nonzeros(VertFreeHits); 
NumVertFreeHits = length(VertFreeHits);
VertEarnedHits = nonzeros(VertEarnedHits); 
NumVertEarnedHits = length(VertEarnedHits);

VertMissedTrials = nonzeros(VertMissedTrials); 
NumVertMissedTrials = length(VertMissedTrials); 
DiagMissedTrials = nonzeros(DiagMissedTrials); 
NumDiagMissedTrials = length(DiagMissedTrials);

VertWrongChoice = nonzeros(VertWrongChoice);
NumVertWrongChoice = length(VertWrongChoice); 
DiagWrongChoice = nonzeros(DiagWrongChoice); 
NumDiagWrongChoice = length(DiagWrongChoice); 

VertLickLatencies = nonzeros(VertLickLatencies); 
AvgVertLatency = mean(VertLickLatencies); 
NumVertLatencies = length(VertLickLatencies); 

DiagLickLatencies = nonzeros(DiagLickLatencies); 
AvgDiagLatency = mean(DiagLickLatencies); 
NumDiagLatencies = length(DiagLickLatencies); 

DiagCorrectFirstChoice = nonzeros(DiagCorrectFirstChoice); 
NumDiagFirstChoice = length(DiagCorrectFirstChoice); 
VertCorrectFirstChoice = nonzeros(VertCorrectFirstChoice);
NumVertFirstChoice = length(VertCorrectFirstChoice); 

VertFirstChoiceRate = NumVertFirstChoice/NumVertStim; 
DiagFirstChoiceRate = NumDiagFirstChoice/NumDiagStim; 


RewardsVsMisses = figure('name', 'Received Versus Missed Rewards');
Vertical = [NumVertFreeHits NumVertEarnedHits NumVertWrongChoice NumVertMissedTrials]; 
Diagonal = [NumDiagFreeHits NumDiagEarnedHits NumDiagWrongChoice NumDiagMissedTrials];
set(gca,'XTickLabel',{'Vertical', 'Diagonal'})
bar_handle = bar([Vertical; Diagonal],'grouped');
bar_handle(1).FaceColor = 'g';
bar_handle(2).FaceColor = 'r';
bar_handle(3).FaceColor = 'k';
bar_handle(4).FaceColor = 'w';
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Received Versus Missed Rewards'); 
title(Title); 
legend('Vert Free', 'Vert Earned', 'Vert Wrong Choice','Vert Missed', 'Diag Free', 'Diag Earned', 'Diag Wrong Choice', 'Diag Missed'); 
YLabel = 'Trials';  
ylabel(YLabel);

FigureSaveName = 'Received_Versus_Missed_Rewards.png'; 
saveas(gcf, FigureSaveName); 
close(RewardsVsMisses); 



AvgVertLickLatency = figure('name', 'Vertical Lick Latency Over Trials');
x = [1:NumVertLatencies]; 
plot(x, VertLickLatencies); 
MeanLine = refline(0, AvgVertLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 

for i = 1:NumVertFirstChoice-3
    
    VertIt = find(VertStim < VertCorrectFirstChoice(i)); 
    VertIt = VertIt(end); 
    plot(VertIt, VertLickLatencies(VertIt), 'r.','markersize',20); 
    
end 

Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Vertical Lick Latency Over Trials'); 
title(Title); 
MeanVertLatency = num2str(AvgVertLatency); 
MeanLatency = strcat('Mean Latency = ', MeanVertLatency); 
legend('Latency Over Time', MeanLatency, 'Correct First Choice'); 
XLabel = 'Time'; 
YLabel = 'Trial'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Vertical_Lick_Latency_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgVertLickLatency); 



AvgDiagLickLatency = figure('name', 'Diagonal Lick Latency Over Trials');
x = [1:NumDiagLatencies]; 
plot(x, DiagLickLatencies); 
MeanLine = refline(0, AvgDiagLatency); %plot reference line with slope = 0 
MeanLine.Color = 'r'; 
hold on; 

for i = 1:NumDiagFirstChoice
    
    DiagIt = find(DiagStim < DiagCorrectFirstChoice(i)); 
    DiagIt = DiagIt(end); 
    plot(DiagIt, DiagLickLatencies(VertIt), 'r.','markersize',20); 
    
end 

Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Diagonal Lick Latency Over Trials'); 
title(Title); 
MeanDiagLatency = num2str(AvgDiagLatency); 
MeanLatency = strcat('Mean Latency = ', MeanDiagLatency); 
legend('Latency Over Time', MeanLatency,'Correct First Choice'); 
XLabel = 'Time'; 
YLabel = 'Trial'; 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Diagonal_Lick_Latency_Over_Trials.png'; 
saveas(gcf, FigureSaveName); 
close(AvgDiagLickLatency); 


FirstChoiceRates = figure('name', 'FirstChoiceRates');
AllRates = [DiagFirstChoiceRate VertFirstChoiceRate]; 
bar(AllRates);
set(gca,'XTickLabel',{'Diagonal Stim', 'Vertical Stim'})
Title = strcat(MouseFolder, '-', SessionNumber, ':', 'First Choice Rates'); 
title(Title); 
legend('First Choice Rate'); 
YLabel = 'Rate'; 
ylabel(YLabel);

FigureSaveName = 'First_Choice_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(FirstChoiceRates); 




DataPath = 'D:\Brooke\Data\Self Initiated 2AFC'; 
MousePath = strcat(DataPath, '\', MouseName); 
cd(MousePath);

Sesh = strcat('Session', SessionNumber); 

MouseDataFile = dir('*.txt'); 

if isempty(MouseDataFile) == 1
    
    fileID = fopen('MouseData.txt','a');
     formatSpec = '%s\n';
    fprintf(fileID, formatSpec, Sesh)
    dlmwrite('MouseData.txt', AvgInitiationLatency, '-append');
    fclose(fileID);
        
else 
    
     fileID = fopen('MouseData.txt','r'); 
    [MouseData Count] = fscanf(fileID, '%c'); 
    SessionsPresent = findstr(MouseData, 'Session')
    NumSessions = length(SessionsPresent);
    SeshNum = str2num(SessionNumber); 
    
    if NumSessions < SeshNum 
      
        fileID = fopen('MouseData.txt','a');
        formatSpec = '%s\n';
        fprintf(fileID, formatSpec, Sesh)
        fprintf(fileID, formatSpec, AvgInitiationLatency)
        fprintf(fileID, formatSpec, MeanVertLatency)
        fprintf(fileID, formatSpec, MeanDiagLatency)
        fprintf(fileID, formatSpec, VertFirstChoiceRate)
        fprintf(fileID, formatSpec, DiagFirstChoiceRate)
        
        fclose(fileID);
    
    end 
       
end 
     


end 


cd(SavePath); 

cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 


 end 

 
 for i = NumMiceFiles-1 %3:NumMiceFiles
     
     cd(AnalyzedPath); 
    MouseFolder = MiceFiles(i).name; %get name of file in data path 
    BHfile = strfind(MouseFolder, 'BH'); %find out if its a BH file -- searches name for BH
      
    if isempty(BHfile) == 0 
            
        MousePath = strcat(AnalyzedPath, '\', MouseFolder); 
        cd(MousePath); 
          MouseDataFile = dir('*.txt'); 

        if isempty(MouseDataFile) == 0 

            fileID = fopen('MouseData.txt','r'); 
            formatSpec = '%s\n';
            [AllMouseData NumMouseData] = fscanf(fileID, formatSpec); 
            
            FindAllSesh = strfind(AllMouseData, 'Session'); 
            NumAllSesh = length(FindAllSesh); 
            
            SessionData = zeros(5, NumAllSesh); 
            x = 0;
            r = 0; 
            c = 0; 
            
            fileID = fopen('MouseData.txt','r'); 
                formatSpec = '%s/n';
            
            for i = 1: NumMouseData
                
                
                Line = fscanf(fileID, formatSpec, i);
                
                FindSession = strfind(Line, 'Session'); 
                
                if isempty(FindSession) == 0 
                   
                    r = 0;   
                    c = c + 1; 
                else 

                    DataPoint = str2num(Line); 
                    r = r + 1; 
                    SessionData(r, c) = DataPoint; 
                                        
                end 
                                              
            end 

        end 
        
    end 
     
  SessionMeanLatencies = SessionData(1, :); 
  SessionInitiationLatencies = figure('name', 'Latency to Initiate Across Sessions');
  plot(SessionMeanLatencies);  
  legend('Initiation Latency');
  XLabel = 'Sessions'; 
  xlabel(XLabel); 
  YLabel = 'Mean Latency'; 
  ylabel(YLabel);
    Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Latency to Initiate Across Sessions'); 
   title(Title); 

    FigureSaveName = 'Latency_to_Initiate_Across_Sessions.png'; 
    saveas(gcf, FigureSaveName); 
    close(SessionInitiationLatencies); 
    
  SessionMeanVertLatencies = SessionData(2, :); 
  SessionMeanDiagLatencies = SessionData(3, :);
  StimLickLatencies = figure('name', 'Correct Side Lick Latencies Across Sessions'); 
  plot(SessionMeanVertLatencies);
  hold on; 
  plot(SessionMeanDiagLatencies);
  legend('Vert Correct Lick Latency', 'Diag Correct Lick Latency');
  XLabel = 'Sessions'; 
  xlabel(XLabel); 
  YLabel = 'Mean Latency'; 
  ylabel(YLabel);
   Title = strcat(MouseFolder, '-', SessionNumber, ':', 'Correct Side Lick Latencies Across Sessions'); 
   title(Title); 

    FigureSaveName = 'Correct_Side_Lick_Latencies_Across_Sessions.png'; 
    saveas(gcf, FigureSaveName); 
    close(StimLickLatencies ); 
  
  
  SessionVertFirstChoiceRates = SessionData(4, :); 
  SessionDiagFirstChoiceRates = SessionData(5, :); 
  StimFirstChoices = figure('name', 'First Choice Rates Across Sessions'); 
  plot(SessionVertFirstChoiceRates); 
  hold on; 
  plot(SessionDiagFirstChoiceRates); 
  legend('Vert Correct First Choice', 'Diag Correct First Choice');
  XLabel = 'Sessions'; 
  xlabel(XLabel); 
  YLabel = 'First Choice Rate'; 
  ylabel(YLabel);
    Title = strcat(MouseFolder, '-', SessionNumber, ':', 'First Choice Rates Across Sessions'); 
   title(Title); 

    FigureSaveName = 'First_Choice_Rates_Across_Sessions.png'; 
    saveas(gcf, FigureSaveName); 
    close(StimFirstChoices); 

     
 end



   




