CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analysis Code'; 
DataPath = 'D:\Brooke\Data\Forced Choice Task'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); %lists the files in a directory
NumMiceFiles = length(MiceFiles);   %number of files in the data path 
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles %for each BH data folder -- for each mouse 
    
    i; 
    cd(DataPath); 
    MouseFolder = MiceFiles(i).name; %get name of file in data path 
    BHfile = strfind(MouseFolder, 'BH'); %find out if its a BH file -- searches name for BH
    
    if isempty(BHfile) == 0  %if it is a BH file -- if the BH string has been found 
    
    addpath(MouseFolder); %adds folder to path so it can be acted upon -- need to do this every time for some reason 
    MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
    cd(MouseFolderDataPath); %makes the BH folder the current directory so that the dir function can be used on that folder
    MouseFolderFiles = dir(MouseFolderDataPath); %files in the BH folder 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), 1); 
    NameAndDate = cell((NumDateFiles-2), 2); 
    
    for x = 3:NumDateFiles %for each date folder in the mouse folder 
        
        DateFile = MouseFolderFiles(x).name; %get name in string form 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile); 
           
    %parses out name/full date of the folder
    %puts into format that matlab can read 
        
    FirstComma = strfind(DateFilePath, ','); 
    StartDateString = FirstComma(1) + 2; %starts the place in the string that is the beginning of the month 
    
    FindEnd = strfind(DateFilePath, 'PM'); %find end of string
    
    if isempty(FindEnd) == 1
         FindEnd = strfind(DateFilePath, 'AM'); %if not AM then PM
    end 
    
    EndDateString = FindEnd-5; %take away AM/PM and seconds 
    DateString = DateFilePath(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time]; %places all the pieces together to fit the format below 
    
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date); %matlab gives number specific to that exact time -- numerical = chronological order 
    DateNumString = num2str(DateNum); %turns number into string 
    
    Dates((x-2), 1) = DateNum; %places dates in array 
    
    DateCell = cellstr(DateNumString); 
    NameCell = cellstr(DateFile); %use cellstr because strings are different sizes  
    
    NameAndDate((x-2), 1) = DateCell; 
    NameAndDate((x-2), 2) = NameCell; %2x2 array of date numbers and date strings
     
    end
   
    AscendDates = sort(Dates); %sort date numbers into ascending order 
    NumDates = length(Dates); 
    AscendFiles = cell(NumDates, 1); 
    
    for x = 1:NumDates %places dates strings in the same order as date numbers 
        
        FindIt = find(Dates == AscendDates(x));
        AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
    end
    
    AscendFiles = char(AscendFiles);
    ItNums = zeros(NumDates, 1);
     cd(MouseFolderDataPath); 
    
    for x = 1:NumDates 
                  
        FirstChar = AscendFiles(x, 1); 
        SecondChar = AscendFiles(x, 2);
        IsNum = str2num(FirstChar);
        IsNumTwo = str2num(SecondChar);
        
        if isempty(IsNumTwo) == 0
            
            TwoDigits = strcat(FirstChar, SecondChar); 
            IsNum = str2num(TwoDigits); 
            
        end 

        if isempty(IsNum) == 0 
        
            if IsNum ~= x
                
                OldName = AscendFiles(x, :); 
                OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                AscendFiles(x, 1) = num2str(x); 
                RevisedName = AscendFiles(x, :);
                RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                movefile(OldNamePath, RevisedName);
            end 
        
        else 
            
        OldName = AscendFiles(x, :); 
        OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
        ItString = num2str(x); 
        NewName = strcat(ItString, AscendFiles(x, :));
        NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 
       
        movefile(OldNamePath, NewNamePath);            

        end
        
    end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = strfind(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = strfind(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRightRewards = single.empty(500000, 0); 
 AllRightLicks = single.empty(500000, 0); 
  AllRightDistTime = single.empty(500000, 0); 
  AllLeftRewards = single.empty(500000, 0); 
 AllLeftLicks = single.empty(500000, 0); 
  AllLeftDistTime = single.empty(500000, 0); 
 AllTime = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(14*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 14*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,14*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 14);  
Zeros = zeros(1, 14); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 14 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:14)= StimInfo;
     
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end


TotalDist= StimPos(:, 1); 
Stims = StimPos(:, 3);
RightLicks = StimPos(:, 4); 
RightRewards = StimPos(:, 5);
RightRZDist = StimPos(:, 6);
LeftLicks = StimPos(:, 7); 
LeftRewards = StimPos(:, 8);
LeftRZDist = StimPos(:, 9);
StimSize = StimPos(:, 10); 
StimSide = StimPos(:, 11);
CueSide = StimPos(:, 12);
StimMotion = StimPos(:, 13);
FlashSide = StimPos(:, 14);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllRightLicks(1:movnu) = RightLicks;
    AllRightReward(1:movnu) = RightRewards;    
    AllRightDistTime(1:movnu) = RightRZDist;
    AllLeftLicks(1:movnu) = LeftLicks;
    AllLeftReward(1:movnu) = LeftRewards;    
    AllLeftDistTime(1:movnu) = LeftRZDist;
    AllDist(1:movnu) = TotalDist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    AllTime(1:movnu) = Timer;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
   
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims;     
    AllRightRewards(StartFill: (StartFill+movnu) - 1) = RightRewards;   
    AllRightLicks(StartFill: (StartFill+movnu) - 1) = RightLicks;  
    AllRightDistTime(StartFill: (StartFill+movnu) - 1) = RightRZDist;
    AllLeftRewards(StartFill: (StartFill+movnu) - 1) = LeftRewards;   
    AllLeftLicks(StartFill: (StartFill+movnu) - 1) = LeftLicks;  
    AllLeftDistTime(StartFill: (StartFill+movnu) - 1) = LeftRZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = TotalDist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
Stims = AllStims';
RightLicks = AllRightLicks';
RightRewards = AllRightRewards';
RightRZDist = round(AllRightDistTime)'; 
LeftLicks = AllLeftLicks';
LeftRewards = AllLeftRewards';
LeftRZDist = round(AllLeftDistTime)'; 
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 1));   
NumVertStim = length(VertStimNum); 
VertStim = zeros(NumVertStim, 1); 

for i = 1:NumVertStim 
    
    if i == 1 
        VertStim(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        VertStim(i, 1) = 0; 
    else 
        VertStim(i, 1) = VertStimNum(i);
    end 
    end 
end 

VertStim = nonzeros(VertStim);  
NumVertStim = length(VertStim); 

VertRZ = find(RightRZDist ~= 0); 
NumVertRZ = length(VertRZ); 
VertRZs = zeros(NumVertRZ, 1); 

for i = 1:NumVertRZ
                      
        if i == 1 
       VertRZs(i, 1) = VertRZ (i);  

        else
            if VertRZ (i)- VertRZ (i-1) < 10
            VertRZs(i, 1) = 0; 
        else 
            VertRZs(i, 1) = VertRZ (i);
        end 
        end       

end 

VertRZs = nonzeros(VertRZs); 
NumVertRZs = length(VertRZs); 

VertRZStarts = zeros(NumVertRZs, 1); 
VertRZEnds = zeros(NumVertRZs, 1); 

for i = 2:NumVertStim-1
    
    RZValues = RightRZDist(VertStim(i): VertStim(i+1)-1);
       
    SearchRZStart = find(RZValues >= 30) ;
    if isempty(SearchRZStart) == 0
        
    Start = SearchRZStart(1); 
    RZStart = VertStim(i)+(Start-1);
    VertRZStarts(i, 1) = RZStart; 
    
    end
   
    SearchRZEnd = find(RZValues >= 70); 
    
    if isempty(SearchRZEnd) == 0 
        
    End = SearchRZEnd(1); 
    RZEnd = VertStim(i)+(End-1);
    VertRZEnds(i, 1) = RZEnd; 
    
    else 
        
        VertRZStarts(i, 1) = 0; 
    
    end
end 

VertRZStarts = nonzeros(VertRZStarts); 
NumVertStarts = length(VertRZStarts); 
VertRZEnds = nonzeros(VertRZEnds); 
NumVertEnds = length(VertRZEnds); 

VertStim = VertStim(2:NumVertStim-1); 
NumVertStim = length(VertStim); 


%finds occurences of vert reward
VertRewards = zeros(NumVertStarts, 1); 
VertEarnedRewards = zeros(NumVertStarts, 1); 

for i = 1: NumVertStarts 
     
    StartRZ = VertRZStarts(i); 
    EndRZ = VertRZEnds(i); 
    
    Span = RightLicks(StartRZ:EndRZ); 
    LickWithin = find(Span == 1); 
    
    if isempty(LickWithin) == 0
        
        FirstLick = LickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartRZ; 
    	VertRewards(i, 1) = FirstLickIt;  
        VertEarnedRewards(i, 1) = FirstLickIt;
        
    else
        
        VertRewards(i, 1) = EndRZ; 
        
    end 
end 

VertRewards = nonzeros(VertRewards);
NumVertReward = length(VertRewards)

VertEarnedRewards = nonzeros(VertEarnedRewards); 
NumVertEarnedRewards = length(VertEarnedRewards); 


VertRZCorrectChoice = zeros(NumVertStarts, 1); 

for i = 1: NumVertStarts 
     
    StartRZ = VertRZStarts(i); 
    EndRZ = VertRZEnds(i); 
    
    RightLickSpan = RightLicks(StartRZ:EndRZ); 
    RightLickWithin = find(RightLickSpan == 1); 
    
    LeftLickSpan = LeftLicks(StartRZ:EndRZ); 
    LeftLickWithin = find(LeftLickSpan == 1);
    
    
    if isempty(RightLickWithin) == 0 % if correct lick 
        
        FirstLick = RightLickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartRZ; 
        
        if isempty(LeftLickWithin) == 0 %if also a wrong lick 
        
            WrongLick = LeftLickWithin(1); 
            WrongLickIt = (WrongLick - 1) + StartRZ;
            
            if FirstLickIt < WrongLickIt %did correct lick come before wrong lick 
            
                VertRZCorrectChoice(i, 1) = FirstLickIt; 
                
            end
            
        else %if only the correct lick 
            
            VertRZCorrectChoice(i, 1) = FirstLickIt; 
            
        end
    end 
end 

VertRZCorrectChoice = nonzeros(VertRZCorrectChoice);
NumVertRZCorrectChoice = length(VertRZCorrectChoice) 



VertCorrCorrectChoice = zeros(NumVertStarts, 1); 

for i = 1: NumVertStarts 
     
    StartCorr = VertStim(i); 
    EndCorr = VertRZEnds(i); 
    
    RightLickSpan = RightLicks(StartCorr:EndCorr); 
    RightLickWithin = find(RightLickSpan == 1); 
    
    LeftLickSpan = LeftLicks(StartCorr:EndCorr); 
    LeftLickWithin = find(LeftLickSpan == 1);
    
    
    if isempty(RightLickWithin) == 0 % if correct lick 
        
        FirstLick = RightLickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartCorr; 
        
        if isempty(LeftLickWithin) == 0 %if also a wrong lick 
        
            WrongLick = LeftLickWithin(1); 
            WrongLickIt = (WrongLick - 1) + StartCorr;
            
            if FirstLickIt < WrongLickIt %did correct lick come before wrong lick 
            
                VertCorrCorrectChoice(i, 1) = FirstLickIt; 
                
            end
            
        else %if only the correct lick 
            
            VertCorrCorrectChoice(i, 1) = FirstLickIt; 
            
        end
    end 
end 

VertCorrCorrectChoice = nonzeros(VertCorrCorrectChoice);
NumVertCorrCorrectChoice = length(VertCorrCorrectChoice) 




%finds occurences of  Diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 2));   
NumDiagStim = length(DiagStimNum); 
DiagStim = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStim(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStim(i, 1) = 0; 
    else 
        DiagStim(i, 1) = DiagStimNum(i);
    end 
    end 
end 

DiagStim = nonzeros(DiagStim);  
NumDiagStim = length(DiagStim); 


%occurrences of RZ starts and ends 

DiagRZ = find(LeftRZDist ~= 0); 
NumDiagRZ = length(DiagRZ); 
DiagRZs = zeros(NumDiagRZ, 1); 

for i = 1:NumDiagRZ
                      
        if i == 1 
            
            FirstValue = LeftRZDist(DiagRZ(i));            
            if FirstValue == 1
                DiagRZs(i, 1) = DiagRZ (i);
            end

        else
            if DiagRZ (i)- DiagRZ (i-1) < 10
            DiagRZs(i, 1) = 0; 
        else 
            DiagRZs(i, 1) = DiagRZ (i);
        end 
        end       

end 

DiagRZs = nonzeros(DiagRZs); 
NumDiagRZs = length(DiagRZs); 

DiagRZStarts = zeros(NumDiagRZs, 1); 
DiagRZEnds = zeros(NumDiagRZs, 1); 

for i = 2:NumDiagStim-1
    
    RZValues = LeftRZDist(DiagStim(i): DiagStim(i+1)-1);
       
    SearchRZStart = find(RZValues >= 30) ;
    if isempty(SearchRZStart) == 0
        
    Start = SearchRZStart(1); 
    RZStart = DiagStim(i)+(Start-1);
    DiagRZStarts(i, 1) = RZStart; 
    
    end
   
    SearchRZEnd = find(RZValues >= 60); 
    
    if isempty(SearchRZEnd) == 0 
        
    End = SearchRZEnd(1); 
    RZEnd = DiagStim(i)+(End-1);
    DiagRZEnds(i, 1) = RZEnd; 
    
    else 
        
       ShortRZEnd = find(RZValues >= 45); 
       
       if isempty(ShortRZEnd) == 0 
        
        End = ShortRZEnd(1); 
        RZEnd = DiagStim(i)+(End-1)
        DiagRZEnds(i, 1) = RZEnd; 
        
       end

    end
end 

DiagRZStarts = nonzeros(DiagRZStarts); 
NumDiagStarts = length(DiagRZStarts); 
DiagRZEnds = nonzeros(DiagRZEnds); 
NumDiagEnds = length(DiagRZEnds);  

DiagStim = DiagStim(2:NumDiagStim-1); 
NumDiagStim = length(DiagStim); 

% NumDiagStarts = length(DiagRZStarts); 
% 
% DiagStim = DiagStim(1:NumDiagStim-1); 
% NumDiagStim = length(DiagStim); 

%finds occurences of diag reward
DiagRewards = zeros(NumDiagStarts, 1); 
DiagEarnedRewards = zeros(NumDiagStarts, 1); 

for i = 1: NumDiagStarts 
     
    StartRZ = DiagRZStarts(i); 
    EndRZ = DiagRZEnds(i); 
    
    Span = LeftLicks(StartRZ:EndRZ); 
    LickWithin = find(Span == 1); 
    
    if isempty(LickWithin) == 0
        
        FirstLick = LickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartRZ; 
    	DiagRewards(i, 1) = FirstLickIt; 
        DiagEarnedRewards(i, 1) = FirstLickIt; 
        
    else
        
        DiagRewards(i, 1) = EndRZ; 
        
    end 
end 

DiagRewards = nonzeros(DiagRewards);
NumDiagReward = length(DiagRewards) 

DiagEarnedRewards = nonzeros(DiagEarnedRewards); 
NumDiagEarnedRewards = length(DiagEarnedRewards); 


DiagRZCorrectChoice = zeros(NumDiagStarts, 1); 

for i = 1: NumDiagStarts 
     
     StartRZ = DiagRZStarts(i); 
    EndRZ = DiagRZEnds(i); 
    
    RightLickSpan = RightLicks(StartRZ:EndRZ); 
    RightLickWithin = find(RightLickSpan == 1); 
    
    LeftLickSpan = LeftLicks(StartRZ:EndRZ); 
    LeftLickWithin = find(LeftLickSpan == 1);
    
    if isempty(LeftLickWithin) == 0
        
        FirstLick = LeftLickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartRZ; 
        
        if isempty(RightLickWithin) == 0
        
            WrongLick = RightLickWithin(1); 
            WrongLickIt = (WrongLick - 1) + StartRZ;
            
            if FirstLickIt < WrongLickIt
            
                DiagRZCorrectChoice(i, 1) = FirstLickIt; 
                
            end
            
        else %if only the correct lick 
            
            DiagRZCorrectChoice(i, 1) = FirstLickIt; 
            
        end
    end 
end 

DiagRZCorrectChoice = nonzeros(DiagRZCorrectChoice);
NumDiagRZCorrectChoice = length(DiagRZCorrectChoice) 


DiagCorrCorrectChoice = zeros(NumDiagStarts, 1); 

for i = 1: NumDiagStarts 
     
     StartCorr = DiagStim(i); 
    EndCorr = DiagRZEnds(i); 
    
    RightLickSpan = RightLicks(StartCorr:EndCorr); 
    RightLickWithin = find(RightLickSpan == 1); 
    
    LeftLickSpan = LeftLicks(StartCorr:EndCorr); 
    LeftLickWithin = find(LeftLickSpan == 1);
    
    if isempty(LeftLickWithin) == 0
        
        FirstLick = LeftLickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartCorr; 
        
        if isempty(RightLickWithin) == 0
        
            WrongLick = RightLickWithin(1); 
            WrongLickIt = (WrongLick - 1) + StartCorr;
            
            if FirstLickIt < WrongLickIt
            
                DiagCorrCorrectChoice(i, 1) = FirstLickIt; 
                
            end
            
        else %if only the correct lick 
            
            DiagCorrCorrectChoice(i, 1) = FirstLickIt; 
            
        end
    end 
end 

DiagCorrCorrectChoice = nonzeros(DiagCorrCorrectChoice);
NumDiagCorrCorrectChoice = length(DiagCorrCorrectChoice) 





%test for # iterations per 1 ms 
  
VertIt =  VertStim(2); %iteration of each reward
    StimTime = round(Timer(VertIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  VertIt - ItBefore;   

%ItPerMs = 1; 
     

 RevAnalysisSpan = 5; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 30; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;

 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;
 
 StartSpan=   VertIt- (RevAnalysisLength);
 EndSpan = VertIt+ (FwdAnalysisLength);
  
 SpanLength = EndSpan - StartSpan; 
  
  
%peristimulus and reward lick behavior for all vert 

VertLicksinSpan = zeros(SpanLength, NumVertReward); 
LeftLicksDuring = zeros(SpanLength, NumVertReward); 
VertTimeofSpan = zeros(SpanLength, NumVertReward); 
VertSpeedinSpan = zeros(SpanLength, NumVertReward); 

for i = 1:NumVertStim
    
    VertIt =  VertStim(i);
    StimTime = Timer(VertIt); 
   
    StartSpan=   VertIt- (RevAnalysisLength);
    EndSpan =  VertIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after
    Blocks = SpanLength/ItPerMs;

    VertLicksinSpan(:, i) = RightLicks((StartSpan+1):EndSpan);
    LeftLicksDuring(:, i) = LeftLicks((StartSpan+1):EndSpan);
    VertSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
    VertTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
    
    for y = 1:SpanLength
         VertTimeofSpan(y, i) = VertTimeofSpan(y, i) - StimTime; 
    end 
    
    VertTimeofSpan(:, i) ;
end


VertLicksinSpan = VertLicksinSpan';  
VertTimeofSpan = VertTimeofSpan';  
VertSpeedinSpan = VertSpeedinSpan';
LeftLicksDuring = LeftLicksDuring'; 



%peristimulus and reward lick behavior for diag stim 

 RevAnalysisSpan = 5; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 30; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan; 
 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;

DiagLicksinSpan = zeros(SpanLength, NumVertReward); 
DiagTimeofSpan = zeros(SpanLength, NumVertReward); 
DiagSpeedinSpan = zeros(SpanLength, NumVertReward); 
RightLicksDuring = zeros(SpanLength, NumVertReward); 

for i = 1:NumDiagStim
    
    DiagIt = DiagStim(i);   
    DiagStimTime = Timer(DiagIt); 
         
   
    StartSpan=  DiagIt- (RevAnalysisLength);
    EndSpan = DiagIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

         DiagLicksinSpan(:, i) = LeftLicks((StartSpan+1):EndSpan);
         RightLicksDuring(:, i) = RightLicks((StartSpan+1):EndSpan);
         DiagSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
         DiagTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
         
         for y = 1:SpanLength
            
         DiagTimeofSpan(y, i) = DiagTimeofSpan(y, i) - DiagStimTime; 
         
         end 
    
    DiagTimeofSpan(:, i); 
end

DiagLicksinSpan = DiagLicksinSpan';
DiagTimeofSpan = DiagTimeofSpan'; 
DiagSpeedinSpan = DiagSpeedinSpan'; 
RightLicksDuring =  RightLicksDuring'; 






CurrentDir = pwd; 
FindStart = strfind(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Forced Choice Task';
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(AnalyzedPath, '\', SaveString); 
cd(SavePath); 

FindSeshNum = strfind(SavePath, '\'); 
FindSeshNum = FindSeshNum(end); 
SeshNumIt = FindSeshNum + 1; 
SeshNum = strcat('Session', SavePath(SeshNumIt))




XLabel = 'Peristimulus Time (s)';
YLabel = 'Average Licks'; 

AvgLicksinSpanForVert = smooth(smooth(mean(VertLicksinSpan, 1)));
AvgLeftLicksDuring = smooth(smooth(mean(LeftLicksDuring, 1))); 

x = VertTimeofSpan(2, :); 

VertAvgLicks = figure('name', 'Average Licks For Vert Stim In Session'); 
plot(x, AvgLicksinSpanForVert, x, AvgLeftLicksDuring); 
hold on; 
Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Vert Stim In Session'); 
title(Title); 
legend('Right(Correct) Licks', 'Left(False) Licks'); 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Average_Licks_For_Vert_Stim_In_Session.png'; 
saveas(gcf, FigureSaveName); 
close(VertAvgLicks); 




AvgLicksinSpanForDiag = smooth(smooth(mean(DiagLicksinSpan, 1)));
AvgRightLicksDuring = smooth(smooth(mean(RightLicksDuring, 1))); 

x = DiagTimeofSpan(2, :); 

DiagAvgLicks = figure('name', 'Average Licks For Diag Stim In Session'); 
plot(x, AvgLicksinSpanForDiag, x, AvgRightLicksDuring); 
hold on; 
Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Diag Stim In Session'); 
title(Title); 
legend('Left(Correct) Licks', 'Right(False) Licks'); 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Average_Licks_For_Diag_Stim_In_Session.png'; 
saveas(gcf, FigureSaveName); 
close(DiagAvgLicks); 



NumVertFreeRewards = NumVertReward - NumVertEarnedRewards; 
NumDiagFreeRewards = NumDiagReward - NumDiagEarnedRewards;

FreeVersusEarnedRewards = figure('name', 'Free Vs Earned Rewards For Each Stim');
AllVertRewards = [NumVertFreeRewards NumVertEarnedRewards]; 
AllDiagRewards = [NumDiagFreeRewards NumDiagEarnedRewards]; 
AllRewards = [AllVertRewards; AllDiagRewards]; 
bar(AllRewards, 'stacked');
set(gca,'XTickLabel',{'Vert Stim', 'Diag Stim'})

legend('Free Rewards', 'Earned Rewards'); 

FigureSaveName = 'Earned_Versus_Free_Reward_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(FreeVersusEarnedRewards);




VertRZCorrectChoiceRate = NumVertRZCorrectChoice/NumVertStim; 
DiagRZCorrectChoiceRate = NumDiagRZCorrectChoice/NumDiagStim; 

CorrectChoiceRates = figure('name', 'Rate of Correct First Choice Within the RZ For Each Stim'); 
AllChoiceRates = [VertRZCorrectChoiceRate DiagRZCorrectChoiceRate]; 
bar(AllChoiceRates , 'r');
set(gca,'XTickLabel',{'Vert RZ Correct Choices', 'Diag RZ Correct Choices'})

FigureSaveName = 'Correct_First_Choice_in_the_RZ_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(CorrectChoiceRates);


VertCorrCorrectChoiceRate = NumVertCorrCorrectChoice/NumVertStim; 
DiagCorrCorrectChoiceRate = NumDiagCorrCorrectChoice/NumDiagStim; 

CorrectChoiceRates = figure('name', 'Rate of Correct First Choice Within the Corridor For Each Stim'); 
AllChoiceRates = [VertCorrCorrectChoiceRate DiagCorrCorrectChoiceRate]; 
bar(AllChoiceRates , 'b');
set(gca,'XTickLabel',{'Vert Corridor Correct Choices', 'Diag Corridor Correct Choices'})

FigureSaveName = 'Correct_First_Choice_in_the_Corridor_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(CorrectChoiceRates);


% YLabel = 'Speed (cm/s)'; 
% 
% %avg speed of trials 
% AvgSpeedinSpanForVert = smooth(mean(VertSpeedinSpan, 1)); 
% Height = max(AvgSpeedinSpanForVert); 
% x = VertTimeofSpan(1, :); 
% 
% VertAvgSpeed = figure('name', 'Average Speed For Vert Stim in Session'); 
% plot(x, AvgSpeedinSpanForVert); 
% hold on; 
% y = linspace(0, Height);  
% plot(AvgRewardTime, y, 'r.'); 
% plot(AvgRZStartTime, y, 'g.');
% Title = strcat(MouseName, '-', SeshNum, ':', 'Average Speed For Vert Stim In Session'); 
% title(Title); 
% xlabel(XLabel); 
% ylabel(YLabel);
% 
% FigureSaveName = 'Average_Speed_For_Vert_Stim_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertAvgSpeed); 
% 



YLabel = 'Trial'; 

Trials = (1:NumVertStim);
VertTrialsOne = figure('name','Vertical Trials Part1'); 

for i = 1:(round(NumVertStim/2)) 
    
    i; 
    x = VertTimeofSpan(2, :); 
    y = i; 
    plot(x, y); 
      
    hold on; 
       
    VertIt = VertStim(i);
    StimTime = Timer(VertIt);
     
     EndRZ = VertRZEnds(i);
     RZEndTime = Timer(EndRZ)-StimTime;  
     
     StartRZ = VertRZStarts(i);
     RZStartTime = Timer(StartRZ)-StimTime;  
     
     RZSpan = [RZStartTime RZEndTime]; 
     Ys = [y y]; 
     
     plot(RZSpan, Ys, 'Color', [0 0.75 0], 'LineWidth', 6);
     Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part1'); 
     title(Title); 
     xlabel(XLabel); 
     ylabel(YLabel); 
     
  hold on; 
    
    for a = 1:SpanLength
               
        LickPresent = VertLicksinSpan(i, a);  
        
        if LickPresent == 1
            
            LickTime = VertTimeofSpan(i, a); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
    end  
    
    hold on; 
    
     RewardIt = VertRewards(i); 
     RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
     plot(RewardTime, y, 'r.', 'MarkerSize', 16); 
    
end  

FigureSaveName = 'Vert_Trials_Part1.png'; 
saveas(gcf, FigureSaveName); 
close(VertTrialsOne); 




VertTrialTwo = figure('name','Vert Trials Part2'); 

for i = round((NumVertStim/2))+1 : NumVertStim-1 
    

    x = VertTimeofSpan(2, :); 
    y = i; 
    plot(x, y); 
    hold on; 
       
    VertIt = VertStim(i);
    StimTime = Timer(VertIt);
     
     EndRZ = VertRZEnds(i);
     RZEndTime = Timer(EndRZ)-StimTime;  
     
     StartRZ = VertRZStarts(i);
     RZStartTime = Timer(StartRZ)-StimTime;  
     
     RZSpan = [RZStartTime RZEndTime]; 
     Ys = [y y]; 
     
     plot(RZSpan, Ys, 'Color', [0 0.75 0], 'LineWidth', 6);
     Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part2'); 
     title(Title); 
     xlabel(XLabel); 
     ylabel(YLabel);
     
  hold on; 
    
    for a = 1:SpanLength
               
        LickPresent = VertLicksinSpan(i, a);  
        
        if LickPresent == 1
            
            LickTime = VertTimeofSpan(i, a); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
    end  
    
    hold on; 
    
     RewardIt = VertRewards(i); 
     RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
     plot(RewardTime, y, 'r.', 'MarkerSize', 16); 
    
end 

FigureSaveName = 'Vert_Trials_Part2.png'; 
saveas(gcf, FigureSaveName); 
close(VertTrialTwo); 










Trials = (1:NumDiagStim);
YLabel = 'Trial'; 

DiagTrialsOne = figure('name','Diag Trials Part1'); 

for i = 1:round((NumDiagStim/2)) 
    
   
    x = DiagTimeofSpan(2, :); 
    y = i; 
    plot(x, y); 
       
    hold on;     
     
    DiagStimIt = DiagStim(i); 
    DiagStimTime = Timer(DiagStimIt); 
     
     EndRZ = DiagRZEnds(i);
     RZEndTime = Timer(EndRZ)-DiagStimTime;  
     
     StartRZ = DiagRZStarts(i);
     RZStartTime = Timer(StartRZ)-DiagStimTime;  
     
     RZSpan = [RZStartTime RZEndTime]; 
     Ys = [y y]; 
    
    plot(RZSpan, Ys, 'r', 'LineWidth', 6);
    Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
    title(Title); 
    xlabel(XLabel); 
    ylabel(YLabel);

    hold on; 
    
        for z = 1:SpanLength
        
        LickPresent = DiagLicksinSpan (i, z);  
        
        if LickPresent == 1
            
            LickTime = DiagTimeofSpan(i, z); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
        end  
    
        hold on; 
        
         RewardIt = DiagRewards(i); 
         RewardTime = Timer(RewardIt)-DiagStimTime; %time at that reward occurrence
         plot(RewardTime, y, 'b.', 'MarkerSize', 16); 
    
end 

FigureSaveName = 'Diag_Trials_Part1.png'; 
saveas(gcf, FigureSaveName); 
close(DiagTrialsOne); 



DiagTrialsTwo = figure('name','DiagTrials Part2'); 

for i = round((NumDiagStim/2))+1 : NumDiagStim-1 

      x = DiagTimeofSpan(2, :); 
    y = i; 
    plot(x, y); 
       
    hold on;     
     
    DiagStimIt = DiagStim(i); 
    DiagStimTime = Timer(DiagStimIt); 
    
     EndRZ = DiagRZEnds(i);
     RZEndTime = Timer(EndRZ)-DiagStimTime;  
     
     StartRZ = DiagRZStarts(i);
     RZStartTime = Timer(StartRZ)-DiagStimTime;  
     
     RZSpan = [RZStartTime RZEndTime]; 
     Ys = [y y];    
    
    plot(RZSpan, Ys, 'r', 'LineWidth', 6);
    Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part2'); 
    title(Title); 
    xlabel(XLabel); 
    ylabel(YLabel);
    
    hold on; 
    
        for z = 1:SpanLength
        
        LickPresent = DiagLicksinSpan (i, z);  
        
        if LickPresent == 1
            
            LickTime = DiagTimeofSpan(i, z); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
        end 
    
        hold on; 
        RewardIt = DiagRewards(i); 
        RewardTime = Timer(RewardIt)- DiagStimTime; %time at that reward occurrence
        plot(RewardTime, y, 'b.', 'MarkerSize', 16); 
       
end  

FigureSaveName = 'Diag_Trials_Part2.png'; 
saveas(gcf, FigureSaveName); 
close(DiagTrialsTwo); 



% 
% EndDiagStimTimes = zeros(NumDiagStim, 1); 
% 
% for i = 1:NumDiagStim
%     
%     DiagStimIt = DiagStimIts(i); 
%     DiagStimTime = Timer(DiagStimIt); 
%     
%     DiagStimDist = TotalDist(DiagStimIt);
%     EndDiagStim = find(AllDist>= DiagStimDist + 55); 
%     EndDiagStim = EndDiagStim(1); 
%     
%     EndDiagStimTime = Timer(EndDiagStim) - DiagStimTime;
%     EndDiagStimTimes(i, 1) = EndDiagStimTime; 
% 
% end 

% 
% YLabel = 'Speed (cm/s)';
% 
% %avg speed of trials 
% AvgSpeedinSpanForDiag = smooth(mean(DiagSpeedinSpan, 1)); 
% Height = max(AvgSpeedinSpanForDiag); 
% x = DiagTimeofSpan(1, :) ;
% 
% DiagAvgSpeed = figure('name', 'Average Speed For Diag Stim in Session'); 
% plot(x, AvgSpeedinSpanForDiag); 
% hold on; 
% y = linspace(0, Height); 
% plot(AvgEndDiagStimTime, y, 'r.');
%  Title = strcat(MouseName, '-', SeshNum, ':', 'Average Speed For Diagonal Stim In Session'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
%  
% 
% FigureSaveName = 'Average_Speed_For_Diag_Stim_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagAvgSpeed); 
% 
% DiagSeshSpeed = figure('name', 'Average Speed For Session'); 
% plot(x, AvgSpeedinSpanForVert, x, AvgSpeedinSpanForDiag);
% hold on; 
% plot(0, y, 'k.'); 
%  Title = strcat(MouseName, '-', SeshNum, ':', 'Average Speed For Session'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
% 
%     
% FigureSaveName = 'Average_Speed_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagSeshSpeed); 


cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 




end 



   




