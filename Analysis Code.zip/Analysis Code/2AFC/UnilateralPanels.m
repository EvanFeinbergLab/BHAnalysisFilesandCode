CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analysis Code'; 
DataPath = 'D:\Brooke\Data\Forced Choice Task\4Uni Panels'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles
    
    i; 
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = strfind(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), 1); 
    NameAndDate = cell((NumDateFiles-2), 2); 
    
    for x = 3:NumDateFiles
        
        DateFile = MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
           
    %sort files in order of date 
        
    FirstComma = strfind(DateFilePath, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = strfind(DateFilePath, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = strfind(DateFilePath, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = DateFilePath(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates((x-2), 1) = DateNum; 
    
    DateCell = cellstr(DateNumString); 
    NameCell = cellstr(DateFile); 
    
    NameAndDate((x-2), 1) = DateCell; 
    NameAndDate((x-2), 2) = NameCell;
     
    end
   
    AscendDates = sort(Dates); 
    NumDates = length(Dates); 
    AscendFiles = cell(NumDates, 1); 
    
    for x = 1:NumDates 
        
        FindIt = find(Dates == AscendDates(x));
        AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
    end
    
    AscendFiles = char(AscendFiles);
    ItNums = zeros(NumDates, 1);
     cd(MouseFolderDataPath); 
    
    for x = 1:NumDates 
                  
        FirstChar = AscendFiles(x, 1); 
        SecondChar = AscendFiles(x, 2);
        IsNum = str2num(FirstChar);
        IsNumTwo = str2num(SecondChar);
        
        if isempty(IsNumTwo) == 0
            
            TwoDigits = strcat(FirstChar, SecondChar); 
            IsNum = str2num(TwoDigits); 
            
        end 

        if isempty(IsNum) == 0 
        
            if IsNum ~= x
                
                OldName = AscendFiles(x, :); 
                OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                AscendFiles(x, 1) = num2str(x); 
                RevisedName = AscendFiles(x, :);
                RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                movefile(OldNamePath, RevisedName);
            end 
        
        else 
            
        OldName = AscendFiles(x, :); 
        OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
        ItString = num2str(x); 
        NewName = strcat(ItString, AscendFiles(x, :));
        NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 
       
        movefile(OldNamePath, NewNamePath);            

        end
        
    end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = strfind(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = strfind(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRightRewards = single.empty(500000, 0); 
 AllRightLicks = single.empty(500000, 0); 
  AllRightDistTime = single.empty(500000, 0); 
  AllLeftRewards = single.empty(500000, 0); 
 AllLeftLicks = single.empty(500000, 0); 
  AllLeftDistTime = single.empty(500000, 0); 
 AllTime = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(13*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 13*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,13*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 13);  
Zeros = zeros(1, 13); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 13 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:13)= StimInfo;
     
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end


TotalDist= StimPos(:, 1); 
Stims = StimPos(:, 3);
RightLicks = StimPos(:, 4); 
RightRewards = StimPos(:, 5);
RightRZDist = StimPos(:, 6);
LeftLicks = StimPos(:, 7); 
LeftRewards = StimPos(:, 8);
LeftRZDist = StimPos(:, 9);
StimSize = StimPos(:, 10); 
StimSide = StimPos(:, 11);
CueSide = StimPos(:, 12);
FlashSide = StimPos(:, 13);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllRightLicks(1:movnu) = RightLicks;
    AllRightReward(1:movnu) = RightRewards;    
    AllRightDistTime(1:movnu) = RightRZDist;
    AllLeftLicks(1:movnu) = LeftLicks;
    AllLeftReward(1:movnu) = LeftRewards;    
    AllLeftDistTime(1:movnu) = LeftRZDist;
    AllDist(1:movnu) = TotalDist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllTime(1:movnu) = Timer;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
   
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims;     
    AllRightRewards(StartFill: (StartFill+movnu) - 1) = RightRewards;   
    AllRightLicks(StartFill: (StartFill+movnu) - 1) = RightLicks;  
    AllRightDistTime(StartFill: (StartFill+movnu) - 1) = RightRZDist;
    AllLeftRewards(StartFill: (StartFill+movnu) - 1) = LeftRewards;   
    AllLeftLicks(StartFill: (StartFill+movnu) - 1) = LeftLicks;  
    AllLeftDistTime(StartFill: (StartFill+movnu) - 1) = LeftRZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = TotalDist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
Stims = AllStims';
RightLicks = AllRightLicks';
RightRewards = AllRightRewards';
RightRZDist = round(AllRightDistTime)'; 
LeftLicks = AllLeftLicks';
LeftRewards = AllLeftRewards';
LeftRZDist = round(AllLeftDistTime)'; 
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 1));   
NumVertStim = length(VertStimNum); 
VertStim = zeros(NumVertStim, 1); 

for i = 1:NumVertStim
    
    if i == 1 
        VertStim(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        VertStim(i, 1) = 0; 
    else 
        VertStim(i, 1) = VertStimNum(i);
    end 
    end 
end 

VertStim = nonzeros(VertStim);  
NumVertStim = length(VertStim); 



LeftVert = zeros(NumVertStim, 1); 
RightVert= zeros(NumVertStim, 1); 


for i = 2: NumVertStim-1 
    
    StimIt = VertStim(i); 
    
    StimType = StimSide(StimIt:StimIt+10); 
    StimType = mode(StimType); 
    
    if StimType == 1 
        
       RightVert(i, 1) = StimIt;  
        
    end 
    
    if StimType == 2 
        
        LeftVert(i, 1) = StimIt;
        
    end 
    
end 

LeftVert = nonzeros(LeftVert);
NumLeftVert = length(LeftVert); 
RightVert= nonzeros(RightVert); 
NumRightVert = length(RightVert);





LeftVertHits= zeros(NumLeftVert, 1); 
LeftVertLatency = zeros(NumLeftVert, 1);
LeftVertFAs = zeros(NumLeftVert, 1);
LeftVertMisses = zeros(NumLeftVert, 1);

for i = 1:NumLeftVert
    
    StimStart = LeftVert(i); 
    StimTime = Timer(StimStart); 
 
    WindowEnd = RightRZDist(StimStart:StimStart+50); 
    EndWindow = max(WindowEnd);
    StimEnd = find(WindowEnd == EndWindow); 
    StimEnd = (StimStart - 1) + StimEnd; 
    
    VertLick = find(RightLicks(StimStart:StimEnd) == 1);    
    WrongLick = find(LeftLicks(StimStart:StimEnd) == 1); 
    
    if isempty(VertLick) == 0 %if there was a vert lick 
        
        if isempty(WrongLick) == 0 %if there was also a diag lick 
            
            if VertLick(1) < WrongLick(1) %if the vert lick was first 
                
                LeftVertHits(i, 1) = StimStart; 
                
                FirstLick = VertLick(1); 
                VertLickIt = (StimStart - 1) + FirstLick; 
                VertLickTime = Timer(VertLickIt) - StimTime; 
                
                LeftVertLatency(i, 1) = VertLickTime; 
                
            else  %if diag lick first 
                
                LeftVertFAs(i, 1) = StimStart; 
                
            end   
            
        else %if there was only a vert lick 
            
             LeftVertHits(i, 1) = StimStart; 
                
                FirstLick = VertLick(1); 
                VertLickIt = (StimStart - 1) + FirstLick; 
                VertLickTime = Timer(VertLickIt) - StimTime; 
                
                LeftVertLatency(i, 1) = VertLickTime; 
            
        end   
        
    else %if there was no vert lick 
        
        if isempty(WrongLick) == 0 %if there was only a diag lick 
            
            LeftVertFAs(i, 1) = StimStart; 
            
        else %if there were no licks 
            
            LeftVertMisses(i, 1) = StimStart; 
            
        end 
    end   
end 


LeftVertHits = nonzeros(LeftVertHits); 
NumLeftVertHits = length(LeftVertHits); 

LeftVertLatency = nonzeros(LeftVertLatency); 
AvgLeftVertLatency = mean(LeftVertLatency)*1000 

LeftVertFAs = nonzeros(LeftVertFAs); 
LeftVertMisses = nonzeros(LeftVertMisses); 

NumLeftVertFAs = length(LeftVertFAs); 
NumLeftVertMisses = length(LeftVertMisses);




RightVertHits= zeros(NumRightVert, 1); 
RightVertLatency = zeros(NumRightVert, 1);
RightVertFAs = zeros(NumRightVert, 1);
RightVertMisses = zeros(NumRightVert, 1);

for i = 1:NumRightVert
    
    StimStart = RightVert(i); 
    StimTime = Timer(StimStart); 
 
    WindowEnd = RightRZDist(StimStart:StimStart+50); 
    EndWindow = max(WindowEnd);
    StimEnd = find(WindowEnd == EndWindow); 
    StimEnd = (StimStart - 1) + StimEnd; 
    
    VertLick = find(RightLicks(StimStart:StimEnd) == 1);    
    WrongLick = find(LeftLicks(StimStart:StimEnd) == 1); 
    
    if isempty(VertLick) == 0 %if there was a vert lick 
        
        if isempty(WrongLick) == 0 %if there was also a diag lick 
            
            if VertLick(1) < WrongLick(1) %if the vert lick was first 
                
                RightVertHits(i, 1) = StimStart; 
                
                FirstLick = VertLick(1); 
                VertLickIt = (StimStart - 1) + FirstLick; 
                VertLickTime = Timer(VertLickIt) - StimTime; 
                
                RightVertLatency(i, 1) = VertLickTime; 
                
            else  %if diag lick first 
                
                RightVertFAs(i, 1) = StimStart; 
                
            end   
            
        else %if there was only a vert lick 
            
             RightVertHits(i, 1) = StimStart; 
                
                FirstLick = VertLick(1); 
                VertLickIt = (StimStart - 1) + FirstLick; 
                VertLickTime = Timer(VertLickIt) - StimTime; 
                
                RightVertLatency(i, 1) = VertLickTime; 
            
        end   
        
    else %if there was no vert lick 
        
        if isempty(WrongLick) == 0 %if there was only a diag lick 
            
            RightVertFAs(i, 1) = StimStart; 
            
        else %if there were no licks 
            
            RightVertMisses(i, 1) = StimStart; 
            
        end 
    end   
end 


RightVertHits = nonzeros(RightVertHits); 
NumRightVertHits = length(RightVertHits); 

RightVertLatency = nonzeros(RightVertLatency); 
AvgRightVertLatency = mean(RightVertLatency)*1000 

RightVertFAs = nonzeros(RightVertFAs); 
RightVertMisses = nonzeros(RightVertMisses); 

NumRightVertFAs = length(RightVertFAs); 
NumRightVertMisses = length(RightVertMisses);





%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 2));   
NumDiagStim = length(DiagStimNum); 
DiagStim = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStim(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStim(i, 1) = 0; 
    else 
        DiagStim(i, 1) = DiagStimNum(i);
    end 
    end 
end 

DiagStim = nonzeros(DiagStim);  
NumDiagStim = length(DiagStim); 



RightDiag = zeros(NumDiagStim, 1); 
LeftDiag = zeros(NumDiagStim, 1); 

for i = 2: NumDiagStim-1 
    
    StimIt = DiagStim(i); 
    
    StimType = StimSide(StimIt:StimIt+10); 
    StimType = mode(StimType); 
    
    if StimType == 1 
        
       RightDiag(i, 1) = StimIt;  
        
    end 
    
    if StimType == 2 
        
        LeftDiag(i, 1) = StimIt;
        
    end 
    
end 

RightDiag = nonzeros(RightDiag);
NumRightDiag = length(RightDiag); 
LeftDiag = nonzeros(LeftDiag); 
NumLeftDiag = length(LeftDiag);




LeftDiagHits= zeros(NumLeftDiag, 1); 
LeftDiagLatency = zeros(NumLeftDiag, 1);
LeftDiagFAs = zeros(NumLeftDiag, 1);
LeftDiagMisses = zeros(NumLeftDiag, 1);

for i = 1:NumLeftDiag
    
    StimStart = LeftDiag(i); 
    StimTime = Timer(StimStart); 
 
    WindowEnd = LeftRZDist(StimStart:StimStart+50); 
    EndWindow = max(WindowEnd);
    StimEnd = find(WindowEnd == EndWindow); 
    StimEnd = (StimStart - 1) + StimEnd; 
    
    DiagLick = find(LeftLicks(StimStart:StimEnd) == 1);    
    WrongLick = find(RightLicks(StimStart:StimEnd) == 1); 
    
    if isempty(DiagLick) == 0 %if there was a Diag lick 
        
        if isempty(WrongLick) == 0 %if there was also a diag lick 
            
            if DiagLick(1) < WrongLick(1) %if the Diag lick was first 
                
                LeftDiagHits(i, 1) = StimStart; 
                
                FirstLick = DiagLick(1); 
                DiagLickIt = (StimStart - 1) + FirstLick; 
                DiagLickTime = Timer(DiagLickIt) - StimTime; 
                
                LeftDiagLatency(i, 1) = DiagLickTime; 
                
            else  %if diag lick first 
                
                LeftDiagFAs(i, 1) = StimStart; 
                
            end   
            
        else %if there was only a Diag lick 
            
             LeftDiagHits(i, 1) = StimStart; 
                
                FirstLick = DiagLick(1); 
                DiagLickIt = (StimStart - 1) + FirstLick; 
                DiagLickTime = Timer(DiagLickIt) - StimTime; 
                
                LeftDiagLatency(i, 1) = DiagLickTime; 
            
        end   
        
    else %if there was no Diag lick 
        
        if isempty(WrongLick) == 0 %if there was only a diag lick 
            
            LeftDiagFAs(i, 1) = StimStart; 
            
        else %if there were no licks 
            
            LeftDiagMisses(i, 1) = StimStart; 
            
        end 
    end   
end 


LeftDiagHits = nonzeros(LeftDiagHits); 
NumLeftDiagHits = length(LeftDiagHits); 

LeftDiagLatency = nonzeros(LeftDiagLatency); 
AvgLeftDiagLatency = mean(LeftDiagLatency)*1000 

LeftDiagFAs = nonzeros(LeftDiagFAs); 
LeftDiagMisses = nonzeros(LeftDiagMisses); 

NumLeftDiagFAs = length(LeftDiagFAs); 
NumLeftDiagMisses = length(LeftDiagMisses);




RightDiagHits= zeros(NumRightDiag, 1); 
RightDiagLatency = zeros(NumRightDiag, 1);
RightDiagFAs = zeros(NumRightDiag, 1);
RightDiagMisses = zeros(NumRightDiag, 1);

for i = 1:NumRightDiag
    
    StimStart = RightDiag(i); 
    StimTime = Timer(StimStart); 
 
    WindowEnd = LeftRZDist(StimStart:StimStart+50); 
    EndWindow = max(WindowEnd);
    StimEnd = find(WindowEnd == EndWindow); 
    StimEnd = (StimStart - 1) + StimEnd; 
    
    DiagLick = find(LeftLicks(StimStart:StimEnd) == 1);    
    WrongLick = find(RightLicks(StimStart:StimEnd) == 1); 
    
    if isempty(DiagLick) == 0 %if there was a Diag lick 
        
        if isempty(WrongLick) == 0 %if there was also a diag lick 
            
            if DiagLick(1) < WrongLick(1) %if the Diag lick was first 
                
                RightDiagHits(i, 1) = StimStart; 
                
                FirstLick = DiagLick(1); 
                DiagLickIt = (StimStart - 1) + FirstLick; 
                DiagLickTime = Timer(DiagLickIt) - StimTime; 
                
                RightDiagLatency(i, 1) = DiagLickTime; 
                
            else  %if diag lick first 
                
                RightDiagFAs(i, 1) = StimStart; 
                
            end   
            
        else %if there was only a Diag lick 
            
             RightDiagHits(i, 1) = StimStart; 
                
                FirstLick = DiagLick(1); 
                DiagLickIt = (StimStart - 1) + FirstLick; 
                DiagLickTime = Timer(DiagLickIt) - StimTime; 
                
                RightDiagLatency(i, 1) = DiagLickTime; 
            
        end   
        
    else %if there was no Diag lick 
        
        if isempty(WrongLick) == 0 %if there was only a diag lick 
            
            RightDiagFAs(i, 1) = StimStart; 
            
        else %if there were no licks 
            
            RightDiagMisses(i, 1) = StimStart; 
            
        end 
    end   
end 


RightDiagHits = nonzeros(RightDiagHits); 
NumRightDiagHits = length(RightDiagHits); 

RightDiagLatency = nonzeros(RightDiagLatency); 
AvgRightDiagLatency = mean(RightDiagLatency)*1000 

RightDiagFAs = nonzeros(RightDiagFAs); 
RightDiagMisses = nonzeros(RightDiagMisses); 

NumRightDiagFAs = length(RightDiagFAs); 
NumRightDiagMisses = length(RightDiagMisses);





AllVertFAs = [LeftVertFAs; RightVertFAs]; 
AllDiagFAs = [RightDiagFAs; LeftDiagFAs]; 
AllFAs = [AllVertFAs; AllDiagFAs];
AllFAs = sort(AllFAs, 'ascend');

AllVertMisses = [LeftVertMisses; RightVertMisses]; 
AllDiagMisses = [LeftDiagMisses;RightDiagMisses]; 
AllMisses = [AllVertMisses; AllDiagMisses];
AllMisses = sort(AllMisses, 'ascend');

AllVertUnRewarded = [AllVertFAs; AllVertMisses]; 
AllVertUnRewarded = sort(AllVertUnRewarded, 'ascend');
NumVertUnRewarded = length(AllVertUnRewarded); 
AllDiagUnRewarded = [AllDiagFAs; AllDiagMisses]; 
AllDiagUnRewarded = sort(AllDiagUnRewarded, 'ascend');
NumDiagUnRewarded = length(AllDiagUnRewarded); 

VertRewarded = [RightVertHits; LeftVertHits];
VertRewarded = sort(VertRewarded, 'ascend');
NumVertHits = length(VertRewarded); 
DiagRewarded = [LeftDiagHits; RightDiagHits];
DiagRewarded = sort(DiagRewarded, 'ascend');
NumDiagHits = length(DiagRewarded); 



VertStim = VertStim(1:NumVertStim - 1); 
DiagStim = DiagStim(1:NumDiagStim - 1); 
AllStim = [VertStim; DiagStim]; 
AllStim = sort(AllStim, 'ascend'); 
NumAllStim = length(AllStim); 

ProbVertBeforeVertRewarded = zeros(NumVertHits-5, 5);

for i = 4:NumVertHits
    
    VertIt = VertRewarded(i); 
    TotalIt = find(AllStim == VertIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Vert = find(VertStim == StimType); 
        
        if isempty(Vert) == 0 
            
            ProbVertBeforeVertRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbVertBeforeVertRewarded = mean(ProbVertBeforeVertRewarded) ;


ProbDiagBeforeVertUnRewarded = zeros(NumVertUnRewarded-5, 5);

for i = 4:NumVertUnRewarded 
    
    VertIt = AllVertUnRewarded(i); 
    TotalIt = find(AllStim == VertIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Diag = find(DiagStim == StimType); 
        
        if isempty(Diag) == 0 
            
            ProbDiagBeforeVertUnRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbDiagBeforeVertUnRewarded = mean(ProbDiagBeforeVertUnRewarded); 



ProbDiagBeforeDiagRewarded = zeros(NumDiagHits-5, 5);

for i = 4:NumDiagHits
    
    DiagIt = DiagRewarded(i); 
    TotalIt = find(AllStim == DiagIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Diag = find(DiagStim == StimType); 
        
        if isempty(Diag) == 0 
            
            ProbDiagBeforeDiagRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbDiagBeforeDiagRewarded = mean(ProbDiagBeforeDiagRewarded); 




ProbVertBeforeDiagUnRewarded = zeros(NumDiagUnRewarded-5, 5);

for i = 4:NumDiagUnRewarded 
    
    VertIt = AllDiagUnRewarded(i); 
    TotalIt = find(AllStim == VertIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Vert = find(VertStim == StimType); 
        
        if isempty(Vert) == 0 
            
            ProbVertBeforeDiagUnRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbVertBeforeDiagUnRewarded = mean(ProbVertBeforeDiagUnRewarded); 




AllLeft = [LeftDiag; LeftVert]; 
AllLeft = sort(AllLeft, 'ascend'); 
AllLeftHits = [LeftDiagHits; LeftVertHits]; 
AllLeftHits = sort(AllLeftHits, 'ascend');
NumLeftHits = length(AllLeftHits); 

AllRight = [RightDiag; RightVert]; 
AllRight = sort(AllRight, 'ascend'); 
AllRightHits = [RightDiagHits; RightVertHits]; 
AllRightHits = sort(AllRightHits, 'ascend');
NumRightHits = length(AllRightHits); 



ProbLeftBeforeLeftRewarded = zeros(NumLeftHits-5, 5);

for i = 4:NumLeftHits
    
    LeftIt = AllLeftHits(i); 
    TotalIt = find(AllStim == LeftIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Left = find(AllLeft == StimType); 
        
        if isempty(Left) == 0 
            
            ProbLeftBeforeLeftRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbLeftBeforeLeftRewarded = mean(ProbLeftBeforeLeftRewarded); 


ProbLeftHitBeforeLeftHit = zeros(NumLeftHits-5, 5);

for i = 4:NumLeftHits
    
    LeftIt = AllLeftHits(i); 
    TotalIt = find(AllStim == LeftIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Left = find(AllLeftHits == StimType); 
        
        if isempty(Left) == 0 
            
            ProbLeftHitBeforeLeftHit(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbLeftHitBeforeLeftHit = mean(ProbLeftHitBeforeLeftHit); 



ProbRightBeforeRightRewarded = zeros(NumRightHits-5, 5);

for i = 4:NumRightHits
    
    RightIt = AllRightHits(i); 
    TotalIt = find(AllStim == RightIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Right = find(AllRight == StimType); 
        
        if isempty(Right) == 0 
            
            ProbRightBeforeRightRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbRightBeforeRightRewarded = mean(ProbRightBeforeRightRewarded); 


ProbRightHitBeforeRightHit = zeros(NumRightHits-5, 5);

for i = 4:NumRightHits
    
    RightIt = AllRightHits(i); 
    TotalIt = find(AllStim == RightIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Right = find(AllRightHits == StimType); 
        
        if isempty(Right) == 0 
            
            ProbRightHitBeforeRightHit(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbRightHitBeforeRightHit = mean(ProbRightHitBeforeRightHit); 




AllLeftUnRewarded = [LeftVertFAs; LeftVertMisses; LeftDiagFAs; LeftDiagMisses]; 
AllLeftUnRewarded = sort(AllLeftUnRewarded, 'ascend'); 
NumLeftUnRewarded = length(AllLeftUnRewarded); 
AllRightUnRewarded = [RightVertFAs; RightVertMisses; RightDiagFAs; RightDiagMisses]; 
AllRightUnRewarded =  sort(AllLeftUnRewarded, 'ascend');
NumRightUnRewarded = length(AllRightUnRewarded); 


ProbRightBeforeLeftUnRewarded = zeros(NumLeftUnRewarded-5, 5);

for i = 4:NumLeftUnRewarded
    
    LeftIt = AllLeftUnRewarded(i); 
    TotalIt = find(AllStim == LeftIt); 
    PeriStimSpan = AllStim(TotalIt-4:TotalIt); 
    SpanLength = length(PeriStimSpan); 
   
    for x = 1:SpanLength
    
        StimType = PeriStimSpan(x); 
        
        Right = find(AllRight == StimType); 
        
        if isempty(Right) == 0 
            
            ProbRightBeforeLeftUnRewarded(i-3, x) = 1;  
            
        end 
               
    end    
end 

PeriProbRightBeforeLeftUnRewarded = mean(ProbRightBeforeLeftUnRewarded); 


%test for # iterations per 1 ms 
  
VertIt =  VertStim(2); %iteration of each reward
    StimTime = round(Timer(VertIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  VertIt - ItBefore;   
     

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 10; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;

 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;
 
 StartSpan=   VertIt- (RevAnalysisLength);
 EndSpan = VertIt+ (FwdAnalysisLength);
  
 SpanLength = EndSpan - StartSpan; 
  
  
%peristimulus and reward lick behavior for all vert 

VertLicksinSpan = zeros(SpanLength, NumVertStim); 
LeftLicksDuring = zeros(SpanLength, NumVertStim); 
VertTimeofSpan = zeros(SpanLength, NumVertStim); 
VertSpeedinSpan = zeros(SpanLength, NumVertStim); 

for i = 2:NumVertStim-1
    
    VertIt =  VertStim(i);
    StimTime = Timer(VertIt); 
   
    StartSpan=   VertIt- (RevAnalysisLength);
    EndSpan =  VertIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after
    Blocks = SpanLength/ItPerMs;

    VertLicksinSpan(:, i) = RightLicks((StartSpan+1):EndSpan);
    LeftLicksDuring(:, i) = LeftLicks((StartSpan+1):EndSpan);
    VertSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
    VertTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
    
    for y = 1:SpanLength
         VertTimeofSpan(y, i) = VertTimeofSpan(y, i) - StimTime; 
    end 
    
    VertTimeofSpan(:, i) ;
end


VertLicksinSpan = VertLicksinSpan';  
VertTimeofSpan = VertTimeofSpan';  
VertSpeedinSpan = VertSpeedinSpan';
LeftLicksDuring = LeftLicksDuring'; 



%peristimulus and reward lick behavior for diag stim 

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 10; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan; 
 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;

DiagLicksinSpan = zeros(SpanLength, NumDiagStim); 
DiagTimeofSpan = zeros(SpanLength, NumDiagStim); 
DiagSpeedinSpan = zeros(SpanLength, NumDiagStim); 
RightLicksDuring = zeros(SpanLength, NumDiagStim); 

for i = 2:NumDiagStim-1
    
    DiagIt = DiagStim(i);   
    DiagStimTime = Timer(DiagIt);          
   
    StartSpan=  DiagIt- (RevAnalysisLength);
    EndSpan = DiagIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

         DiagLicksinSpan(:, i) = LeftLicks((StartSpan+1):EndSpan);
         RightLicksDuring(:, i) = RightLicks((StartSpan+1):EndSpan);
         DiagSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
         DiagTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);   
         
         for y = 1:SpanLength
            
         DiagTimeofSpan(y, i) = DiagTimeofSpan(y, i) - DiagStimTime; 
         
         end 
 
end

DiagLicksinSpan = DiagLicksinSpan';
DiagTimeofSpan = DiagTimeofSpan'; 
DiagSpeedinSpan = DiagSpeedinSpan'; 
RightLicksDuring =  RightLicksDuring'; 






CurrentDir = pwd; 
FindStart = strfind(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Forced Choice Task';
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(AnalyzedPath, '\', SaveString); 
cd(SavePath); 

FindSeshNum = strfind(SavePath, '\'); 
FindSeshNum = FindSeshNum(end); 
SeshNumIt = FindSeshNum + 1; 
SeshNum = strcat('Session', SavePath(SeshNumIt))




XLabel = 'Peristimulus Time (s)';
YLabel = 'Average Licks'; 

AvgLicksinSpanForVert = smooth(mean(VertLicksinSpan, 1));
AvgLeftLicksDuring = smooth(mean(LeftLicksDuring, 1)); 

x = VertTimeofSpan(2, :); 

VertAvgLicks = figure('name', 'Average Licks For Vert Stim In Session'); 
plot(x, AvgLicksinSpanForVert, x, AvgLeftLicksDuring); 
hold on; 
Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Vert Stim In Session'); 
title(Title); 
legend('Right(Correct) Licks', 'Left(False) Licks'); 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Average_Licks_For_Vert_Stim_In_Session.png'; 
saveas(gcf, FigureSaveName); 
close(VertAvgLicks); 




AvgLicksinSpanForDiag = smooth(mean(DiagLicksinSpan, 1));
AvgRightLicksDuring = smooth(mean(RightLicksDuring, 1)); 

x = DiagTimeofSpan(2, :); 

DiagAvgLicks = figure('name', 'Average Licks For Diag Stim In Session'); 
plot(x, AvgLicksinSpanForDiag, x, AvgRightLicksDuring); 
hold on; 
Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Diag Stim In Session'); 
title(Title); 
legend('Left(Correct) Licks', 'Right(False) Licks'); 
xlabel(XLabel); 
ylabel(YLabel);

FigureSaveName = 'Average_Licks_For_Diag_Stim_In_Session.png'; 
saveas(gcf, FigureSaveName); 
close(DiagAvgLicks); 




VertRewardRate = NumVertHits/NumVertStim; 
DiagRewardRate = NumDiagHits/NumDiagStim; 

EarnedRewardRates = figure('name', 'Total Reward Rates'); 
bar(1, VertRewardRate);
hold on;
bar(2, DiagRewardRate, 'r');
legend('Vertical Stim', 'Diagonal Stim'); 

FigureSaveName = 'Total_Reward_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(EarnedRewardRates);




LeftVertHitRate = NumLeftVertHits/NumVertStim; 
RightVertHitRate = NumRightVertHits/NumVertStim; 
LeftDiagHitRate = NumLeftDiagHits/NumDiagStim; 
RightDiagHitRate = NumRightDiagHits/NumDiagStim; 

EarnedRewardRates = figure('name', 'Earned Reward Rate For UniLateral Stim'); 
bar(1, LeftVertHitRate);
hold on;
bar(2, RightVertHitRate, 'r');
hold on; 
bar(3, LeftDiagHitRate);
hold on;
bar(4, RightDiagHitRate, 'r');
legend('Left Vert Stim', 'Right Vert Stim', 'Left Diag Stim', 'Right Diag Stim'); 
set(gca,'XTickLabel',{'LV', 'RV', 'LD', 'RD'})


FigureSaveName = 'Lateral_Reward_Rates.png'; 
saveas(gcf, FigureSaveName); 
close(EarnedRewardRates);




% 
% LickLatencies = figure('name', 'Lick Latencies'); 
% bar(1, AvgVertCorrLatency);
% hold on;
% bar(2, AvgVertPanelLatency, 'r');
% hold on;
% bar(3, AvgDiagCorrLatency, 'g');
% hold on;
% bar(4, AvgDiagPanelLatency, 'm');
% legend('Vert Corridors', 'Vert Panels','Diag Corridors', 'Diag Panels', 'Location', 'NorthOutside'); 
% 
% FigureSaveName = 'Lick_Latencies.png'; 
% saveas(gcf, FigureSaveName); 
% close(LickLatencies);



PeriStimProb = figure('name', 'Peristimulus Probabilities'); 
subplot(2,2,1); 
bar(PeriProbVertBeforeVertRewarded);
legend('Vert Around Vert Rewarded', 'Location', 'NorthOutside'); 
hold on;
subplot(2,2,2);
bar(PeriProbDiagBeforeVertUnRewarded, 'r');
legend('Diag Around Vert UnRewarded', 'Location', 'NorthOutside'); 
hold on; 
subplot(2,2,3);
bar(PeriProbDiagBeforeDiagRewarded, 'g');
legend('Diag Around Diag Rewarded', 'Location', 'NorthOutside'); 
hold on; 
subplot(2,2,4);
bar(PeriProbVertBeforeDiagUnRewarded, 'b');
legend('Vert Around Diag UnRewarded', 'Location', 'NorthOutside'); 

FigureSaveName = 'Peristimulus_Probabilities.png'; 
saveas(gcf, FigureSaveName); 
close(PeriStimProb);




VertHitsFrac = NumVertHits/NumVertStim; 
DiagHitsFrac = NumDiagHits/NumDiagStim;

if VertHitsFrac == 0
    VertHitsFrac = 0.01
end
if VertHitsFrac == 1
    VertHitsFrac = 0.99
end

if DiagHitsFrac == 0
    DiagHitsFrac = 0.01
end
if DiagHitsFrac == 1
    DiagHitsFrac = 0.99
end

NumVertFAs = length(AllVertFAs); 
VertFAFrac = NumVertFAs/NumVertStim; 
NumDiagFAs = length(AllDiagFAs); 
DiagFAFrac = NumDiagFAs/NumDiagStim;

if VertFAFrac == 0
    VertFAFrac = 0.01
end
if VertFAFrac == 1
    VertFAFrac = 0.99
end

if DiagFAFrac == 0
    DiagFAFrac = 0.01
end
if DiagFAFrac == 1
    DiagFAFrac = 0.99
end

VertHitNormInv = norminv(VertHitsFrac,0,1)
VertFANormInv = norminv(VertFAFrac,0,1)
VertDPrime = VertHitNormInv - VertFANormInv
DiagHitNormInv = norminv(DiagHitsFrac,0,1)
DiagFANormInv = norminv(DiagFAFrac,0,1)
DiagDPrime = DiagHitNormInv - DiagFANormInv



% NumVertCorrHits = length(VertEarnedCorrRewards); 
% VertCorrHitFrac = NumVertCorrHits/NumVertCorridors; 
% NumDiagCorrHits = length(DiagEarnedCorrRewards); 
% DiagCorrHitFrac = NumDiagCorrHits/NumDiagCorridors;
% 
% if VertCorrHitFrac == 0
%     VertCorrHitFrac = 0.01
% end
% if VertCorrHitFrac == 1
%     VertCorrHitFrac = 0.99
% end
% 
% if DiagCorrHitFrac == 0
%     DiagCorrHitFrac = 0.01
% end
% if DiagCorrHitFrac == 1
%     DiagCorrHitFrac = 0.99
% end
% 
% NumVertCorrFAs = length(VertCorrFAs); 
% VertCorrFAFrac = NumVertCorrFAs/NumVertCorridors; 
% NumDiagCorrFAs = length(DiagCorrFAs); 
% DiagCorrFAFrac = NumDiagCorrFAs/NumDiagCorridors;
% 
% if VertCorrFAFrac == 0
%     VertCorrFAFrac = 0.01
% end
% if VertCorrFAFrac == 1
%     VertCorrFAFrac = 0.99
% end
% 
% if DiagCorrFAFrac == 0
%     DiagCorrFAFrac = 0.01
% end
% if DiagCorrFAFrac == 1
%     DiagCorrFAFrac = 0.99
% end
% 
% 
% VertCorrHitNormInv = norminv(VertCorrHitFrac,0,1)
% VertCorrFANormInv = norminv(VertCorrFAFrac,0,1)
% VertCorrDPrime = VertCorrHitNormInv - VertCorrFANormInv
% DiagCorrHitNormInv = norminv(DiagCorrHitFrac,0,1)
% DiagCorrFANormInv = norminv(DiagCorrFAFrac,0,1)
% DiagCorrDPrime = DiagCorrHitNormInv - DiagCorrFANormInv
% 
% 
% 
% NumVertPanelHits = length(LeftVertHits); 
% VertPanelHitFrac = NumVertPanelHits/NumVertPanels; 
% NumDiagPanelHits = length(DiagPanelRewards); 
% DiagPanelHitFrac = NumDiagPanelHits/NumDiagPanels;
% 
% if VertPanelHitFrac == 0
%     VertPanelHitFrac = 0.01
% end
% if VertPanelHitFrac == 1
%     VertPanelHitFrac = 0.99
% end
% 
% if DiagPanelHitFrac == 0
%     DiagPanelHitFrac = 0.01
% end
% if DiagPanelHitFrac == 1
%     DiagPanelHitFrac = 0.99
% end
% 
% NumLeftVertFAs = length(LeftVertFAs); 
% VertPanelFAFrac = NumLeftVertFAs/NumVertPanels; 
% NumDiagPanelFAs = length(DiagPanelFAs); 
% DiagPanelFAFrac = NumDiagPanelFAs/NumDiagPanels;
% 
% if VertPanelFAFrac == 0
%     VertPanelFAFrac = 0.01
% end
% if VertPanelFAFrac == 1
%     VertPanelFAFrac = 0.99
% end
% 
% if DiagPanelFAFrac == 0
%     DiagPanelFAFrac = 0.01
% end
% if DiagPanelFAFrac == 1
%     DiagPanelFAFrac = 0.99
% end
% 
% VertPanelHitNormInv = norminv(VertPanelHitFrac,0,1)
% VertPanelFANormInv = norminv(VertPanelFAFrac,0,1)
% VertPanelDPrime = VertPanelHitNormInv - VertPanelFANormInv
% DiagPanelHitNormInv = norminv(DiagPanelHitFrac,0,1)
% DiagPanelFANormInv = norminv(DiagPanelFAFrac,0,1)
% DiagPanelDPrime = DiagPanelHitNormInv - DiagPanelFANormInv




AllDPrimes = figure('name', 'D Primes for All Stim'); 
bar(1, VertDPrime, 'k');
hold on;
% bar(2, VertCorrDPrime, 'r');
% hold on; 
% bar(3, VertPanelDPrime, 'b');
% hold on;
bar(2, DiagDPrime, 'k');
% hold on; 
% bar(5, DiagCorrDPrime, 'm');
% hold on;
% bar(6, DiagPanelDPrime, 'c');

legend('All Vert', 'All Diag'); 
% legend('All Vert', 'Vert Corridors', 'Vert Panels', 'All Diag', 'Diag Corridors', 'Diag Panels'); 

FigureSaveName = 'All_D_Primes.png'; 
saveas(gcf, FigureSaveName); 
close(AllDPrimes);




% YLabel = 'Trial'; 
% 
% Trials = (1:NumVertStim);
% VertTrialsOne = figure('name','Vertical Trials Part1'); 
% 
% for i = 1:(round(NumVertStim/2)) 
%     
%     i; 
%     x = VertTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%       
%     hold on; 
%        
%     VertIt = VertStim(i);
%     StimTime = Timer(VertIt);
%      
%      EndRZ = VertCorrEnds(i);
%      RZEndTime = Timer(EndRZ)-StimTime;  
%      
%      StartRZ = VertRZStarts(i);
%      RZStartTime = Timer(StartRZ)-StimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y]; 
%      
%      plot(RZSpan, Ys, 'Color', [0 0.75 0], 'LineWidth', 6);
%      Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part1'); 
%      title(Title); 
%      xlabel(XLabel); 
%      ylabel(YLabel); 
%      
%   hold on; 
%     
%     for a = 1:SpanLength
%                
%         LickPresent = VertLicksinSpan(i, a);  
%         
%         if LickPresent == 1
%             
%             LickTime = VertTimeofSpan(i, a); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%     end  
%     
%     hold on; 
%     
%      RewardIt = VertCorridorRewards(i); 
%      
%      if RewardIt ~=0
%      
%      RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
%      plot(RewardTime, y, 'r.', 'MarkerSize', 16); 
%      
%      else
%          
%        plot(RZEndTime, y, 'r.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%      end
%     
% end  
% 
% FigureSaveName = 'Vert_Trials_Part1.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertTrialsOne); 
% 
% 
% 
% 
% VertTrialTwo = figure('name','Vert Trials Part2'); 
% 
% for i = round((NumVertStim/2))+1 : NumVertStim-1 
%     
% 
%     x = VertTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%     hold on; 
%        
%     VertIt = VertStim(i);
%     StimTime = Timer(VertIt);
%      
%      EndRZ = VertCorrEnds(i);
%      RZEndTime = Timer(EndRZ)-StimTime;  
%      
%      StartRZ = VertRZStarts(i);
%      RZStartTime = Timer(StartRZ)-StimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y]; 
%      
%      plot(RZSpan, Ys, 'Color', [0 0.75 0], 'LineWidth', 6);
%      Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part2'); 
%      title(Title); 
%      xlabel(XLabel); 
%      ylabel(YLabel);
%      
%   hold on; 
%     
%     for a = 1:SpanLength
%                
%         LickPresent = VertLicksinSpan(i, a);  
%         
%         if LickPresent == 1
%             
%             LickTime = VertTimeofSpan(i, a); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%     end  
%     
%     hold on; 
%     
%      RewardIt = VertCorridorRewards(i);
%      
%      if RewardIt ~= 0
%      
%      RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
%      plot(RewardTime, y, 'r.', 'MarkerSize', 16); 
%      
%       else
%          
%        plot(RZEndTime, y, 'r.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%      
%      end
%     
% end 
% 
% FigureSaveName = 'Vert_Trials_Part2.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertTrialTwo); 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% Trials = (1:NumDiagStim);
% YLabel = 'Trial'; 
% 
% DiagTrialsOne = figure('name','Diag Trials Part1'); 
% 
% for i = 1:round((NumDiagStim/2)) 
%     
%    
%     x = DiagTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%        
%     hold on;     
%      
%     DiagStimIt = DiagStim(i); 
%     DiagStimTime = Timer(DiagStimIt); 
%      
%      EndRZ = DiagRZEnds(i);
%      RZEndTime = Timer(EndRZ)-DiagStimTime;  
%      
%      StartRZ = DiagRZStarts(i);
%      RZStartTime = Timer(StartRZ)-DiagStimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y]; 
%     
%     plot(RZSpan, Ys, 'r', 'LineWidth', 6);
%     Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
% 
%     hold on; 
%     
%         for z = 1:SpanLength
%         
%         LickPresent = DiagLicksinSpan (i, z);  
%         
%         if LickPresent == 1
%             
%             LickTime = DiagTimeofSpan(i, z); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%         end  
%     
%         hold on; 
%         
%          RewardIt = DiagRewards(i); 
%          
%          if RewardIt ~=0
%          
%          RewardTime = Timer(RewardIt)-DiagStimTime; %time at that reward occurrence
%          plot(RewardTime, y, 'b.', 'MarkerSize', 16); 
%          
%          else
%          
%         plot(RZEndTime, y, 'b.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%          
%          end
%     
% end 
% 
% FigureSaveName = 'Diag_Trials_Part1.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagTrialsOne); 
% 
% 
% 
% DiagTrialsTwo = figure('name','DiagTrials Part2'); 
% 
% for i = round((NumDiagStim/2))+1 : NumDiagStim-1 
% 
%       x = DiagTimeofSpan(2, :); 
%     y = i; 
%     plot(x, y); 
%        
%     hold on;     
%      
%     DiagStimIt = DiagStim(i); 
%     DiagStimTime = Timer(DiagStimIt); 
%     
%      EndRZ = DiagRZEnds(i);
%      RZEndTime = Timer(EndRZ)-DiagStimTime;  
%      
%      StartRZ = DiagRZStarts(i);
%      RZStartTime = Timer(StartRZ)-DiagStimTime;  
%      
%      RZSpan = [RZStartTime RZEndTime]; 
%      Ys = [y y];    
%     
%     plot(RZSpan, Ys, 'r', 'LineWidth', 6);
%     Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part2'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
%     
%     hold on; 
%     
%         for z = 1:SpanLength
%         
%         LickPresent = DiagLicksinSpan (i, z);  
%         
%         if LickPresent == 1
%             
%             LickTime = DiagTimeofSpan(i, z); 
%             plot(LickTime, y, 'k.', 'MarkerSize', 8);
%             
%         end 
%         end 
%     
%         hold on;
%         
%         RewardIt = DiagRewards(i); 
%         
%         if RewardIt ~=0
%         
%         RewardTime = Timer(RewardIt)- DiagStimTime; %time at that reward occurrence
%         plot(RewardTime, y, 'b.', 'MarkerSize', 16);
%         
%          else
%          
%        plot(RZEndTime, y, 'b.', 'MarkerSize', 16);    %for free rewarded forced choice
%      
%      
%         end
%        
% end  
% 
% FigureSaveName = 'Diag_Trials_Part2.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagTrialsTwo); 




cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 


end 



   




