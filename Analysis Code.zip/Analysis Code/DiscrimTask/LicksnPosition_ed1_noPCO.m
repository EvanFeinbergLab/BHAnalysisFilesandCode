function [behavior] = LVdata_noPCO(Movie)

movfile = fopen(Movie);
movsize = dir(Movie);
movbyt = movsize.bytes;

movnu = movbyt/(4*6) 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

test = fread(movfile); 

%read red stamp dat 
fseek(movfile, 0, 'bof');
redStamp = zeros(1,1);

for i = 1:movnu
  
    reddat = fread(movfile, 1,'uint32',0,'ieee-be');
    redStamp(1,i)= reddat;
    fseek(movfile,2*4+4*4+9*4+2*2,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end

%read PCO iterations
fseek(movfile, 4, 'bof'); %start at beginning with no BYTE offset
PCOit = zeros(1,1); 

for i = 1:movnu
  
    PCOitdat = fread(movfile, 1,'uint32',0,'ieee-be');
    PCOit(1,i)= PCOitdat;
    fseek(movfile,4+4*4+9*4+2*2+4,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end

PCOitsize = length(PCOit); %size equal to number to frames

%read eye cam iterations -- a couple frame delay from when saved on other computer
frewind(movfile); %goes back to beginning of file
fseek(movfile, 4*2 ,'bof');
EYEit = zeros(movnu,1); 

for i = 1:movnu
    
    EYEiteration = fread(movfile, 1 , 'uint32', 0, 'ieee-be');
    EYEit(i, 1)= EYEiteration;
    fseek(movfile, 4*4+9*4+2*2+2*4,'cof'); 
end

EYEfirstit = EYEit(1, 1)
EYElastit = EYEit(movnu, 1)

%read LV time stamp 
%time in hour minutes seconds format 00:00:00
frewind(movfile); 
fseek(movfile, 3*4 ,'bof');
LVT = zeros(1,movnu);

for i = 1:movnu

    LVtime = fread(movfile, 1 , 'single', 0, 'ieee-be'); 
    LVT(1,i)= LVtime; 
    fseek(movfile,3*4+9*4+2*2+3*4,'cof');
   
end

maxsec = LVT(1, movnu)
minsec = LVT(1, 1)
totalsec = (maxsec - minsec)
LVFR = movnu/totalsec
 

%read stim info and mouse position:
%Total Dist traveled, Random Number Interval, Rand Dist Generated  
% Training Mode - (0)Running, (1)RewardBothStim,NoLick, (2)RewardBoth,Lick, (3) Reward Correct
%Stim, Lick?, Correct?, Lick Window, Latency(ms)

%!!empty array are full of eights !!

frewind(movfile);
fseek(movfile,3*4+4*4,'bof');
StimPos = zeros(movnu, 12);  
Zeros = zeros(1, 12); 

for i = 1:movnu
    
    Stiminfo = fread(movfile, 9 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(i, 1:9)= StimInfo;
    
    Mode = StimPos (i, 4); 
    Stim = StimPos (i, 5); 
    Lick = StimPos (i, 6); 
    Correct = StimPos (i, 7);
     
%     
%     if (Stim == 0) && (Lick == 1) && (Correct == 0)
%         result = 2; % 'false pos'
%         StimPos(i, 10) = result;
%     end 
%     
%     if (Mode == 3) & (Stim > 0) && (Lick == 0) && (Correct == 0)
%         result = 3;  %'miss'
%         StimPos(i, 10) = result;
%     end 
%     
%     if (Mode == 4) & (Stim == 1) && (Lick == 0) && (Correct == 0)
%         result = 3;  %'miss'
%         StimPos(i, 10) = result; 
%     end 
%     
%       if (Mode == 4) & (Stim == 2) && (Lick == 0) && (Correct == 0)
%         result = 4;  %'correctly ignored'
%         StimPos(i, 10) = result;
%      end 
%     
%      if (Mode == 4) & (Stim == 2) && (Lick == 1) && (Correct == 0)
%         result = 5;  %'wrong'
%         StimPos(i, 10) = result;
%      end  

     if  StimPos(i, 1) == 8
        StimPos(i, :) = Zeros;        
     end

    StimPos(i, 10) = i; 
    StimPos(i, 11) = round(LVT(1, i), 2); 
    
%     if  StimPos(i, 1) ~= 8
%         if StimLickEvents == 0 
%             StimLickEvents = [StimPos(i, :)]; 
%         else 
%             StimLickEvents = [StimLickEvents; StimPos(i, :)];
%         end
%     end
%    

    fseek(movfile,2*2+3*4+4*4,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end

StimPos;

LicknLatency = zeros (1, 4); 

for i = 1:movnu

LicknLatency (i, 1) = StimPos(i, 6); 
LicknLatency (i, 2) = StimPos(i, 9);
LicknLatency (i, 3) = StimPos(i, 11);

Times (i, 1) = StimPos(i, 11);

end


for i = 1: movnu
    
    if (LicknLatency (i, 2) > 0) &&  (LicknLatency ((i-1), 2) == 0)
        
        div = (LicknLatency (i, 2))/ 100; 
        StimTime = (LicknLatency (i, 3)) - div;  
        
        StimIt = find(Times > StimTime); 
        StimAppear = StimIt(1) - 1;  
        
        LicknLatency (StimAppear, 4) = 1; 
    end 
end 
             
LicknLatency; 

figure;
x = LicknLatency(: , 3); 
Licks = LicknLatency(: , 1); 
Stims = LicknLatency(: , 4);
plot (x, Licks, x, Stims); 

StimNum = find((LicknLatency(:, 4) == 1)) 
NumStim = length(StimNum); 
LickProbBefore = zeros(NumStim, 1); 
LickProbAfter = zeros(NumStim, 1); 

LickWindow = 50; %50 iterations = 500 ms 

for i = 1:NumStim 
    StimIt = StimNum(i); 
    
    if StimIt < LickWindow  
        StimIt = StimIt*2; 
    else if StimIt > (movnu - LickWindow )
        StimIt = round(StimIt /2); 
        end 
    end 
    
     LicksBeforeStim = LicknLatency(((StimIt-LickWindow ):(StimIt-1)), 1); 
	 LicksAfterStim = LicknLatency(((StimIt+1):(StimIt+ LickWindow)), 1);
       
    
    NumLicksBefore = length(find(LicksBeforeStim == 1)); 
    NumLicksAfter = length(find(LicksAfterStim == 1)); 
    
    TotalBefore = length(LicksBeforeStim); 
    TotalAfter = length(LicksAfterStim); 
    
    LickProbBefore(i, 1) = NumLicksBefore/ TotalBefore; 
    LickProbAfter(i, 1) = NumLicksAfter/ TotalAfter; 
end 

LickProbBefore; 
LickProbAfter; 
AvgLickBeforeProb = mean(LickProbBefore)
AvgLickAfterProb = mean(LickProbAfter)

RandRange = zeros(LickWindow , 1); 
random = 1 + (movnu-1).*rand(100,1);   
randomit = round (1 + (100-1).*rand(LickWindow ,1));

for i = 1:LickWindow 
    
randomnum = round(random(randomit(i))); 

RandomTime = LicknLatency (randomnum, 3); 
RandSearch = rand;  

if randomnum < LickWindow 
    RandRange = LicknLatency (randomnum:(randomnum + (LickWindow-1)), 1); 
else if randomnum > (movnu-LickWindow)
    RandRange = LicknLatency (randomnum:(randomnum - (LickWindow-1)), 1); 
else 
    if RandSearch > 0.5 
        RandRange = LicknLatency (randomnum:(randomnum + (LickWindow-1)), 1); 
    else 
        RandRange = LicknLatency ((randomnum -(LickWindow-1)):randomnum, 1); 
    end 
    end 
end 

%exclude the interval around a stim appearance ??

RandLicks = find(RandRange == 1);

NumRandLicks = length(RandLicks); 
TotalRange = length(RandRange);

RandLickProb = NumRandLicks/TotalRange; 
RandLickProbs (i, 1) = RandLickProb; 

end 

RandLickProbs; 
AvgRandLickProb = mean(RandLickProbs)

FilePathName = fopen(movfile) %give name of file currently open 
NameDate = FilePathName(12:(end - 11))


filepath = strcat('\', NameDate); 
path = strcat(pwd, filepath) 

folderexists = exist(NameDate(7:end)); 

if folderexists == 7; %folder exists 
    dlmwrite(path, AvgRandLickProb, ' ', '-append')
end 


[LickEventsSize eleven] = size(StimLickEvents);
EventTypes = zeros(LickEventsSize, 1); 

EventLatency = find(StimLickEvents(:, 10) == 3); 
LatencyThreshold = StimLickEvents(EventLatency(1,1), 8); 

TwosEvents = find(StimLickEvents(:, 10) == 2); %iterations of stimlickevents in which there was a #2 event
TwosEventsSize = length(TwosEvents); 
NotMissEvents = zeros(TwosEventsSize, 1); 

for i = 1:TwosEventsSize; 
    TwosEventIt = TwosEvents(i, :);  
    LatencyOfEventBefore = StimLickEvents((TwosEvents(i, :)-1), 9); 
    LatencyOfTwoEventsBefore = StimLickEvents((TwosEvents(i, :)-2), 9);
    
    if  (LatencyOfEventBefore < LatencyThreshold && LatencyOfEventBefore ~= 0) 
        NotMissEvents(i, :) = TwosEventIt; 
    end 
    
end 

MissEventsIt = TwosEvents - NotMissEvents; 
MissEventsSize = length(MissEventsIt); 

NumJustLickEvents = length(nonzeros(NotMissEvents));
numJustLickEvents = NumJustLickEvents*2; % this is true as long as the trend of two "misses" after a "hit" occurs
NumMissEvents = (TwosEventsSize - numJustLickEvents) / 3;  
ThreesEvents = find(StimLickEvents(:, 9) > 0); 
ThreesEventsSize = length(ThreesEvents); 
TotalStimLickEvents = NumMissEvents + ThreesEventsSize

for i = 1:MissEventsSize-1
    
    if MissEventsIt(i, :) == 0 
        MissEventsIt((i+1), :) = 0; 
    end 
end 

JustLickEventsIt = nonzeros(MissEventsIt)
JustLickEventsItSize = length(JustLickEventsIt)
LickEventsSize

EventTypeandFrame = zeros(movnu, 2); 
 
for i = 1:LickEventsSize
    
    EventMode = StimLickEvents(i, 4);
    EventStim = StimLickEvents(i, 5);
    LatencyThres = StimLickEvents(i, 8); 
            
    if StimLickEvents(i, 10) == 2
        Eventtype = 2; %false pos in all cases 
        EventTypeandFrame(i, :) = Eventtype;
        EventTypeandFrame(i, :) = StimLickEvents(i, 10)
    end 
    
    if StimLickEvents(i, 10) == 3
        
        latencyOfevent = StimLickEvents((i+3), 9); 
   
        if latencyOfevent > LatencyThres && EventMode == 2 && EventStim > 0
            Eventtype = 3; %missed 
            EventTypes(i, :) = Eventtype; 
        end 
        
        if latencyOfevent > LatencyThres && EventMode == 3 && EventStim == 1 
            Eventtype = 3; %missed 
            EventTypes(i, :) = Eventtype; 
        end
        
        if latencyOfevent > LatencyThres && EventMode == 3 && EventStim == 2 
            Eventtype = 4; %correctly ignored
            EventTypes(i, :) = Eventtype; 
        end
        
        i = i + 4; %skip ahead
        
    end 
    
    if StimLickEvents(i, 10) == 3
        
        latencyOfevent = StimLickEvents((i+3), 9); 
        
        if latencyOfevent < LatencyThres && EventMode == 2 && EventStim > 0 
            Eventtype = 6; % hit 
            EventTypes(i, :) = Eventtype; 
        end 
        
        if latencyOfevent < LatencyThres && EventMode == 3 && EventStim == 1 
            Eventtype = 6; %hit 
            EventTypes(i, :) = Eventtype; 
        end 
        
        if latencyOfevent < LatencyThres && EventMode == 3 && EventStim == 2 
            Eventtype = 5; %wrong
            EventTypes(i, :) = Eventtype; 
        end 

       i = i + 6;  % skip ahead -- may need to change 
    end 
    
    Eventtype 
end 

EventTypes


%find each event instance -- return the index numbers in ann array  
Ignored = find(StimPos == 2);
FalsePos = find(StimPos == 3);
Missed = find(StimPos == 4);
Hit = find(StimPos == 5);
EventHit = find(StimPos == 6);
%calc how many of each event instance 
sizeIg = size(Ignored); 
sizeFP = size(FalsePos); 
sizeMiss = size(Missed); 
sizeHit = size(Hit); 









