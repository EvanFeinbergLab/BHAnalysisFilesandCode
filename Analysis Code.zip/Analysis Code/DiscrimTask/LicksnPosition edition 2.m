function [behavior] = LicksnPosition(Movie)

movfile = fopen(Movie);
movsize = dir(Movie);
movbyt = movsize.bytes;

movnu = movbyt/(6*4+8) 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie


fseek(movfile, 6*4 ,'bof');
Timer = zeros(movnu, 1);

for i = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(i, 1)= Time; 
    fseek(movfile,6*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 7);  
Zeros = zeros(1, 7); 

for i = 1:movnu
    
    Stiminfo = fread(movfile, 6 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(i, 1:6)= StimInfo;
     
    StimPos(i, 7) = i; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end
Velocity = zeros(movnu, 1); 

for i = 2:movnu; 
    
%instant running speed 

DeltaDist = StimPos(i, 1) - StimPos((i-1), 1); 
DeltaTime = Timer(i, 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

StimnLick = zeros(movnu, 5); 

for i = 1:movnu

StimnLick(i, 1) = StimPos(i, 3); %stim
StimnLick(i, 2) = StimPos(i, 4);%lick
StimnLick(i, 3) = StimPos(i, 5); %reward
StimnLick(i, 4) = Timer(i, 1); 
StimnLick(i, 5) = i; 

end

StimnLick;

%plots lick occurrences around each stim 
figure;
x = StimnLick(:, 4); 
Licks = StimnLick(: , 2)/2; 
Stims = StimnLick(: , 1);
Rewards = StimnLick(:, 3);
%Speed = StimnLick(:, 4); 

plot (x, Licks, x, Stims, x, Rewards); 

Licks = StimnLick(: , 2); 
% 
% fileID = fopen('Stim.txt','a+');
% fprintf(fileID,'%f\n', StimnLick(:, 1));
% fclose(fileID);
% 
% fileID = fopen('Lick.txt','a+');
% fprintf(fileID,'%f\n', StimnLick(:, 2));
% fclose(fileID);
% 
% fileID = fopen('Reward.txt','a+');
% fprintf(fileID,'%f\n', StimnLick(:, 3));
% fclose(fileID);
% 
% fileID = fopen('Time.txt','a+');
% fprintf(fileID,'%f\n', StimnLick(:, 4));
% fclose(fileID);
% 
% fileID = fopen('DistAtLick.txt','a+');
% fprintf(fileID,'%f\n', StimPos(:, 6));
% fclose(fileID);
% 
% 
% fileID = fopen('TotalDist.txt','a+');
% fprintf(fileID,'%f\n', StimPos(:, 1));
% fclose(fileID);

%find occurences of the beginning and end of the reward zone 

DistAtLick = StimPos(:, 6); 
DistAtLick = round(DistAtLick);
   
RZStart = find(DistAtLick(:, 1) ==  30); 
NumStart = length(RZStart);

for i = 1:NumStart
    
    if i == 1 
    RZStarts(i, 1) = RZStart (i);  

    else
        if RZStart (i)- RZStart (i-1) == 1
        RZStarts(i, 1) = 0; 
    else 
        RZStarts(i, 1) = RZStart (i);
    end 
    end 
end 

RZStarts = nonzeros(RZStarts)
NumStarts = length(RZStarts)

RZEnd = find(DistAtLick(:, 1) ==  70); 
NumEnd = length(RZEnd);

for i = 1:NumEnd
    
    if i == 1 
    RZEnds(i, 1) = RZEnd (i);  

    else
        if RZEnd (i)- RZEnd (i-1) == 1
        RZEnds(i, 1) = 0; 
    else 
        RZEnds(i, 1) = RZEnd (i);
    end 
    end 
end 

RZEnds = nonzeros(RZEnds)
NumEnds = length(RZEnds)


%finds occurences of  vertical stimuli
StimNum = find((Stims(:, 1) == 2));   
NumStim = length(StimNum); 
StimIts = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIts(i, 1) = StimNum(i);  

    else
        if StimNum(i)-StimNum(i-1) == 1
        StimIts(i, 1) = 0; 
    else 
        StimIts(i, 1) = StimNum(i);
    end 
    end 
end 

StimIts = nonzeros(StimIts) 
NumStim = length(StimIts)

%test for # iterations per 10 ms 
  
    StimIt = StimIts(1); %iteration of each reward
    StimTime = Timer(StimIt) ; %time at that reward occurrence 
    BeforeReward = StimTime - 1; 
    StartRewardSpan = find(Timer == BeforeReward);  %iteration __ ms before reward 
    SpanLengthBefore = StimIt - StartRewardSpan;  
    NumBlocks = 10; 
    ItPerBlock = SpanLengthBefore/NumBlocks;  


%finds occurences of reward
RewardNum = find((Rewards(:, 1) == 1));   
NumReward = length(RewardNum); 
RewardIts = zeros(NumReward, 1); 

for i = 1:NumReward 
    
    if i == 1 
        RewardIts(i, 1) = RewardNum(i);  

    else
        if RewardNum(i)-RewardNum(i-1) == 1
        RewardIts(i, 1) = 0; 
    else 
        RewardIts(i, 1) = RewardNum(i);
    end 
    end 
end 

RewardIts = nonzeros(RewardIts) 
NumReward = length(RewardIts)

% %determining where saving was cut off 
% 
% StimMin = StimIts(1); 
% StimMax = StimIts(end); 
% RZStartMin = RZStarts(1); 
% RZStartMax = RZStarts(end);
% RZEndMin = RZEnds(1); 
% RZEndMax = RZEnds(end); 
% RewardMin = RewardIts(1); 
% RewardMax = RewardIts(end);
% 
% Mins = [StimMin RZStartMin RZEndMin RewardMin]; 
% Maxs = [StimMax RZStartMax RZEndMax RewardMax]; 
% 
% FirstSaved = min(Mins); 
% FirstDataSaved = find(Mins == FirstSaved); 
% 
% if FirstDataSaved == 2 %RZStart was saved first 
%     
%     StimIts = [0;  StimIts]; %replacing with zeros for now 
%     
% end 
% 
% if FirstDataSaved == 3 %RZEnd was saved first 
%     
%    if NumReward == NumEnds 
%      
%         StimIts = [0;  StimIts]; 
%         RZStarts = [0;  RZStarts];       
%     end 
%     
%    if NumReward < NumEnds 
%         
%         StimIts = [0;  StimIts]; 
%         RZStarts = [0;  RZStarts]; 
%         RewardIts = [0;  RewardIts]; 
%     end 
%     
% end
% 
% if FirstDataSaved == 4 %Reward was saved first
%     
%    if NumReward == NumEnds 
%         
%         StimIts = [0;  StimIts]; 
%         RZStarts = [0; RZStarts];
%     end 
%     
%    if NumReward > NumEnds 
%         
%         StimIts = [0;  StimIts]; 
%         RZStarts = [0;   RZStarts]; 
%         RZEnds = [0;  RZEnds];
%     end 
%     
% end
% 
% LastSaved = max(Maxs); 
% LastDataSaved = find(Maxs == LastSaved); 
% 
% if LastDataSaved == 1 %stim saved last 
%     
%     RewardIts = [RewardIts; 0]; 
%     RZStarts = [RZStarts; 0]; 
%     RZEnds = [RZEnds; 0];
%     
% end 
% 
% if LastDataSaved == 2 %RZStart saved last 
%     
%     RZEnds = [RZEnds; 0];
%     RewardIts = [RewardIts; 0];  
%     
% end
% 
% if LastDataSaved == 3
%     
%    if NumReward < NumEnds 
%         
%         RewardIts = [RewardIts; 0]; 
%     end 
%     
% end
% 
% if LastDataSaved == 4
%     
%     if NumReward > NumEnds 
%         
%         RZEnds = [RZEnds;  0]; 
%     end 
%     
% end
% 
%  
% NumStim = length(StimIts)
% 
% NumStarts = length(RZStarts)
% 
% NumEnds = length(RZEnds)
%   
% NumReward = length(RewardIts)
    
%peri reward lick behavior

 BeforeRewardAnalysisSpan = 30; %milliseconds
 AfterRewardAnalysisSpan = 10; 
 RewardAnalysisSpan = BeforeRewardAnalysisSpan + AfterRewardAnalysisSpan; 
 IterationsPerSpan = NumBlocks*ItPerBlock; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;

LicksSpanReward = zeros(1, RewardAnalysisLength);
LickForEachReward = zeros(NumReward, RewardAnalysisLength);
TimeofRewardLick = zeros(NumReward, RewardAnalysisLength);


for i = 1:NumReward 
            
    StimIt = StimIts(i);
    RewardIt = RewardIts(i); %iteration of each reward
    
    if StimIt > 0 && RewardIt > 0 
        
    StimTime = Timer(StimIt);
    
    RewardTime = Timer(RewardIt); %time at that reward occurrence
     
    BeforeReward = RewardTime - BeforeRewardAnalysisSpan; 
    StartRewardSpan = find(Timer == BeforeReward);  %iteration __ ms before reward 
    
    AfterReward = RewardTime + AfterRewardAnalysisSpan; 
    EndRewardSpan = find(Timer == AfterReward) ; %iteration __ ms after reward 
    
    SpanLength = EndRewardSpan - StartRewardSpan;  %span of iterations before and after
    Blocks = SpanLength/ItPerBlock; 
      
%     %licks before reward
%     for x = 0:(NumBlocksBefore - 1)
%      
%     LicksinBlockBefore = Licks(StartRewardSpan+(x*2): StartRewardSpan+(x*2 + 1)); 
%     LicrementsBefore = sum(LicksinBlockBefore);
%  
%     LickForEachReward(i, (x+1)) = LicrementsBefore; 
%     
%     TimeofRewardLick(i, (x+1)) = Timer(StartRewardSpan+(x*2)); 
%     end
%     
%     %lick at reward
%     LicksSpanReward(i, HalfwayPoint) = Licks(RewardIt);
%     TimeofRewardLick(i, HalfwayPoint) = Timer(RewardIt);
         
    for y = 1:Blocks 
    
    LicksinBlockAfter = Licks(StartRewardSpan +(y*2 - 1): StartRewardSpan +(y*2)); 
    LicrementsAfter = sum(LicksinBlockAfter);
 
    LickForEachReward(i, y) = LicrementsAfter; 
   
    TimeofRewardLick(i, y) = Timer(StartRewardSpan+(y*2 - 1));
    end   
    
    end
    
                
end

TimeofRewardLick;
LickForEachReward;


figure;    
for i = 1:NumReward %individual stim instances 
    
    x = TimeofRewardLick(i, :); 
    y = LickForEachReward(i, :);  
    
    subplotI = subplot(12, 1, i); 
    plot(x, y); 
    hold on; 
    
        
    StimIt = StimIts(i); %iteration of each reward
    
    if StimIt == 0
             
        plot(TimeofRewardLick(i, 1), 0, 'gx');  
    else     
         
        StimTime = Timer(StimIt); %time at that reward occurrence
        plot(StimTime, 1, 'gx'); 
    end
       
    StartRZ = RZStarts(i); %iteration of the start of the reward zone 
    
    if StartRZ == 0
        
        plot(TimeofRewardLick(i, 50), 0, 'go'); 
        
    else 
        RZStartTime = Timer(StartRZ);      
        plot(RZStartTime, 0, 'go');  
    end    
    
        
    EndRZ = RZEnds(i); %iteration of the end of the reward zone 
    if EndRZ == 0
       
    plot(TimeofRewardLick(i, end), 0 , 'ro'); 
    
    else
       
    RZEndTime = Timer(EndRZ); 
    plot(RZEndTime, 1, 'ro'); 
    end
    
    RewardIt = RewardIts(i); %iteration of each reward
        
    if RewardIt == 0
            
     plot(TimeofRewardLick(i, (end-50)), 0, 'kx');
        
    else 
            
    RewardTime = Timer(RewardIt); %time at that reward occurrence
    plot(RewardTime, 1, 'kx'); 
    end
    
end 

FilePathName = fopen(movfile);
[PathName, FileName, Ext] = fileparts(FilePathName); 
MouseName = PathName((end - 37):(end - 33));
FilePart = FileName(1); 

prompt = 'What is the number of the day/session?'; 
DayNum = num2str(input(prompt)); 
NumDay = strcat('Day', DayNum)

FigureSaveName = strcat(MouseName, '_', NumDay,'_' , FilePart )

saveas(gcf, FigureSaveName)


