CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analysis Code\DiscrimTask'; 
DataPath = 'D:\Brooke\Data\Discrim Tasks\Discrim Only'; 
AnalysisPath = strcat(CodePath, '\', 'Analyzed');
        
MiceDataFolders = dir(DataPath);
MiceAnalyFolders = dir(AnalysisPath); 
NumMiceDataFiles = length(MiceDataFolders);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceDataFiles
    

    %Check if file has been accessed        
   
    cd(DataPath);
    MouseFolder = MiceDataFolders(i).name; 
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
        
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), (NumMiceDataFiles-2)); 
    
    for x = 3:NumDateFiles 
        
        DateFile =  MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile); 
        cd(DateFilePath); 
  
        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt');
       NumStamps = length(AccessStamp); 
       
       if isempty(AccessStamp) == 0 
       
       for z = 1:NumStamps
           
           StampName = AccessStamp(z).name; 
           PrimeStamp = findstr(StampName, 'Prime'); 
       end 
       
       end 
           
        if isempty(AccessStamp) == 1| isempty(PrimeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           

        end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess; 
        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
        
     end 
    
     PathsToAnalyze; 

    end
   
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRewards = single.empty(500000, 0); 
 AllLicks = single.empty(500000, 0); 
  AllTime = single.empty(500000, 0); 
 AllRZ = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(10*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 10*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,10*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 11);  
Zeros = zeros(1, 11); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 10 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:10)= StimInfo;
     
    StimPos(y, 11) = y; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end 

StimnLick = zeros(movnu, 5); 

StimnLick(:, 1) = StimPos(:, 3); %stim
StimnLick(:, 2) = StimPos(:, 4);%lick
StimnLick(:, 3) = StimPos(:, 5); %reward
StimnLick(:, 4) = Timer(:, 1); 
StimnLick(:, 5) = StimPos(:, 6);
StimnLick(:, 6) = StimPos(:, 1);

Stims = StimnLick(:, 1); 
Licks = StimnLick(:, 2); 
Rewards = StimnLick(:, 3);
Timer = StimnLick(:, 4);
RZDist = StimnLick(:, 5);
Dist= StimnLick(:, 6);
StimSize = StimPos(:, 7); 
StimSide = StimPos(:, 8);
CueSide = StimPos(:, 9);
StimMotion = StimPos(:, 10);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllLicks(1:movnu) = Licks;
    AllReward(1:movnu) = Rewards;
    AllTime(1:movnu) = Timer;
    AllRZ(1:movnu) = RZDist;
    AllDist(1:movnu) = Dist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims; 
    
    AllRewards(StartFill: (StartFill+movnu) - 1) = Rewards;   
    AllLicks(StartFill: (StartFill+movnu) - 1) = Licks;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
    AllRZ(StartFill: (StartFill+movnu) - 1) = RZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = Dist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
RZDist = round(AllRZ)'; 
Stims = AllStims';
Licks = AllLicks';
Rewards = AllRewards';
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

%finds occurences of  all stimuli
AllNumStim = find((Stims(:, 1) > 0));   
AllStimNum = length(AllNumStim); 
AllStimIts = zeros(AllStimNum, 1); 

for i = 1:AllStimNum 
    
    if i == 1 
        AllStimIts(i, 1) = AllNumStim(i);  

    else
        if AllNumStim(i)- AllNumStim(i-1) < 10
        AllStimIts(i, 1) = 0; 
    else 
        AllStimIts(i, 1) = AllNumStim(i);
    end 
    end 
end 

AllStimIts = nonzeros(AllStimIts);  
AllStimNum = length(AllStimIts);

TotalTime = Timer(end) - Timer(1);

StimPeriodicity = TotalTime/AllStimNum; 


%find deriv/change in value of licks 

derivLicks = diff(Licks); 
NumDiffLicks = length(derivLicks); 

DerivLicks  = abs(derivLicks); 
DerivLicks = [0; DerivLicks]; 
%Licks = DerivLicks; 

% occurrences of lick windows 

Windows = find(RZDist > 100); 
NumWindows = length(Windows); 
LickWindows = zeros(NumWindows, 1); 

for i = 1:NumWindows
    
    if i == 1 
   LickWindows(i, 1) = Windows(i);  

    else
        if  Windows (i)-  Windows (i-1) == 1
         LickWindows(i, 1) = 0; 
    else 
         LickWindows(i, 1) =  Windows(i);
    end 
    end 
end 

 LickWindows = nonzeros(LickWindows); 
NumLickWindows = length(LickWindows)

%occurrences of RZ starts and ends 

RZ = find(RZDist ~= 0); 
NumRZ = length(RZ); 
RZs = zeros(NumRZ, 1); 

for i = 1:NumRZ
    
    if RZDist(i) < 100 
                   
        if i == 1 
       RZs(i, 1) = RZ (i);  

        else
            if RZ (i)- RZ (i-1) == 1
            RZs(i, 1) = 0; 
        else 
            RZs(i, 1) = RZ (i);
        end 
        end 
        
    else 
        
       RZs(i, 1) = 0; 
       
    end 
        
end 

RZs = nonzeros(RZs); 
NumRZs = length(RZs);  

%get rid of ones that are actually lick windows 

for i =  1:NumRZs
    
    RZAfter = RZs(i)+5 ;
    RZDistAfter = RZDist(RZAfter); 
    
    if RZDistAfter > 100 
        
        RZs(i, 1) = 0; 
        
    end
    
end 

RZs = nonzeros(RZs); 
NumRZs = length(RZs); 

%get rid of repeat starts -- toggling at beginning of RZ
tempRZs = zeros(NumRZs, 1); 

for i = 1:NumRZs
    
    if i == 1 
    tempRZs(i, 1) = RZs (i);  

    else
        if RZs (i)- RZs (i-1) < 100
        tempRZs(i, 1) = 0; 
    else 
        tempRZs(i, 1) = RZs (i);
    end 
    end 
end 

RZs = nonzeros(tempRZs); 
NumRZs = length(RZs);

tempRZs = zeros(NumRZs, 1); 

for i= 1:NumRZs
    
    RZValue = RZDist(RZs(i)); 
    RZValueBefore = RZDist(RZs(i) - 1); 
    
    if RZValueBefore == 0 && RZValue < 5; 
        
      tempRZs(i, 1) = RZs(i); 
      
    end 
    
    
end 

RZs = nonzeros(tempRZs); 
NumRZs = length(RZs); 

MaxRZDist = max(RZDist); 
if MaxRZDist > 70 
    
    MaxRZDist = 70; 
    
end 

RZStarts = zeros((NumRZs-2), 1); 
RZEnds = zeros((NumRZs-2), 1); 

for i = 2:(NumRZs-1) %ignore first and last trial 
    
    i; 
    if i == NumRZs
        
    RZValues = RZDist(RZs(i): end);
        
    else 
    
    RZValues = RZDist(RZs(i): RZs(i+1)-1);
    end 
        
    SearchRZStart = find(RZValues >= 30) ;
    if isempty(SearchRZStart) == 0
        
    Start = SearchRZStart(1); 
    RZStart = RZs(i)+(Start-1);
    RZStarts(i, 1) = RZStart; 
    
    end
   
    SearchRZEnd = find(RZValues >= MaxRZDist); 
    
    if isempty(SearchRZEnd) == 0 
        
    End = SearchRZEnd(1); 
    RZEnd = RZs(i)+(End-1);
    RZEnds(i, 1) = RZEnd; 
    
    end
end 

RZStarts;
RZStarts = nonzeros(RZStarts); 
NumStarts = length(RZStarts); 
RZEnds = nonzeros(RZEnds); 
NumEnds = length(RZEnds);  

%elim early starts

EarlyStarts = find(RZStarts < RZEnds(1)); 
FirstStart = EarlyStarts(end); 
NumEarlyStarts = length(EarlyStarts); 

for i = 1:(NumEarlyStarts-1) 
    
    RZStarts(i) = 0; 
    
end 

RZStarts = nonzeros(RZStarts); 
NumStarts = length(RZStarts); 



%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 2));   
NumStim = length(VertStimNum); 
StimIts = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIts(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        StimIts(i, 1) = 0; 
    else 
        StimIts(i, 1) = VertStimNum(i);
    end 
    end 
end 

StimIts = nonzeros(StimIts);  
StimIts(1) = 0;
StimIts(end) = 0;
StimIts = nonzeros(StimIts); 
NumDefaultStims = length(StimIts); 

VertStimLength = zeros(NumDefaultStims, 1); 
VertStimSide = zeros(NumDefaultStims, 1); 
VertCueSide = zeros(NumDefaultStims, 1); 
VertStimMotion = zeros(NumDefaultStims, 1); 


for i = 1:NumDefaultStims 
    
    VertStimLength(i, 1) = StimLength(StimIts(i), 1); 
    VertStimSide(i, 1) = StimSide(StimIts(i), 1);
    VertCueSide(i, 1) = CueSide(StimIts(i), 1);
    VertStimMotion(i, 1) = StimMotion(StimIts(i), 1);

end 

VertDefaultIts = StimIts; 
VertVariantIts = LickWindows;
NumVertVariants = length(VertVariantIts) 



%discarding early info  

StartAtFirstRZ = find(VertDefaultIts < RZStarts(1)); 
NumEarlyStims = length(StartAtFirstRZ); 
for i = 1:(NumEarlyStims - 1) 
    
    VertDefaultIts(i) = 0;    
end 
VertDefaultIts = nonzeros(VertDefaultIts); 


    StartsBefore = find(RZStarts < VertDefaultIts(1)); 
    NumStartsBefore = length(StartsBefore); 
    
    for i = 1: (NumStartsBefore)
        
        RZStarts(i) = 0;        
    end 
    
    RZStarts = nonzeros(RZStarts); 
    NumStarts = length(RZStarts); 


%discarding info after the last RZStart

if StimIts(end) > RZStarts(end)   
    StimIts(end) = 0;    
end 
VertDefaultIts= nonzeros(VertDefaultIts); 
NumDefaultStims = length(VertDefaultIts); 


%get same num of starts and ends 

 TempStarts = zeros(NumEnds, 1);  

if NumStarts > NumEnds
        
    for i = 1:NumEnds
        
        StartsBefore = find(RZStarts < RZEnds(i));        
        TempStarts(i, 1) = RZStarts(StartsBefore(end), 1); 
        
    end   
    RZStarts = TempStarts; 
    
end 

NumStarts = length(RZStarts);


TempEnds = zeros(NumStarts, 1);  

if NumEnds > NumStarts
    
    for i = 1:NumStarts
        
        if i < NumStarts 
        
        EndsBefore = find(RZEnds < RZStarts(i+1));        
        TempEnds(i, 1) = RZEnds(EndsBefore(end), 1); 
        
        else 
            
         TempEnds(i, 1)=  RZEnds(end);   
        
        end  
    end 
    
    RZEnds = TempEnds;
    
end 
 
NumEnds = length(RZEnds);


%eliminate extra Stims 
if NumDefaultStims > NumStarts 
    
    tempStim = zeros(NumStarts, 1); 

for i = 1:NumStarts
    
    i; 
    LastStim = find(VertDefaultIts < RZStarts(i)); 
    LastStim = LastStim(end); 
    
    tempStim(i, 1) = VertDefaultIts(LastStim); 
end

VertDefaultIts= tempStim; 
end 

    
tempStim = zeros(NumStarts, 1); 
    
for i = 1:NumStarts
        
        StimBefore = find(VertDefaultIts < RZStarts(i)); 
        
        if isempty(StimBefore) == 0 
        StimBefore = StimBefore(end); 
        
         tempStim(i, 1) = VertDefaultIts(StimBefore); 
         
        end 
         
end   
VertDefaultIts = tempStim; 


%finds occurences of reward
RewardIts = zeros(NumStarts, 1); 
DefaultHits = zeros(NumStarts, 1); 


for i = 1: NumStarts 
     
    StartRZ = RZStarts(i); 
    EndRZ = RZEnds(i); 
    
    Span = Licks(StartRZ:EndRZ); 
    LickWithin = find(Span == 1); 
    
    if isempty(LickWithin) == 0
        
        FirstLick = LickWithin(1); 
        FirstLickIt = (FirstLick - 1) + StartRZ; 
    	RewardIts(i, 1) = FirstLickIt;  
        DefaultHits(i, 1) = FirstLickIt;
        
    else
        
        if i < NumStarts
        RewardAfter =  RZDist(EndRZ:RZStarts(i+1)); 
        else 
         RewardAfter =  RZDist(EndRZ:end); 
        end 
        
        CorridorEnd = max(RewardAfter); 
        RewardDist = find(RewardAfter == CorridorEnd); 
        RewardDist = RewardDist(1); 
        FreeRewardIt = (RewardDist - 1) + EndRZ;  
        RewardIts(i, 1) = FreeRewardIt; 
    end 
end



RZStarts = nonzeros(RZStarts);
NumStarts = length(RZStarts)  

RZEnds = nonzeros(RZEnds);
NumEnds = length(RZEnds)

RewardIts = nonzeros(RewardIts);
NumReward = length(RewardIts) 

VertDefaultIts = nonzeros(VertDefaultIts);
NumDefaultStims = length(VertDefaultIts)




%lick analysis for vert variants 

VariantHits = zeros(NumVertVariants, 1); 
VariantFA = zeros(NumVertVariants, 1); 

for i = 1:NumVertVariants

    VertVariantIt = VertVariantIts(i); 
    StartWindow = find(RZDist(VertVariantIt:VertVariantIt+50) ~= 0);
    StartWindow = StartWindow(1); 
    StartWindowIt = (VertVariantIt + StartWindow) - 1; 
    StartWindowIt = StartWindowIt - 1; 
    
    EndWindowValue = max(RZDist(VertVariantIt:VertVariantIt+50));   
    EndWindowIt = find(RZDist(VertVariantIt:VertVariantIt+50) == EndWindowValue); 
    EndLickWindowIt = (VertVariantIt + EndWindowIt) - 1; 
    
    LickedInWindow = find(Licks(StartWindowIt:EndLickWindowIt) == 1); 

    if isempty(LickedInWindow == 0)
        
        VariantHits(i, 1) = i; 
        
    else 
        
        FullWindow = EndWindowValue; 
        
    end 
    
end

VariantHits = nonzeros(VariantHits); 

%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 1));   
NumDiagStim = length(DiagStimNum); 
DiagStimIts = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStimIts(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStimIts(i, 1) = 0; 
    else 
        DiagStimIts(i, 1) = DiagStimNum(i);
    end 
    end 
end 

DiagStimIts = nonzeros(DiagStimIts);
DiagStimIts(1) = 0; %ignore the first trial 
DiagStimIts(end) = 0;
DiagStimIts = nonzeros(DiagStimIts);
NumDiagStim = length(DiagStimIts)

DiagVariantStim = zeros(NumDiagStim, 1); 
DiagDefaultStim = zeros(NumDiagStim, 1);

for i = 1:NumDiagStim 
    
     DiagVariant = StimLength(DiagStimIts(i)-10, 1); 
     
     if DiagVariant > 0
         
         DiagVariantStim(i, 1) = DiagStimIts(i); 
         
     else 
                  
        DiagDefaultStim(i, 1) =  DiagStimIts(i); 
        
     end 
    
end 

DiagVariantStimIts = nonzeros(DiagVariantStim); 
DiagDefaultStimIts = nonzeros(DiagDefaultStim);
NumDiagVariants = length(DiagVariantStimIts); 
NumDiagDefaults = length(DiagDefaultStimIts); 




%calc behavioral d-prime for defaults

DefaultFAs = zeros(NumDiagDefaults , 1); 

for i = 1: NumDiagDefaults 
 
    DiagDefaultStimIt = DiagDefaultStimIts(i);    
    DiagStimDist = TotalDist(DiagDefaultStimIt);
  
    StartDiagStim = find(TotalDist>= DiagStimDist + 30); 
    StartDiagStimIt = StartDiagStim(1); 
    
    EndDiagStim = find(TotalDist>= DiagStimDist + 60); 
    EndDiagStimIt = EndDiagStim(1); 
    
    LickInDiag = find(Licks(StartDiagStimIt:EndDiagStimIt) == 1); 
    
    if length(LickInDiag)> 1
        
        LickIt = LickInDiag(1); 
        DefaultFAs(i, 1) = LickIt; 
        
    end                
end 

DefaultFAs = nonzeros(DefaultFAs); 
NumDefaultFAs = length(DefaultFAs) 
DefaultFAFrac = NumDefaultFAs/NumDiagDefaults 


DefaultHits = nonzeros(DefaultHits); 
NumDefaultHits = length(DefaultHits) 
DefaultHitFrac = NumDefaultHits/NumDefaultStims


if DefaultFAFrac == 0
    DefaultFAFrac = 0.01
end
if DefaultFAFrac == 1
    DefaultFAFrac = 0.99
end



if DefaultHitFrac == 0
    DefaultHitFrac = 0.01
end
if DefaultHitFrac == 1
    DefaultHitFrac = 0.99
end


DefaultHitNormInv = norminv(DefaultHitFrac,0,1)
DefaultFANormInv = norminv(DefaultFAFrac,0,1)

DefaultDPrime = DefaultHitNormInv - DefaultFANormInv


%calc behavioral d-prime for variants

VariantHits = nonzeros(VariantHits); 
NumVariantHits = length(VariantHits)
VariantHitFrac = NumVariantHits/NumVertVariants; 


VariantFalseAlarm = zeros(NumDiagVariants , 1); 

for i = 1: NumDiagVariants 
    
    DiagVariantIt = DiagVariantStimIts(i); 
    DiagVariantTime = Timer(DiagVariantIt); 
    DiagLickWindow = DiagVariantTime + 1; 
    EndDiagWindow = find(Timer >= DiagLickWindow); 
    EndDiagWindowIt = EndDiagWindow(1); 
    
    LicksInDiagWindow = find(Licks(DiagVariantIt:EndDiagWindowIt) == 1); 
    
    if length(LicksInDiagWindow) > 2 
        
        VariantFalseAlarm(i, 1) = DiagVariantIt; 
        
    end 
      
end 

VariantFalseAlarm = nonzeros(VariantFalseAlarm); 
NumVariantFAs = length(VariantFalseAlarm); 
VariantFAFrac = NumVariantFAs/NumDiagVariants; 


if VariantFAFrac == 0
    VariantFAFrac = 0.01
end
if VariantFAFrac == 1
    VariantFAFrac = 0.99
end


if VariantHitFrac == 0
    VariantHitFrac = 0.01
end
if VariantHitFrac == 1
    VariantHitFrac = 0.99
end

VariantHitNormInv = norminv(VariantHitFrac,0,1)
VariantFANormInv = norminv(VariantFAFrac,0,1)


VariantDPrime = VariantHitNormInv - VariantFANormInv



%Calc d prime for all trials

NumDiagStim = NumDiagVariants + NumDiagDefaults; 
NumVertStim = NumDefaultStims  + NumVertVariants;  

TotalTrials = NumDiagStim + NumVertStim; 
TotalHitFrac = (NumVariantHits + NumDefaultHits)/NumVertStim; 
TotalFAFrac = (NumVariantFAs + NumDefaultFAs)/NumDiagStim; 


if TotalFAFrac == 0
    TotalFAFrac = 0.01
end
if TotalFAFrac == 1
    TotalFAFrac = 0.99
end


if TotalHitFrac == 0
    TotalHitFrac = 0.01
end
if TotalHitFrac == 1
    TotalHitFrac = 0.99
end

TotalHitNormInv = norminv(TotalHitFrac,0,1)
TotalFANormInv = norminv(TotalFAFrac,0,1)


TotalDPrime = TotalHitNormInv - TotalFANormInv



%save data for mouse on consecutive days 

FindStart = findstr(AnalysisPath, 'BH'); 
Date = AnalysisPath(FindStart+6:end);  
MouseName = AnalysisPath(FindStart:FindStart+4);
SaveString = AnalysisPath(FindStart:end); 
MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName);  

DefaultFAStr = num2str(DefaultFAFrac); 
DefaultHitStr = num2str(DefaultHitFrac); 

VariantFAStr = num2str(VariantFAFrac); 
VariantHitStr = num2str(VariantHitFrac); 

TotalFAStr = num2str(TotalFAFrac); 
TotalHitStr = num2str(TotalHitFrac); 

cd(MousePath); 
fileID = fopen('AllDPrime.txt','a');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',TotalTrials, '-append');
dlmwrite('AllDPrime.txt',HitFrac, '-append');
dlmwrite('AllDPrime.txt',FAFrac,'-append');
dlmwrite('AllDPrime.txt',DPrime,'-append');
fclose(fileID);

cd(AnalysisPath); 
fileID = fopen('AllDPrime.txt','w');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',TotalTrials, '-append');
dlmwrite('AllDPrime.txt',HitFrac, '-append');
dlmwrite('AllDPrime.txt',FAFrac,'-append');
dlmwrite('AllDPrime.txt',DPrime,'-append');
fclose(fileID);

 end 
 
 
 %open cummulative data files for analysis 

cd(CodePath);
AnalyzedPath = 'C:\Users\Feinberg Lab- Matlab\Documents\Analyzed\Discrim Analysis'; 
MiceAnalysisFolders = dir(AnalyzedPath); 
NumMiceAnalyFiles = length(MiceAnalysisFolders);


AllDPrimes = zeros(4, (NumMiceAnalyFiles-3)); 
AllTrials = zeros(4, (NumMiceAnalyFiles-3));
AllFAs = zeros(4, (NumMiceAnalyFiles-3));
AllHits= zeros(4, (NumMiceAnalyFiles-3));

Dates = zeros(4, (NumMiceAnalyFiles-3)); 
MouseNames = cell((NumMiceAnalyFiles-3), 1);

OverlayedDPrimes = figure('name', 'All DPrimes');

for i = 3:NumMiceAnalyFiles

    MouseAnalyFolder = MiceAnalysisFolders(i).name; 
    BHFile = findstr(MouseAnalyFolder, 'BH'); 
    
    if isempty(BHFile) == 0
    
    if i == 3
        
        MouseNames = cellstr(MouseAnalyFolder); 
        
    else 
        
        MouseName = cellstr(MouseAnalyFolder); 
        MouseNames = [MouseNames MouseName]; 
        
    end 
    
    
    MouseFolderAnalyPath = strcat(AnalyzedPath, '\', MouseAnalyFolder) 
    cd(MouseFolderAnalyPath); 
    DPrimeFileCreated = dir('*.txt'); 
    FoldersPresent = dir(MouseFolderAnalyPath);  
    NumFolders = length(FoldersPresent);  
    NumDateFolders = zeros(NumFolders, 1); 
   
    
    for x = 3:NumFolders
        
        FolderName =  FoldersPresent(x).name;  
        AMFolders = length(findstr(FolderName, 'AM'));  
        PMFolders = length(findstr(FolderName, 'PM'));
        
        NumDateFolders(x, 1) = AMFolders + PMFolders; 
        
    end 
    
    NumDateFolders = sum(NumDateFolders); 
    
    if isempty(DPrimeFileCreated) == 0
        
        fileID = fopen('AllDPrime.txt','r');
        FirstChars = zeros(NumDateFolders*5, 1);
        DPrimeDates = cell(NumDateFolders, 1); %change to cells 
        DPrimeData = zeros(NumDateFolders*5, 1);
        a = 0; 
        
        for x = 1:(NumDateFolders*5)
            
        x ; 
        LineRead = fgetl(fileID); 
        LineLength = length(LineRead);
        
        if LineLength > 11
            
            a = a + 1; 
            FirstChars(x, 1) = str2num(LineRead(1)); 
            LineRead = cellstr(LineRead); 
            DPrimeDates(a, 1) = LineRead; 
        
        else
            
            LineRead = char(LineRead(1, :)); 
            LineRead = strcat(LineRead); 
            NumRead = str2num(LineRead);
            if NumRead == 0 
                
                NumRead = 0.01; 
                
            end 
            DPrimeData(x, 1) = NumRead; 
            
            
        end 
            
        end 
        
        DPrimeDates ; 
        
        DPrimeData = nonzeros(DPrimeData); 
        DPrimeData = reshape(DPrimeData, 4, []);                            
        
    end
    
    NumPrimeDates = length(DPrimeDates);
    DPrimeDates = char(DPrimeDates); 
   
    
%sort files in order of date 
        
    for x = 1:NumPrimeDates 
        
     PrimeDate = DPrimeDates(x, :);     
    FirstComma = findstr(PrimeDate, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = findstr(PrimeDate, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = findstr(PrimeDate, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = PrimeDate(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates(x, (i-2)) = DateNum; 
    
     
    end
    
    
    FirstChars = nonzeros(FirstChars);
    NumFirstChars = length(FirstChars);     
    
    Trials = DPrimeData(1, :);
    Trials = Trials';
    
    HitFracs = DPrimeData(2, :); 
    HitFracs = HitFracs'; 
    
    FAFracs = DPrimeData(3, :); 
    FAFracs = FAFracs' ;

    DPrimes = DPrimeData(4, :); 
    DPrimes =  DPrimes';


    
    for x = 2:NumFirstChars 
        
        
        SameDay = FirstChars(x,1) - FirstChars((x-1),1); 
       
       if SameDay == 0 
           
           AvgFAFrac = mean([TotalFAFracs(x-1) TotalFAFracs(x)]); 
           AvgHitFrac = mean([HitFracs(x-1) HitFracs(x)]); 
           
           AvgFANorm = norminv(AvgFAFrac); 
           AvgHitNorm = norminv(AvgHitFrac);
           
           AvgDPrime = AvgHitNorm-AvgFANorm; 
           
           TotalDPrimes(x) = AvgDPrime; 
           TotalDPrimes(x-1) = 0; 
           
           AvgTrials = mean([Trials(x-1) Trials(x)]);  
           
           Trials(x) = AvgTrials; 
           Trials(x-1) = 0; 
           
           HitFracs(x) = AvgHitFrac; 
           HitFracs(x-1) = 0; 
           
           TotalFAFracs(x) = AvgFAFrac; 
           TotalFAFracs(x-1) = 0; 
           
           Dates((x-1), (i-2)) = 0; 
           
       end 
    end
    
    
    
    Trials = nonzeros(Trials); 
    NumTrials = length(Trials); 
    AllTrials(1:NumTrials, (i-2)) = Trials; 
    
    DPrimes = nonzeros(DPrimes); 
    NumPrimes = length(DPrimes);
    AllDPrimes(1:NumPrimes, (i-2)) = DPrimes; 
    
    Hits = nonzeros(HitFracs); 
    NumHits = length(Hits);
    AllHits(1:NumPrimes, (i-2)) = Hits; 
    
    FAs = nonzeros(FAFracs); 
    NumFAs = length(FAs);
    AllFAs(1:NumFAs, (i-2)) = FAs; 

   figure('name', MouseAnalyFolder); 
    
   for i = 1:NumHits
 
       plot(Hits, 'b'); 
       hold on; 
       plot(FAs, 'r'); 
       
    end 

    
%     %plot total d primes 
%     
%     if NumTotalPrimes == 1
%         
%       plot(TotalDPrimes, 'o');  
%     
%     else if i < 8
%     
%     plot(TotalDPrimes,  'LineWidth', 2); 
%    
%     else 
%     plot(TotalDPrimes, '--',  'LineWidth', 2); 
%         
%         end 
%     end 
%     hold on;
%     
%    legend(MouseNames, 'Location', 'southeast'); 
%      
%     NumTotalPrimes = length(TotalDPrimes);    

    end 
end

    

% cd(AnalyzedPath); 
% FigureSaveName = 'Behavioral_DPrimes_as_of_7/20.png'; 
% FigureSave = strcat(pwd, '\', FigureSaveName); 
% saveas(gcf, FigureSaveName); 
% %close(VertTrialsOne); 


NumMiceFolders = 0; 

for i = 1:NumMiceAnalyFiles
    
    FolderName = MiceAnalysisFolders(i).name;
    BHFolder = findstr(FolderName, 'BH'); 
    
    if isempty(BHFolder) == 0
        
       NumMiceFolders = NumMiceFolders +1; 
       
    end 
    
end 

NumMiceFolders; 

AllIndivDPrimes = figure('name', 'All Indiv DPrimes Variants'); 

for i = 1:(NumMiceFolders)

    subplot(2, 2, i); 
    
    IndivDefaultPrimes = AllDPrimes(:, i); 
    IndivDefaultPrimes = nonzeros(IndivDefaultPrimes); 
     
    IndivVariantPrimes = AllVariantDPrimes(:, i); 
    IndivVariantPrimes = nonzeros(IndivVariantPrimes); 
         
    IndivTotalPrimes = AllTotalDPrimes(:, i); 
    IndivTotalPrimes = nonzeros(IndivTotalPrimes); 
    
    MouseDates = nonzeros(Dates(:, i)); 
    NumDays = length(MouseDates) ; 
    RelativeDays = zeros(NumDays, 1); 
    
    for x = 1:NumDays
    
    RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
    RelativeDays(x, 1) =  RelativeDayNum; 
    
    end 
           
    MouseName = MouseNames(1, i); 
    
    plot(RelativeDays,  IndivDefaultPrimes, '-o', RelativeDays,  IndivVariantPrimes, '-o', RelativeDays,  IndivTotalPrimes, '-o');
    title(MouseName); 
    hold on;  
 
   if i == 1
       
      legend('Default DPrime', 'Variant DPrime', 'Total DPrime', 'Location','northoutside', 'Orientation','horizontal'); 
       
   end 
    
end 

% MouseNames = char(MouseNames); 
% AllIndivDPrimes = figure('name', 'All Indiv DPrimes'); 
% 
% for i = 1:(NumMiceAnalyFiles-3)
%     
%     i; 
%     subplot(6, 2, i); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%  
%     
% end 
% 
% figure('name', 'Indiv DPrimes and Percents BH101-106');
% FAandHits = {'Correct Vertical Trials (Hits)' 'Incorrect Diagonal Trials (False Alarms)'}; 
% 
% for i = 1:6 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(6, 2, (i*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%     
%     subplot(6, 2, i*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivFAFrac = nonzeros(AllTotalFAFrac(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivFAFrac, '-bo');
%     title(MouseName);
%       
%         if i == 3
%         legend(FAandHits, 'Location', 'east');        
%         end 
%         
%     hold on; 
%  
%     
% end 
% 
% figure('name', 'Indiv DPrimes and Percents BH107 - 113'); 
% 
% for i = 7:11 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(5, 2, ((i-6)*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%     
%     subplot(5, 2, (i-6)*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivFAFrac = nonzeros(AllTotalFAFrac(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivFAFrac, '-bo');
%         title(MouseName);
%         
%         if i == 9
%         legend(FAandHits, 'Location', 'east');        
%         end 
%         
%         hold on; 
%    
% end 
% 
% 
% MouseNames = char(MouseNames); 
% AllIndivDPrimes = figure('name', 'All Indiv DPrimes'); 
% 
% for i = 1:(NumMiceAnalyFiles-3)
%     
%     i; 
%     subplot(6, 2, i); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%  
%     
% end 
% 
% figure('name', 'DPrimes, Hits, and True Negatives BH101-106');
% TPandHits = {'Correct Vertical Trials (Hits)' 'Correct Diagonal Trials (True Negative)'}; 
% 
% for i = 1:6 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(6, 2, (i*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%     
%     subplot(6, 2, i*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivTPFrac = nonzeros(TrueNegFracs(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivTPFrac, '-bo');
%     title(MouseName);
%       
%         if i == 3
%         legend(TPandHits, 'Location', 'east');        
%         end 
%         
%     hold on; 
%     
% end 
%  
% 
% figure('name', 'DPrimes, Hits, and True Negatives BH107-113');
% 
% 
% for i = 7:11 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(5, 2, ((i-6)*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%         
%     subplot(5, 2, (i-6)*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivTPFrac = nonzeros(TrueNegFracs(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivTPFrac, '-bo');
%     title(MouseName);
%       
%         if i == 9
%         legend(TPandHits, 'Location', 'east');        
%         end 
%         
%     hold on; 
    
% end 

