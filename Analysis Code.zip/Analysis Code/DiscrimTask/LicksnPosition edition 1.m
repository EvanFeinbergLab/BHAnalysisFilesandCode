function [behavior] = LVdata_noPCO(Movie)

movfile = fopen(Movie);
movsize = dir(Movie);
movbyt = movsize.bytes;

movnu = movbyt/(9*4+8) 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie


fseek(movfile, 9*4 ,'bof');
LVT = zeros(1,movnu);

for i = 1:movnu

    LVtime = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    LVT(1,i)= LVtime; 
    fseek(movfile,9*4,'cof');
   
end

LVT = round(LVT, 2);

%read stim info and mouse position:
%Total Dist traveled, Random Number Interval, Rand Dist Generated  
% Training Mode - (0)Running, (1)RewardBothStim,NoLick, (2)RewardBoth,Lick, (3) Reward Correct
%Stim, Lick?, Correct?, Lick Window, Latency(ms)

%!!empty array are full of eights !!

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 12);  
Zeros = zeros(1, 12); 

for i = 1:movnu
    
    Stiminfo = fread(movfile, 9 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(i, 1:9)= StimInfo;
    
    Mode = StimPos (i, 4); 
    Stim = StimPos (i, 5); 
    Lick = StimPos (i, 6); 
    Correct = StimPos (i, 7);
     
%     
%     if (Stim == 0) && (Lick == 1) && (Correct == 0)
%         result = 2; % 'false pos'
%         StimPos(i, 10) = result;
%     end 
%     
%     if (Mode == 3) & (Stim > 0) && (Lick == 0) && (Correct == 0)
%         result = 3;  %'miss'
%         StimPos(i, 10) = result;
%     end 
%     
%     if (Mode == 4) & (Stim == 1) && (Lick == 0) && (Correct == 0)
%         result = 3;  %'miss'
%         StimPos(i, 10) = result; 
%     end 
%     
%       if (Mode == 4) & (Stim == 2) && (Lick == 0) && (Correct == 0)
%         result = 4;  %'correctly ignored'
%         StimPos(i, 10) = result;
%      end 
%     
%      if (Mode == 4) & (Stim == 2) && (Lick == 1) && (Correct == 0)
%         result = 5;  %'wrong'
%         StimPos(i, 10) = result;
%      end  

    StimPos(i, 10) = i; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end

LicknLatency = zeros(movnu, 4); 

for i = 1:movnu

LicknLatency (i, 1) = StimPos(i, 6); %licks
LicknLatency (i, 2) = StimPos(i, 9); % latencies
LicknLatency (i, 3) = StimPos(i, 5); %stims 
LicknLatency (i, 4) = LVT(1, i); %time

end

StimNum = find((LicknLatency(:, 3) == 1));   
NumStim = length(StimNum); 
StimIt = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIt(i, 1) = StimNum(i);  

    else
        if StimNum(i)-StimNum(i-1) == 1
        StimIt(i, 1) = 0; 
    else 
        StimIt(i, 1) = StimNum(i);
    end 
    end 
end 

StimIt; 
StimIt = nonzeros(StimIt); 
NumStim = length(StimIt) 

figure;
x = LicknLatency(: , 4); 
Licks = LicknLatency(: , 1); 
Stims = LicknLatency(: , 3);

plot (x, Licks, x, Stims); 

LickWindow = 10; %1 iterations = 10 ms 
FullWindow = 100; 
NumWindows = FullWindow/ LickWindow; 

LickItInterval = zeros(1, NumWindows*2);
Licrements = zeros(LickWindow, NumWindows*2);
LicksSpanStims = zeros(NumStim, NumWindows*2); 

for i = 1:NumStim 
    StimIt = StimNum(i); 
    
    if StimIt < FullWindow  
        LicksSpanStim (i, StimIt:end) = LicknLatency(((StimIt- (StimIt - 1)):(StimIt+ FullWindow)), 1);
        %test= length(LicksSpanStim)
        
    else if StimIt > (movnu - FullWindow)
        Remaining = movnu - StimIt; 
        LicksSpanStim = LicknLatency(((StimIt- (FullWindow - 1)):(StimIt+ Remaining)), 1);    
        
        else 
            LicksSpanStim = LicknLatency(((StimIt- (FullWindow - 1)):(StimIt+ FullWindow)), 1);
            SpanStim = LicknLatency(((StimIt- (FullWindow - 1)):(StimIt+ FullWindow)), 3);
            LatencySpanStim = LicknLatency(((StimIt- (FullWindow - 1)):(StimIt+ FullWindow)), 2);
        end 
    end
    
    LicksSpanStim; 
     %spans a full second around the stimulus
    
    for x = 1:(NumWindows*2)
    
        if x == 1
        
        Licrements(:, x) = LicksSpanStim (LickWindow*x); %get it... licrements ... lick increments

        else 
             
        Licrements(:, x) =  LicksSpanStim ((LickWindow*(x-1)+1):LickWindow*x); 
        
        end           
 
    end
    
    Licrements; 
    LicksInBlock = sum(Licrements, 1);  %return row vector of the sum of each column
    LicksSpanStims(i, :) = LicksInBlock; 
    
end

LicksSpanStims; 

for i = 1:NumWindows 
    
    LickItIntervalBefore(1, ((LickWindow +1)-i)) = -10*i;     
    LickItIntervalAfter(1, i) = 10*i; 
    
end 

LickItInterval = [LickItIntervalBefore  LickItIntervalAfter] ;  
    
for i = 1:NumStim %individual stim instances 
    
    %figure; plot(LickItInterval,LicksSpanStims(i, :)); 
end 

AvgLicksSpanStim = mean(LicksSpanStims, 1);  %row vector with mean of each column

figure; plot(LickItInterval, AvgLicksSpanStim);  

% AvgLickBeforeProb = mean(LickProbBefore)
% AvgLickAfterProb = mean(LickProbAfter)

RandRange = zeros(LickWindow , 1); 
random = 1 + (movnu-1).*rand(200,1);  %creates 100 random numbers in the range of 1 to movnu  
randomit = round (1 + (200-1).*rand(100 ,1))

for i = 1:100 
    
randomnum = round(random(randomit(i))); 

RandomTime = LicknLatency (randomnum, 3); 
RandSearch = rand;  

if randomnum < LickWindow 
    RandRange = LicknLatency (randomnum:(randomnum + (LickWindow-1)), 1); 
else if randomnum > (movnu-LickWindow)
    RandRange = LicknLatency ((randomnum - (LickWindow-1)): randomnum, 1); 
else 
    if RandSearch > 0.5 
        RandRange = LicknLatency (randomnum:(randomnum + (LickWindow-1)), 1); 
    else 
        RandRange = LicknLatency ((randomnum -(LickWindow-1)):randomnum, 1); 
    end 
    end 
end 

%exclude the interval around a stim appearance ??

RandLicks = find(RandRange == 1);

NumRandLicks = length(RandLicks); 
TotalRange = length(RandRange);

RandLickProb = NumRandLicks/TotalRange; 
RandLickProbs (i, 1) = RandLickProb; 

end 

RandLickProbs
test = length(RandLickProbs)
AvgRandLickProb = mean(RandLickProbs)

FilePathName = fopen(movfile); %give name of file currently open 
NameDate = FilePathName(12:(end - 10)); 
SessionFileNum = FilePathName(end-9);
SessionFileNum = str2num(SessionFileNum);

LickProbabilities = [SessionFileNum AvgLickBeforeProb AvgLickAfterProb AvgRandLickProb];  

filepath = strcat('\', NameDate);
filename = strcat(filepath, 'Analysis\'); 
path = strcat(pwd, filename);  
datafilename = 'LickProbabilities'; 

folderexists = exist(path); 

if folderexists == 7 %folder exists 
    dlmwrite([path datafilename], LickProbabilities, '-append', 'delimiter', ' ')
else if folderexists == 0 %folder doesnt exist
        mkdir(path); 
        dlmwrite([path datafilename], LickProbabilities, 'delimiter', ' ')
end 
end 

[LickEventsSize eleven] = size(StimLickEvents);
EventTypes = zeros(LickEventsSize, 1); 

EventLatency = find(StimLickEvents(:, 10) == 3); 
LatencyThreshold = StimLickEvents(EventLatency(1,1), 8); 

TwosEvents = find(StimLickEvents(:, 10) == 2); %iterations of stimlickevents in which there was a #2 event
TwosEventsSize = length(TwosEvents); 
NotMissEvents = zeros(TwosEventsSize, 1); 

for i = 1:TwosEventsSize; 
    TwosEventIt = TwosEvents(i, :);  
    LatencyOfEventBefore = StimLickEvents((TwosEvents(i, :)-1), 9); 
    LatencyOfTwoEventsBefore = StimLickEvents((TwosEvents(i, :)-2), 9);
    
    if  (LatencyOfEventBefore < LatencyThreshold && LatencyOfEventBefore ~= 0) 
        NotMissEvents(i, :) = TwosEventIt; 
    end 
    
end 

MissEventsIt = TwosEvents - NotMissEvents; 
MissEventsSize = length(MissEventsIt); 

NumJustLickEvents = length(nonzeros(NotMissEvents));
numJustLickEvents = NumJustLickEvents*2; % this is true as long as the trend of two "misses" after a "hit" occurs
NumMissEvents = (TwosEventsSize - numJustLickEvents) / 3;  
ThreesEvents = find(StimLickEvents(:, 9) > 0); 
ThreesEventsSize = length(ThreesEvents); 
TotalStimLickEvents = NumMissEvents + ThreesEventsSize

for i = 1:MissEventsSize-1
    
    if MissEventsIt(i, :) == 0 
        MissEventsIt((i+1), :) = 0; 
    end 
end 

JustLickEventsIt = nonzeros(MissEventsIt)
JustLickEventsItSize = length(JustLickEventsIt)
LickEventsSize

EventTypeandFrame = zeros(movnu, 2); 
 
for i = 1:LickEventsSize
    
    EventMode = StimLickEvents(i, 4);
    EventStim = StimLickEvents(i, 5);
    LatencyThres = StimLickEvents(i, 8); 
            
    if StimLickEvents(i, 10) == 2
        Eventtype = 2; %false pos in all cases 
        EventTypeandFrame(i, :) = Eventtype;
        EventTypeandFrame(i, :) = StimLickEvents(i, 10)
    end 
    
    if StimLickEvents(i, 10) == 3
        
        latencyOfevent = StimLickEvents((i+3), 9); 
   
        if latencyOfevent > LatencyThres && EventMode == 2 && EventStim > 0
            Eventtype = 3; %missed 
            EventTypes(i, :) = Eventtype; 
        end 
        
        if latencyOfevent > LatencyThres && EventMode == 3 && EventStim == 1 
            Eventtype = 3; %missed 
            EventTypes(i, :) = Eventtype; 
        end
        
        if latencyOfevent > LatencyThres && EventMode == 3 && EventStim == 2 
            Eventtype = 4; %correctly ignored
            EventTypes(i, :) = Eventtype; 
        end
        
        i = i + 4; %skip ahead
        
    end 
    
    if StimLickEvents(i, 10) == 3
        
        latencyOfevent = StimLickEvents((i+3), 9); 
        
        if latencyOfevent < LatencyThres && EventMode == 2 && EventStim > 0 
            Eventtype = 6; % hit 
            EventTypes(i, :) = Eventtype; 
        end 
        
        if latencyOfevent < LatencyThres && EventMode == 3 && EventStim == 1 
            Eventtype = 6; %hit 
            EventTypes(i, :) = Eventtype; 
        end 
        
        if latencyOfevent < LatencyThres && EventMode == 3 && EventStim == 2 
            Eventtype = 5; %wrong
            EventTypes(i, :) = Eventtype; 
        end 

       i = i + 6;  % skip ahead -- may need to change 
    end 
    
    Eventtype 
end 

EventTypes


%find each event instance -- return the index numbers in ann array  
Ignored = find(StimPos == 2);
FalsePos = find(StimPos == 3);
Missed = find(StimPos == 4);
Hit = find(StimPos == 5);
EventHit = find(StimPos == 6);
%calc how many of each event instance 
sizeIg = size(Ignored); 
sizeFP = size(FalsePos); 
sizeMiss = size(Missed); 
sizeHit = size(Hit); 









