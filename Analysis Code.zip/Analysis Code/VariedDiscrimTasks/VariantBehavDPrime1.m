CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents'; 
DataPath = 'D:\Brooke\Data'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles
    

    %Check if file has been accessed        
   
    cd(DataPath);
    MouseFolder = MiceFiles(i).name; 
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
        
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), (NumMiceFiles-2)); 
    
    for x = 3:NumDateFiles 
        
        DateFile =  MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile); 
        cd(DateFilePath); 
  
        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt');
       NumStamps = length(AccessStamp); 
       
       if isempty(AccessStamp) == 0 
       
       for z = 1:NumStamps
           
           StampName = AccessStamp(z).name; 
           PrimeStamp = findstr(StampName, 'Prime'); 
       end 
       
       end 
           
        if isempty(AccessStamp) == 1| isempty(PrimeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           

        end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess; 
        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
        
     end 
    
     PathsToAnalyze; 

    end
   
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRewards = single.empty(500000, 0); 
 AllLicks = single.empty(500000, 0); 
  AllTime = single.empty(500000, 0); 
 AllRZ = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
    StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(10*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 10*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,10*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 11);  
Zeros = zeros(1, 11); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 10 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:10)= StimInfo;
     
    StimPos(y, 11) = y; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end 

StimnLick = zeros(movnu, 5); 

StimnLick(:, 1) = StimPos(:, 3); %stim
StimnLick(:, 2) = StimPos(:, 4);%lick
StimnLick(:, 3) = StimPos(:, 5); %reward
StimnLick(:, 4) = Timer(:, 1); 
StimnLick(:, 5) = StimPos(:, 6);
StimnLick(:, 6) = StimPos(:, 1);

Stims = StimnLick(:, 1); 
Licks = StimnLick(:, 2); 
Rewards = StimnLick(:, 3);
Timer = StimnLick(:, 4);
RZDist = StimnLick(:, 5);
Dist= StimnLick(:, 6);
StimSize = StimPos(:, 7); 
StimSide = StimPos(:, 8);
CueSide = StimPos(:, 9);
StimMotion = StimPos(:, 10);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllLicks(1:movnu) = Licks;
    AllReward(1:movnu) = Rewards;
    AllTime(1:movnu) = Timer;
    AllRZ(1:movnu) = RZDist;
    AllDist(1:movnu) = Dist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims; 
    
    AllRewards(StartFill: (StartFill+movnu) - 1) = Rewards;   
    AllLicks(StartFill: (StartFill+movnu) - 1) = Licks;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
    AllRZ(StartFill: (StartFill+movnu) - 1) = RZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = Dist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
RZDist = round(AllRZ)'; 
Stims = AllStims';
Licks = AllLicks';
Rewards = AllRewards';
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

%find deriv/change in value of licks 

derivLicks = diff(Licks); 
NumDiffLicks = length(derivLicks); 

DerivLicks  = abs(derivLicks); 
DerivLicks = [0; DerivLicks]; 
%Licks = DerivLicks; 


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 2));   
NumStim = length(VertStimNum); 
StimIts = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIts(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        StimIts(i, 1) = 0; 
    else 
        StimIts(i, 1) = VertStimNum(i);
    end 
    end 
end 

StimIts = nonzeros(StimIts);   
NumVertStim = length(StimIts); 

%separate default from variant stims 

VertVariants = zeros(NumVertStim, 1); 
VertDefaults = zeros(NumVertStim, 1);
StimTypes = zeros(NumVertStim, 1);

for i = 1:NumVertStim
    
    StimIt = StimIts(i) 
    
    if i < NumVertStim 
        
    NextStim = StimIts(i+1);
    FindStimType = find(RZDist(StimIts(i): NextStim) ~= 0); 
    
    if isempty(FindStimType) == 0
    
    StimTypeIt = (FindStimType(1) + StimIts(i)) - 1; 
    StimType = RZDist(StimTypeIt);   
    StimTypes(i, 1) = StimType; 
    
    if StimType < 20
        
         VertDefaults(i, 1) = StimIts(i);
        
    else 
         VertVariants(i, 1) = StimIts(i); 
        
      end
    end
              
    else 
        
        FindStimType = find(RZDist(StimIts(i): end) ~= 0); 
        
        if isempty(FindStimType) == 0
    
            StimTypeIt = (FindStimType(1) + StimIts(i)) - 1; 
            StimType = RZDist(StimTypeIt); 
            StimTypes(i, 1) = StimType; 
            
            if StimType < 20
        
         VertDefaults(i, 1) = StimIts(i);
        
        else 
         VertVariants(i, 1) = StimIts(i); 
        
      end
        end
        
    end
        
      if length(FindStimType) == 1
          
         VertDefaults(i, 1) = 0;  
         VertVariants(i, 1) = 0; 
         
      end 

end 

StimTypes = nonzeros(StimTypes); 
VertVariants = nonzeros(VertVariants); 
NumVertVariants = length(VertVariants);

VertDefaults = nonzeros(VertDefaults); 
NumVertDefaults = length(VertDefaults); 

RZStarts = zeros(NumVertDefaults); 
RZEnds = zeros(NumVertDefaults); 

for i = 1: NumVertDefaults 
       
    VDefault = VertDefaults(i); 
    
    if i < NumVertDefaults
    
    NextStim = VertDefaults(i+1); 
    RZStart = find(RZDist(VDefault:NextStim) >= 30);      
    RZEnd = find(RZDist(VDefault:NextStim) >= 70);
    else 
    RZStart = find(RZDist(VDefault:end) >=30);
    RZEnd = find(RZDist(VDefault:end) >= 70);
    end
    
    if isempty(RZStart) == 0 
    RZStart = RZStart(1); 
    RZStartIt = (RZStart+VDefault) - 1; 
    RZStarts(i, 1) = RZStartIt;        
    end 
    
    if isempty(RZEnd) == 0 
    RZEnd = RZEnd(1); 
    RZEndIt = (RZEnd+VDefault) - 1; 
    RZEnds(i, 1) = RZEndIt; 
    end 
    
    if isempty(RZStart) == 0 && isempty(RZEnd) == 1
        
         VertDefaults(i, 1) = 0; 
         RZEnds(i, 1) = 0; 
         RZStarts(i, 1) = 0; 
         
    end
    
     if isempty(RZStart) == 1 && isempty(RZEnd) == 0
        
         VertDefaults(i, 1) = 0; 
         RZEnds(i, 1) = 0; 
         RZStarts(i, 1) = 0; 
         
     end
    
       if isempty(RZStart) == 1 && isempty(RZEnd) == 1
        
         VertDefaults(i, 1) = 0; 
         RZEnds(i, 1) = 0; 
         RZStarts(i, 1) = 0; 
         
    end
    
end 

RZStarts = nonzeros(RZStarts);
NumStarts = length(RZStarts)  

RZEnds = nonzeros(RZEnds);
NumEnds = length(RZEnds)

VertDefaults = nonzeros(VertDefaults); 
NumVertDefaults = length(VertDefaults)



RZRewards = zeros(NumStarts, 1); 

for i = 1:NumStarts
    
    RZStart = RZStarts(i); 
    RZEnd = RZEnds(i);
    
    FindLick = find(Licks(RZStart:RZEnd) == 1); 
    
    if isempty(FindLick) == 0
        
        FindLick = FindLick(1); 
        RewardIt = (FindLick + RZStart) - 1; 
        RZRewards(i,1) = RewardIt; 
    end 
    
end 

RZRewards = nonzeros(RZRewards);
NumRZRewards = length(RZRewards)
DefaultHits = RZRewards; 


VariantRewards = zeros(NumVertVariants, 1); 

for i = 1:NumVertVariants
    
    VariantIt = VertVariants(i); 
    
    if i < NumVertVariants  
    
    NextVariant = VertVariants(i+1);   
    LickWindow = find(RZDist(VariantIt:NextVariant) ~= 0); 
    
    else 
        
         LickWindow = find(RZDist(VariantIt:end) ~= 0); 
         
    end
    
    if isempty(LickWindow) == 0
        
    StartWindow = LickWindow(1); 
    EndWindow = LickWindow(end);
    StartWindowIt = (VariantIt + StartWindow) - 1; 
    StartWindowIt = StartWindowIt - 1;
    EndWindowIt = (VariantIt + EndWindow) - 1;
    
    WindowStartValue = RZDist(StartWindowIt); 
    WindowEndValue = RZDist(EndWindowIt);
    
    FindLicks = find(Licks(StartWindowIt:EndWindowIt) == 1); 
    
    if isempty(FindLicks) == 0 
       
        LickIt = FindLicks(1); 
        RewardIt = (LickIt + VariantIt) - 1; 
        VariantRewards(i, 1) = RewardIt;
        
    else 
        
        FullWindow =  WindowEndValue; 
        
    end
    
    else
        
       VertVariants(i, 1) = 0; 
       
    end 
    
end 

VertVariants = nonzeros(VertVariants); 
VariantRewards = nonzeros(VariantRewards); 
 
NumVertVariants = length(VertVariants); 
NumVaryRewards = length(VariantRewards); 





%lick analysis for vert variants 

VariantHits = zeros(NumVertVariants, 1); 
VariantFA = zeros(NumVertVariants, 1); 

for i = 1:NumVertVariants

     VertVariantIt = VertVariants(i); 
%     StartWindow = find(RZDist(VertVariantIt:VertVariantIt+50) ~= 0);  
%              
%         StartWindow = LickWindow(1); 
%         StartWindowIt = (VertVariantIt + StartWindow) - 1; 
%         StartWindowIt = StartWindowIt - 1; 
%         
% 
%               StartWindowTime = Timer(StartWindowIt, 1); 
%               EndWindowTime = StartWindowTime + FullWindow/1000; 
%               EndWindowIt = find(Timer >= EndWindowTime); 
%               EndWindowIt = EndWindowIt(1); 
       
        StimTime = Timer(VertVariantIt, 1);
        StartWindowIt = VertVariantIt; 
        EndWindow = StimTime + FullWindow/1000; 
        EndWindowIt = find(Timer >= EndWindow); 
        EndWindowIt = EndWindowIt(1); 

       Licked = find(Licks(StartWindowIt:EndWindowIt)== 1);
       
       if isempty(Licked) == 0 
           
           VariantHits(i, 1) = VertVariantIt; 
           
       end
end

 VariantHits = nonzeros(VariantHits); 


%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 1));   
NumDiagStim = length(DiagStimNum); 
DiagStimIts = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStimIts(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStimIts(i, 1) = 0; 
    else 
        DiagStimIts(i, 1) = DiagStimNum(i);
    end 
    end 
end 

DiagStimIts = nonzeros(DiagStimIts);
NumDiagStim = length(DiagStimIts) 

DiagVariants = zeros(NumDiagStim, 1); 
DiagDefaults = zeros(NumDiagStim, 1);

for i = 1:NumDiagStim 
    
    DiagStim = DiagStimIts(i); 
    
    if i < NumDiagStim 
        
        NextStim = DiagStimIts(i+1); 
        FindVariant = find(StimLength(DiagStim:DiagStim+50) ~= 0); 
        
        else 
            
            FindVariant = find(StimLength(DiagStim:end) ~= 0);             
    end 
    
    if length(FindVariant) > 2  
        
        DiagVariants(i, 1) = DiagStim; 
        
    else 
        
       DiagDefaults(i, 1) = DiagStim; 
        
    end 
end 

DiagVariants = nonzeros(DiagVariants); 
DiagDefaults = nonzeros(DiagDefaults); 

NumDiagVariants = length(DiagVariants) 
NumDiagDefaults = length(DiagDefaults) 


NumDiagStim = NumDiagVariants + NumDiagDefaults; 
NumVertStim = NumVertVariants + NumVertDefaults; 

TotalTrials = NumDiagStim + NumVertStim; 




%calc behavioral d-prime for defaults

DefaultFAs = zeros(NumDiagDefaults , 1); 

for i = 1: NumDiagDefaults 
 
    DiagDefaultStimIt = DiagDefaults(i);    
    DiagStimDist = TotalDist(DiagDefaultStimIt);
    
    StartDiagStim = find(TotalDist>= DiagStimDist + 30); 
    StartDiagStimIt = StartDiagStim(1); 
    
    EndDiagStim = find(TotalDist>= DiagStimDist + 60); 
    EndDiagStimIt = EndDiagStim(1); 
    
    LickInDiag = find(Licks(StartDiagStimIt:EndDiagStimIt) == 1); 
    
    if length(LickInDiag) > 0
        
        LickIt = LickInDiag(1); 
        DefaultFAs(i, 1) = LickIt; 
        
    end                
end 

DefaultFAs = nonzeros(DefaultFAs); 
NumDefaultFAs = length(DefaultFAs) 
DefaultFAFrac = NumDefaultFAs/NumDiagDefaults 


DefaultHits = nonzeros(DefaultHits); 
NumDefaultHits = length(DefaultHits) 
DefaultHitFrac = NumDefaultHits/NumVertDefaults 


if DefaultFAFrac == 0
    DefaultFAFrac = 0.01
end
if DefaultFAFrac == 1
    DefaultFAFrac = 0.99
end



if DefaultHitFrac == 0
    DefaultHitFrac = 0.01
end
if DefaultHitFrac == 1
    DefaultHitFrac = 0.99
end


DefaultHitNormInv = norminv(DefaultHitFrac,0,1)
DefaultFANormInv = norminv(DefaultFAFrac,0,1)

DefaultDPrime = DefaultHitNormInv - DefaultFANormInv


%calc behavioral d-prime for variants

VariantHits = nonzeros(VariantHits); 
NumVariantHits = length(VariantHits)
VariantHitFrac = NumVariantHits/NumVertVariants; 


VariantFalseAlarm = zeros(NumDiagVariants , 1); 

for i = 1: NumDiagVariants 
    
    DiagVariantIt = DiagVariants(i); 
    DiagVariantTime = Timer(DiagVariantIt);
    FullWindowTime = FullWindow/1000; 
    DiagLickWindow = DiagVariantTime + FullWindowTime; 
    EndDiagWindow = find(Timer >= DiagLickWindow); 
    EndDiagWindowIt = EndDiagWindow(1); 
    
    LicksInDiagWindow = find(Licks(DiagVariantIt:EndDiagWindowIt) == 1); 
    
    if length(LicksInDiagWindow) > 2 
        
        VariantFalseAlarm(i, 1) = DiagVariantIt; 
        
    end 
      
end 

VariantFalseAlarm = nonzeros(VariantFalseAlarm); 
NumVariantFAs = length(VariantFalseAlarm); 
VariantFAFrac = NumVariantFAs/NumDiagVariants; 


if VariantFAFrac == 0
    VariantFAFrac = 0.01
end
if VariantFAFrac == 1
    VariantFAFrac = 0.99
end


if VariantHitFrac == 0
    VariantHitFrac = 0.01
end
if VariantHitFrac == 1
    VariantHitFrac = 0.99
end

VariantHitNormInv = norminv(VariantHitFrac,0,1)
VariantFANormInv = norminv(VariantFAFrac,0,1)


VariantDPrime = VariantHitNormInv - VariantFANormInv



%Calc d prime for all trials

NumDiagStim = NumDiagVariants + NumDiagDefaults; 
NumVertStim = NumVertDefaults  + NumVertVariants;  

TotalTrials = NumDiagStim + NumVertStim; 
TotalHitFrac = (NumVariantHits + NumDefaultHits)/NumVertStim; 
TotalFAFrac = (NumVariantFAs + NumDefaultFAs)/NumDiagStim; 


if TotalFAFrac == 0
    TotalFAFrac = 0.01
end
if TotalFAFrac == 1
    TotalFAFrac = 0.99
end


if TotalHitFrac == 0
    TotalHitFrac = 0.01
end
if TotalHitFrac == 1
    TotalHitFrac = 0.99
end

TotalHitNormInv = norminv(TotalHitFrac,0,1)
TotalFANormInv = norminv(TotalFAFrac,0,1)


TotalDPrime = TotalHitNormInv - TotalFANormInv



%save data for mouse on consecutive days 

FindStart = findstr(AnalysisPath, 'BH'); 
Date = AnalysisPath(FindStart+6:end);  
MouseName = AnalysisPath(FindStart:FindStart+4);
SaveString = AnalysisPath(FindStart:end); 
MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName);  

DefaultFAStr = num2str(DefaultFAFrac); 
DefaultHitStr = num2str(DefaultHitFrac); 

VariantFAStr = num2str(VariantFAFrac); 
VariantHitStr = num2str(VariantHitFrac); 

TotalFAStr = num2str(TotalFAFrac); 
TotalHitStr = num2str(TotalHitFrac); 

cd(MousePath); 
fileID = fopen('AllDPrime.txt','a');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',TotalTrials, '-append');
dlmwrite('AllDPrime.txt',DefaultHitFrac, '-append');
dlmwrite('AllDPrime.txt',DefaultFAFrac,'-append');
dlmwrite('AllDPrime.txt',DefaultDPrime,'-append');
dlmwrite('AllDPrime.txt',VariantHitFrac, '-append');
dlmwrite('AllDPrime.txt',VariantFAFrac,'-append');
dlmwrite('AllDPrime.txt',VariantDPrime,'-append');
dlmwrite('AllDPrime.txt',TotalHitFrac, '-append');
dlmwrite('AllDPrime.txt',TotalFAFrac,'-append');
dlmwrite('AllDPrime.txt',TotalDPrime,'-append');
fclose(fileID);

cd(AnalysisPath); 
fileID = fopen('AllDPrime.txt','w');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',TotalTrials, '-append');
dlmwrite('AllDPrime.txt',DefaultHitFrac, '-append');
dlmwrite('AllDPrime.txt',DefaultFAFrac,'-append');
dlmwrite('AllDPrime.txt',DefaultDPrime,'-append');
dlmwrite('AllDPrime.txt',VariantHitFrac, '-append');
dlmwrite('AllDPrime.txt',VariantFAFrac,'-append');
dlmwrite('AllDPrime.txt',VariantDPrime,'-append');
dlmwrite('AllDPrime.txt',TotalHitFrac, '-append');
dlmwrite('AllDPrime.txt',TotalFAFrac,'-append');
dlmwrite('AllDPrime.txt',TotalDPrime,'-append');
fclose(fileID);

 end 
 
 
 %open cummulative data files for analysis 

cd(CodePath);
AnalyzedPath = strcat(CodePath, '\', 'Analyzed'); 
MiceAnalysisFolders = dir(AnalyzedPath); 
NumMiceAnalyFiles = length(MiceAnalysisFolders);

AllDefaultDPrimes = zeros(10, (NumMiceAnalyFiles-3)); 

AllVariantDPrimes = zeros(10, (NumMiceAnalyFiles-3)); 

AllTotalDPrimes = zeros(10, (NumMiceAnalyFiles-3)); 
AllTotalTrials = zeros(10, (NumMiceAnalyFiles-3));
AllTotalFAFrac = zeros(10, (NumMiceAnalyFiles-3));
AllTotalHitFrac = zeros(10, (NumMiceAnalyFiles-3));

Dates = zeros(10, (NumMiceAnalyFiles-3)); 
MouseNames = cell((NumMiceAnalyFiles-3), 1);

OverlayedDPrimes = figure('name', 'All DPrimes');
TrueNegFracs = zeros(10, (NumMiceAnalyFiles-3)); 

for i = 3:NumMiceAnalyFiles

    MouseAnalyFolder = MiceAnalysisFolders(i).name;
    BHFile = findstr(MouseAnalyFolder, 'BH'); 
    
    if isempty(BHFile) == 0
    
    if i == 4
        
        MouseNames = cellstr(MouseAnalyFolder); 
        
    else 
        
        MouseName = cellstr(MouseAnalyFolder); 
        MouseNames = [MouseNames MouseName]; 
        
    end 
    
    MouseFolderAnalyPath = strcat(AnalyzedPath, '\', MouseAnalyFolder); 
    cd(MouseFolderAnalyPath); 
    DPrimeFileCreated = dir('*.txt'); 
    FoldersPresent = dir(MouseFolderAnalyPath);  
    NumFolders = length(FoldersPresent);  
    NumDateFolders = zeros(NumFolders, 1); 
   
    
    for x = 3:NumFolders
        
        FolderName =  FoldersPresent(x).name;  
        AMFolders = length(findstr(FolderName, 'AM'));  
        PMFolders = length(findstr(FolderName, 'PM'));
        
        NumDateFolders(x, 1) = AMFolders + PMFolders; 
        
    end 
    
    NumDateFolders = sum(NumDateFolders); 
    
    if isempty(DPrimeFileCreated) == 0
        
        fileID = fopen('AllDPrime.txt','r');
        FirstChars = zeros(NumDateFolders*11, 1);
        DPrimeDates = cell(NumDateFolders, 1); %change to cells 
        DPrimeData = zeros(NumDateFolders*11, 1);
        a = 0; 
        
        for x = 1:(NumDateFolders*11)
            
        x ; 
        LineRead = fgetl(fileID); 
        LineLength = length(LineRead);
        
        if LineLength > 11
            
            a = a + 1; 
            FirstChars(x, 1) = str2num(LineRead(1)); 
            LineRead = cellstr(LineRead); 
            DPrimeDates(a, 1) = LineRead; 
        
        else
            
            LineRead = char(LineRead(1, :)); 
            NumRead = str2num(LineRead);
            if NumRead == 0 
                
                NumRead = 0.01; 
                
            end 
            DPrimeData(x, 1) = NumRead; 
            
        end 
            
        end 
        
        DPrimeDates ; 
        
        DPrimeData = nonzeros(DPrimeData); 
        DPrimeData = reshape(DPrimeData, 10, []);                            
        
    end
    
    NumPrimeDates = length(DPrimeDates);
    DPrimeDates = char(DPrimeDates); 
   
    
%sort files in order of date 
        
    for x = 1:NumPrimeDates 
        
     PrimeDate = DPrimeDates(x, :);     
    FirstComma = findstr(PrimeDate, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = findstr(PrimeDate, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = findstr(PrimeDate, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = PrimeDate(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates(x, (i-3)) = DateNum; 
    
     
    end
    
    
    FirstChars = nonzeros(FirstChars);
    NumFirstChars = length(FirstChars);     
    
    Trials = DPrimeData(1, :);
    Trials = Trials';
    
    DefaultHitFracs = DPrimeData(2, :); 
    DefaultHitFracs = DefaultHitFracs'; 
    
    DefaultFAFracs = DPrimeData(3, :); 
    DefaultFAFracs = DefaultFAFracs' ;
    
    VariantHitFracs = DPrimeData(5, :); 
    VariantHitFracs = VariantHitFracs'; 
    
    VariantFAFracs = DPrimeData(6, :); 
    VariantFAFracs = VariantFAFracs' ;
    
    TotalHitFracs = DPrimeData(8, :); 
    TotalHitFracs = TotalHitFracs'; 
    
    TotalFAFracs = DPrimeData(9, :); 
    TotalFAFracs = TotalFAFracs' ;
    
        
    DefaultDPrimes = DPrimeData(4, :); 
    DefaultDPrimes =  DefaultDPrimes';
    
    VariantDPrimes = DPrimeData(7, :); 
    VariantDPrimes =  VariantDPrimes';
       
    TotalDPrimes = DPrimeData(10, :); 
    TotalDPrimes =  TotalDPrimes';
    


    
    for x = 2:NumFirstChars 
        
        
        SameDay = FirstChars(x,1) - FirstChars((x-1),1); 
       
       if SameDay == 0 
           
           AvgFAFrac = mean([TotalFAFracs(x-1) TotalFAFracs(x)]); 
           AvgHitFrac = mean([HitFracs(x-1) HitFracs(x)]); 
           
           AvgFANorm = norminv(AvgFAFrac); 
           AvgHitNorm = norminv(AvgHitFrac);
           
           AvgDPrime = AvgHitNorm-AvgFANorm; 
           
           TotalDPrimes(x) = AvgDPrime; 
           TotalDPrimes(x-1) = 0; 
           
           AvgTrials = mean([Trials(x-1) Trials(x)]);  
           
           Trials(x) = AvgTrials; 
           Trials(x-1) = 0; 
           
           HitFracs(x) = AvgHitFrac; 
           HitFracs(x-1) = 0; 
           
           TotalFAFracs(x) = AvgFAFrac; 
           TotalFAFracs(x-1) = 0; 
           
           Dates((x-1), (i-2)) = 0; 
           
       end 
    end
    
    
    
    Trials = nonzeros(Trials); 
    NumTrials = length(Trials); 
    AllTrials(1:NumTrials, (i-2)) = Trials; 
    
    DefaultDPrimes = nonzeros(DefaultDPrimes); 
    NumDefaultPrimes = length(DefaultDPrimes);
    AllDefaultDPrimes(1:NumDefaultPrimes, (i-3)) = DefaultDPrimes; 
    
    VariantDPrimes = nonzeros(VariantDPrimes); 
    NumVariantPrimes = length(VariantDPrimes);
    AllVariantDPrimes(1:NumDefaultPrimes, (i-3)) = VariantDPrimes; 

    TotalDPrimes = nonzeros(TotalDPrimes); 
    NumTotalPrimes = length(TotalDPrimes);
    AllTotalDPrimes(1:NumTotalPrimes, (i-3)) = TotalDPrimes; 
    

    
    %plot total d primes 
    
    if NumTotalPrimes == 1
        
      plot(TotalDPrimes, 'o');  
    
    else if i < 8
    
    plot(TotalDPrimes,  'LineWidth', 2); 
   
    else 
    plot(TotalDPrimes, '--',  'LineWidth', 2); 
        
        end 
    end 
    hold on;
    
   legend(MouseNames, 'Location', 'southeast'); 
     
    NumTotalPrimes = length(TotalDPrimes);    

    end 
end 


% cd(AnalyzedPath); 
% FigureSaveName = 'Behavioral_DPrimes_as_of_7/20.png'; 
% FigureSave = strcat(pwd, '\', FigureSaveName); 
% saveas(gcf, FigureSaveName); 
% %close(VertTrialsOne); 


NumMiceFolders = 0; 

for i = 1:NumMiceAnalyFiles
    
    FolderName = MiceAnalysisFolders(i).name;
    BHFolder = findstr(FolderName, 'BH'); 
    
    if isempty(BHFolder) == 0
        
       NumMiceFolders = NumMiceFolders +1; 
       
    end 
    
end 

NumMiceFolders; 

AllIndivDPrimes = figure('name', 'All Indiv DPrimes Variants'); 

for i = 1:(NumMiceFolders)

    subplot(2, 3, i); 
    
    IndivDefaultPrimes = AllDefaultDPrimes(:, i); 
    IndivDefaultPrimes = nonzeros(IndivDefaultPrimes); 
     
    IndivVariantPrimes = AllVariantDPrimes(:, i); 
    IndivVariantPrimes = nonzeros(IndivVariantPrimes); 
         
    IndivTotalPrimes = AllTotalDPrimes(:, i); 
    IndivTotalPrimes = nonzeros(IndivTotalPrimes); 
    
    MouseDates = nonzeros(Dates(:, i)); 
    NumDays = length(MouseDates) ; 
    RelativeDays = zeros(NumDays, 1); 
    
    for x = 1:NumDays
    
    RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
    RelativeDays(x, 1) =  RelativeDayNum; 
    
    end 
           
    MouseName = MouseNames(1, i); 
    
    plot(RelativeDays,  IndivDefaultPrimes, '-o', RelativeDays,  IndivVariantPrimes, '-o', RelativeDays,  IndivTotalPrimes, '-o');
    title(MouseName); 
    hold on;  
 
   if i == 2
       
      legend('Default DPrime', 'Variant DPrime', 'Total DPrime', 'Location','northoutside', 'Orientation','horizontal'); 
       
   end 
    
end 

% MouseNames = char(MouseNames); 
% AllIndivDPrimes = figure('name', 'All Indiv DPrimes'); 
% 
% for i = 1:(NumMiceAnalyFiles-3)
%     
%     i; 
%     subplot(6, 2, i); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%  
%     
% end 
% 
% figure('name', 'Indiv DPrimes and Percents BH101-106');
% FAandHits = {'Correct Vertical Trials (Hits)' 'Incorrect Diagonal Trials (False Alarms)'}; 
% 
% for i = 1:6 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(6, 2, (i*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%     
%     subplot(6, 2, i*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivFAFrac = nonzeros(AllTotalFAFrac(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivFAFrac, '-bo');
%     title(MouseName);
%       
%         if i == 3
%         legend(FAandHits, 'Location', 'east');        
%         end 
%         
%     hold on; 
%  
%     
% end 
% 
% figure('name', 'Indiv DPrimes and Percents BH107 - 113'); 
% 
% for i = 7:11 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(5, 2, ((i-6)*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%     
%     subplot(5, 2, (i-6)*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivFAFrac = nonzeros(AllTotalFAFrac(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivFAFrac, '-bo');
%         title(MouseName);
%         
%         if i == 9
%         legend(FAandHits, 'Location', 'east');        
%         end 
%         
%         hold on; 
%    
% end 
% 
% 
% MouseNames = char(MouseNames); 
% AllIndivDPrimes = figure('name', 'All Indiv DPrimes'); 
% 
% for i = 1:(NumMiceAnalyFiles-3)
%     
%     i; 
%     subplot(6, 2, i); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%  
%     
% end 
% 
% figure('name', 'DPrimes, Hits, and True Negatives BH101-106');
% TPandHits = {'Correct Vertical Trials (Hits)' 'Correct Diagonal Trials (True Negative)'}; 
% 
% for i = 1:6 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(6, 2, (i*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%     
%     subplot(6, 2, i*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivTPFrac = nonzeros(TrueNegFracs(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivTPFrac, '-bo');
%     title(MouseName);
%       
%         if i == 3
%         legend(TPandHits, 'Location', 'east');        
%         end 
%         
%     hold on; 
%     
% end 
%  
% 
% figure('name', 'DPrimes, Hits, and True Negatives BH107-113');
% 
% 
% for i = 7:11 %(NumMiceAnalyFiles-3)
%     
%     MouseName = MouseNames(i, :); 
%     
%     subplot(5, 2, ((i-6)*2-1)); 
%     
%     IndivDPrimes = AllTotalDPrimes(:, i); 
%     IndivDPrimes = nonzeros(IndivDPrimes); 
%     
%     MouseDates = nonzeros(Dates(:, i)); 
%     NumDays = length(MouseDates) ; 
%     RelativeDays = zeros(NumDays, 1); 
%     
%     for x = 1:NumDays
%     
%     RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
%     RelativeDays(x, 1) =  RelativeDayNum; 
%     
%     end 
%            
%     MouseName = MouseNames(i, :); 
%     
%     plot(RelativeDays, IndivDPrimes, '-o');
%     title(MouseName); 
%     hold on;  
%         
%     subplot(5, 2, (i-6)*2); 
%     
%     IndivHitFrac = nonzeros(AllTotalHitFrac(:, i)).*100; 
%     IndivTPFrac = nonzeros(TrueNegFracs(:, i)).*100;
%     
%     plot(RelativeDays, IndivHitFrac, '-ro', RelativeDays, IndivTPFrac, '-bo');
%     title(MouseName);
%       
%         if i == 9
%         legend(TPandHits, 'Location', 'east');        
%         end 
%         
%     hold on; 
%     
% end 
% 
