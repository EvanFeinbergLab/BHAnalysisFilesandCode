CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents'; 
DataPath = 'D:\Brooke\Data\Discrim Variant'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles
    
    i; 
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), 1); 
    NameAndDate = cell((NumDateFiles-2), 2); 
    
    for x = 3:NumDateFiles
        
        DateFile = MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
           
    %sort files in order of date 
        
    FirstComma = findstr(DateFilePath, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = findstr(DateFilePath, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = findstr(DateFilePath, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = DateFilePath(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates((x-2), 1) = DateNum; 
    
    DateCell = cellstr(DateNumString); 
    NameCell = cellstr(DateFile); 
    
    NameAndDate((x-2), 1) = DateCell; 
    NameAndDate((x-2), 2) = NameCell;
     
    end
   
    AscendDates = sort(Dates); 
    NumDates = length(Dates); 
    AscendFiles = cell(NumDates, 1); 
    
    for x = 1:NumDates 
        
        FindIt = find(Dates == AscendDates(x));
        AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
    end
    
    AscendFiles = char(AscendFiles);
    ItNums = zeros(NumDates, 1);
     cd(MouseFolderDataPath); 
    
    for x = 1:NumDates 
                  
        FirstChar = AscendFiles(x, 1); 
        SecondChar = AscendFiles(x, 2);
        IsNum = str2num(FirstChar);
        IsNumTwo = str2num(SecondChar);
        
        if isempty(IsNumTwo) == 0
            
            TwoDigits = strcat(FirstChar, SecondChar); 
            IsNum = str2num(TwoDigits); 
            
        end 

        if isempty(IsNum) == 0 
        
            if IsNum ~= x
                
                OldName = AscendFiles(x, :); 
                OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                AscendFiles(x, 1) = num2str(x); 
                RevisedName = AscendFiles(x, :);
                RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                movefile(OldNamePath, RevisedName);
            end 
        
        else 
            
        OldName = AscendFiles(x, :); 
        OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
        ItString = num2str(x); 
        NewName = strcat(ItString, AscendFiles(x, :));
        NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 
       
        movefile(OldNamePath, NewNamePath);            

        end
        
    end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = findstr(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRewards = single.empty(500000, 0); 
 AllLicks = single.empty(500000, 0); 
  AllTime = single.empty(500000, 0); 
 AllRZ = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(10*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 10*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,10*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 11);  
Zeros = zeros(1, 11); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 10 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:10)= StimInfo;
     
    StimPos(y, 11) = y; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end 

StimnLick = zeros(movnu, 5); 

StimnLick(:, 1) = StimPos(:, 3); %stim
StimnLick(:, 2) = StimPos(:, 4);%lick
StimnLick(:, 3) = StimPos(:, 5); %reward
StimnLick(:, 4) = Timer(:, 1); 
StimnLick(:, 5) = StimPos(:, 6);
StimnLick(:, 6) = StimPos(:, 1);

Stims = StimnLick(:, 1); 
Licks = StimnLick(:, 2); 
Rewards = StimnLick(:, 3);
Timer = StimnLick(:, 4);
RZDist = StimnLick(:, 5);
Dist= StimnLick(:, 6);
StimSize = StimPos(:, 7); 
StimSide = StimPos(:, 8);
CueSide = StimPos(:, 9);
StimMotion = StimPos(:, 10);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllLicks(1:movnu) = Licks;
    AllReward(1:movnu) = Rewards;
    AllTime(1:movnu) = Timer;
    AllRZ(1:movnu) = RZDist;
    AllDist(1:movnu) = Dist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims; 
    
    AllRewards(StartFill: (StartFill+movnu) - 1) = Rewards;   
    AllLicks(StartFill: (StartFill+movnu) - 1) = Licks;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
    AllRZ(StartFill: (StartFill+movnu) - 1) = RZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = Dist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
RZDist = round(AllRZ)'; 
Stims = AllStims';
Licks = AllLicks';
Rewards = AllRewards';
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

%find deriv/change in value of licks 

derivLicks = diff(Licks); 
NumDiffLicks = length(derivLicks); 

DerivLicks  = abs(derivLicks); 
DerivLicks = [0; DerivLicks]; 
%Licks = DerivLicks; 


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 2));   
NumStim = length(VertStimNum); 
StimIts = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIts(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        StimIts(i, 1) = 0; 
    else 
        StimIts(i, 1) = VertStimNum(i);
    end 
    end 
end 

StimIts = nonzeros(StimIts);   
NumVertStim = length(StimIts); 

%separate default from variant stims 

VertVariants = zeros(NumVertStim, 1); 
VertDefaults = zeros(NumVertStim, 1);
StimTypes = zeros(NumVertStim, 1);

for i = 1:NumVertStim
    
    StimIt = StimIts(i) ; 
    
    if i < NumVertStim 
        
    NextStim = StimIts(i+1);
    FindStimType = find(RZDist(StimIts(i): NextStim) ~= 0); 
    
    if isempty(FindStimType) == 0
    
    StimTypeIt = (FindStimType(1) + StimIts(i)) - 1; 
    StimType = RZDist(StimTypeIt);   
    StimTypes(i, 1) = StimType; 
    
    if StimType < 20
        
         VertDefaults(i, 1) = StimIts(i);
        
    else 
         VertVariants(i, 1) = StimIts(i); 
        
      end
    end
              
    else 
        
        FindStimType = find(RZDist(StimIts(i): end) ~= 0); 
        
        if isempty(FindStimType) == 0
    
            StimTypeIt = (FindStimType(1) + StimIts(i)) - 1; 
            StimType = RZDist(StimTypeIt); 
            StimTypes(i, 1) = StimType; 
            
            if StimType < 20
        
         VertDefaults(i, 1) = StimIts(i);
        
        else 
         VertVariants(i, 1) = StimIts(i); 
        
      end
        end
        
    end
        
      if length(FindStimType) == 1
          
         VertDefaults(i, 1) = 0;  
         VertVariants(i, 1) = 0; 
         
      end 

end 

StimTypes = nonzeros(StimTypes); 
VertVariants = nonzeros(VertVariants); 
NumVertVariants = length(VertVariants);

VertDefaults = nonzeros(VertDefaults); 
NumVertDefaults = length(VertDefaults); 

RZStarts = zeros(NumVertDefaults); 
RZEnds = zeros(NumVertDefaults); 

for i = 1: NumVertDefaults 
       
    VDefault = VertDefaults(i); 
    
    if i < NumVertDefaults
    
    NextStim = VertDefaults(i+1); 
    RZStart = find(RZDist(VDefault:NextStim) >= 30);      
    RZEnd = find(RZDist(VDefault:NextStim) >= 70);
    else 
    RZStart = find(RZDist(VDefault:end) >= 30);
    RZEnd = find(RZDist(VDefault:end) >= 70);
    end
    
    if isempty(RZStart) == 0 
    RZStart = RZStart(1); 
    RZStartIt = (RZStart+VDefault) - 1; 
    RZStarts(i, 1) = RZStartIt;        
    end 
    
    if isempty(RZEnd) == 0 
    RZEnd = RZEnd(1); 
    RZEndIt = (RZEnd+VDefault) - 1; 
    RZEnds(i, 1) = RZEndIt; 
    end 
    
    if isempty(RZStart) == 0 && isempty(RZEnd) == 1
        
         VertDefaults(i, 1) = 0; 
         RZEnds(i, 1) = 0; 
         RZStarts(i, 1) = 0; 
         
    end
    
     if isempty(RZStart) == 1 && isempty(RZEnd) == 0
        
         VertDefaults(i, 1) = 0; 
         RZEnds(i, 1) = 0; 
         RZStarts(i, 1) = 0; 
         
     end
    
       if isempty(RZStart) == 1 && isempty(RZEnd) == 1
        
         VertDefaults(i, 1) = 0; 
         RZEnds(i, 1) = 0; 
         RZStarts(i, 1) = 0; 
         
    end
    
end 

RZStarts = nonzeros(RZStarts);
NumStarts = length(RZStarts)  

RZEnds = nonzeros(RZEnds);
NumEnds = length(RZEnds)

VertDefaults = nonzeros(VertDefaults); 
NumVertDefaults = length(VertDefaults)



RZRewards = zeros(NumStarts, 1); 

for i = 1:NumStarts
    
    RZStart = RZStarts(i); 
    RZEnd = RZEnds(i);
    
    FindLick = find(Licks(RZStart:RZEnd) == 1); 
    
    if isempty(FindLick) == 0
        
        FindLick = FindLick(1); 
        RewardIt = (FindLick + RZStart) - 1; 
        RZRewards(i,1) = RewardIt; 
    end 
    
end 

RZRewards = nonzeros(RZRewards);
NumRZRewards = length(RZRewards) 

FullWindow = 0; 
VariantRewards = zeros(NumVertVariants, 1); 

for i = 1:NumVertVariants
    
    VariantIt = VertVariants(i); 
    
    if i < NumVertVariants  
    
    NextVariant = VertVariants(i+1);   
    LickWindow = find(RZDist(VariantIt:NextVariant) ~= 0); 
    
    else 
        
         LickWindow = find(RZDist(VariantIt:end) ~= 0); 
         
    end
    
    if isempty(LickWindow) == 0
        
    StartWindow = LickWindow(1); 
    EndWindow = LickWindow(end);
    StartWindowIt = (VariantIt + StartWindow) - 1; 
    StartWindowIt = StartWindowIt - 1;
    EndWindowIt = (VariantIt + EndWindow) - 1;
    
    WindowStartValue = RZDist(StartWindowIt); 
    WindowEndValue = RZDist(EndWindowIt);
    
    FindLicks = find(Licks(StartWindowIt:EndWindowIt) == 1); 
    
    if isempty(FindLicks) == 0 
       
        LickIt = FindLicks(1); 
        RewardIt = (LickIt + VariantIt) - 1; 
        VariantRewards(i, 1) = RewardIt;
        
    else 
        
        FullWindow =  WindowEndValue; 
        
    end
    
    else
        
       VertVariants(i, 1) = 0; 
       
    end 
    
end 

if FullWindow == 0 
    
    FullWindow = 800; %add code to ask for length of lick window 
    
end 

VertVariants = nonzeros(VertVariants); 
VariantRewards = nonzeros(VariantRewards); 
 
NumVertVariants = length(VertVariants)
NumVaryRewards = length(VariantRewards); 

 
VertHitLatencies = zeros(NumVertVariants, 1); 
 
for i = 1: NumVertVariants 
    
    StimIt = VertVariants(i); 
    
    StimTime = Timer(StimIt); 
    EndWindowTime = StimTime + 0.5; 
    EndWindowIt = find(Timer <= EndWindowTime); 
    EndWindowIt = EndWindowIt(end); 
    
    Licked = find(Licks(StimIt:EndWindowIt) == 1); 
    
    if isempty(Licked) == 0
        
        FirstLick = Licked(1); 
        LickIt = (StimIt + FirstLick) - 1; 
        LickTime = Timer(LickIt); 

        LickLatency = (LickTime - StimTime)*1000; 
        VertHitLatencies(i, 1) = LickLatency; 
        
    end   
   
end 

VertHitLatencies = nonzeros(VertHitLatencies); 
VertLatAvg = mean(VertHitLatencies)

%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 1));   
NumDiagStim = length(DiagStimNum); 
DiagStimIts = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStimIts(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStimIts(i, 1) = 0; 
    else 
        DiagStimIts(i, 1) = DiagStimNum(i);
    end 
    end 
end 

DiagStimIts = nonzeros(DiagStimIts);
NumDiagStim = length(DiagStimIts) 

DiagVariants = zeros(NumDiagStim, 1); 
DiagDefaults = zeros(NumDiagStim, 1);

for i = 1:NumDiagStim 
    
    DiagStim = DiagStimIts(i); 
    FindStimType = StimLength(DiagStim:DiagStim+10);  
    FindStimType = mode(FindStimType);      
    
    if FindStimType == 2 
        
        DiagVariants(i, 1) = DiagStim; 
        
    else if FindStimType == 1
        
       DiagDefaults(i, 1) = DiagStim; 
        
        end 
    end
end 

DiagVariants = nonzeros(DiagVariants); 
DiagDefaults = nonzeros(DiagDefaults); 

NumDiagVariants = length(DiagVariants) 
NumDiagDefaults = length(DiagDefaults) 


NumDiagStim = NumDiagVariants + NumDiagDefaults; 
NumVertStim = NumVertVariants + NumVertDefaults; 

TotalTrials = NumDiagStim + NumVertStim;


 
VertHitLatencies = zeros(NumVertVariants, 1); 
 
for i = 1: NumDiagVariants 
    
    StimIt = DiagVariants(i); 
    
    StimTime = Timer(StimIt); 
    EndWindowTime = StimTime + 0.5; 
    EndWindowIt = find(Timer <= EndWindowTime); 
    EndWindowIt = EndWindowIt(end); 
    
    Licked = find(Licks(StimIt:EndWindowIt) == 1); 
    
    if isempty(Licked) == 0
        
        FirstLick = Licked(1); 
        LickIt = (StimIt + FirstLick) - 1; 
        LickTime = Timer(LickIt); 

        LickLatency = (LickTime - StimTime)*1000; 
        VertHitLatencies(i, 1) = LickLatency; 
        
    end   
   
end 

VertHitLatencies = nonzeros(VertHitLatencies); 
VertLatAvg = mean(VertHitLatencies)




AllDiagStimIts = [DiagVariants; DiagDefaults]; 
AllDiagStimIts = sort(AllDiagStimIts,'descend'); 
NumDiagIts = length(AllDiagStimIts); 




%test for # iterations per 1 ms 
  
    VertIt =  StimIts(1); %iteration of each reward
    StimTime = round(Timer(VertIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  VertIt - ItBefore;   
     

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 20; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;

 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;
 
 StartSpan=   VertIt- (RevAnalysisLength);
 EndSpan = VertIt+ (FwdAnalysisLength);
  
 SpanLength = EndSpan - StartSpan; 
  
  
%peristimulus and reward lick behavior for all vert 

VertLicksinSpan = zeros(SpanLength, NumVertStim-2); 
VertTimeofSpan = zeros(SpanLength,NumVertStim-2); 
VertSpeedinSpan = zeros(SpanLength,NumVertStim-2); 
VertCorridorColor = zeros(NumVertStim-2, 1); 

AllVertStim = [VertDefaults; VertVariants]; 
AllVertStim = sort(AllVertStim, 'ascend'); 


for i = 2:NumVertStim-1 %ignore first and last trial 
    
    VertStim = AllVertStim(i); 
    IsVariant = find(VertVariants == VertStim); 
    
    if isempty(IsVariant) == 1  %is default
        
    VertDefaultIt =  VertStim; 
    StimTime = Timer(VertDefaultIt); 
   
    StartSpan=   VertDefaultIt- (RevAnalysisLength);
    EndSpan =  VertDefaultIt+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

    VertLicksinSpan(:, i) = Licks((StartSpan+1):EndSpan);
    VertSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
    VertTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
    
    for y = 1:SpanLength
         VertTimeofSpan(y, i) = VertTimeofSpan(y, i) - StimTime; 
    end 
    
    VertTimeofSpan(:, i) ;
    VertCorridorColor(i, 1) = 1; %green
    
    
    else %is variant 
        
        VertVariantIt = VertStim; 
        
        if i < (NumVertStim-1) 
        NextStim = AllVertStim(i+1); 
        LickWindow = find(RZDist(VertVariantIt: NextStim) ~= 0); 
        else           
              LickWindow = find(RZDist(VertVariantIt: end) ~= 0); 
        end
         
        StartWindow = LickWindow(1); 
        StartWindowIt = (VertVariantIt + StartWindow) - 1; 
        StartWindowIt = StartWindowIt - 1; 
        
        StartWindowTime = Timer(StartWindowIt, 1);
        StimTime = StartWindowTime; 
       
       StartSpan=   VertVariantIt- (RevAnalysisLength);
       EndSpan =  VertVariantIt+ (FwdAnalysisLength); 
       SpanLength = EndSpan - StartSpan; 
         
        VertLicksinSpan(:, i) = Licks((StartSpan+1):EndSpan);
        VertSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
        VertTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan); 
        
        for y = 1:SpanLength
            VertTimeofSpan(y, i) = VertTimeofSpan(y, i) - StimTime; 
        end 
    
        VertTimeofSpan(:, i) ;
        
    end 
end


VertLicksinSpan = VertLicksinSpan';  
[r c] = size(VertLicksinSpan); 
VertTimeofSpan = VertTimeofSpan';  
VertSpeedinSpan = VertSpeedinSpan';


%PresentTime = 0.8; %seconds 

% %peristimulus and reward lick behavior for diag stim 

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 20; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan; 
 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;

DiagLicksinSpan = zeros(SpanLength, NumDiagStim -2); 
DiagTimeofSpan = zeros(SpanLength, NumDiagStim -2); 
DiagSpeedinSpan = zeros(SpanLength, NumDiagStim -2); 

AllDiagStim = [DiagDefaults; DiagVariants]; 
AllDiagStim = sort(AllDiagStim, 'ascend'); 

for i = 2:NumDiagStim-1
    
    DiagStim = AllDiagStim(i);
    
    DiagStimTime = Timer(DiagStim); 
   
    StartSpan=  DiagStim- (RevAnalysisLength);
    EndSpan =DiagStim + (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

         DiagLicksinSpan(:, i) = Licks((StartSpan+1):EndSpan);
         DiagSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
         DiagTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
         
         for y = 1:SpanLength
            
         DiagTimeofSpan(y, i) = DiagTimeofSpan(y, i) - DiagStimTime; 
         
         end 
    
    DiagTimeofSpan(:, i); 
        
end

DiagLicksinSpan = DiagLicksinSpan';
DiagTimeofSpan = DiagTimeofSpan'; 
DiagSpeedinSpan = DiagSpeedinSpan'; 





AllRewards = [VariantRewards; RZRewards]; 
AllRewards = sort(AllRewards, 'ascend'); 


CurrentDir = pwd; 
FindStart = findstr(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = strcat(CodePath, '\', 'Analyzed');
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(CodePath, '\', 'Analyzed', '\', SaveString); 
cd(SavePath); 

FindSeshNum = findstr(SavePath, '\'); 
FindSeshNum = FindSeshNum(end); 
SeshNumIt = FindSeshNum + 1; 
SeshNum = strcat('Session', SavePath(SeshNumIt)); 


XLabel = 'Peristimulus Time (s)';
YLabel = 'Trial'; 

Trials = (1:NumVertStim);
VertTrialsOne = figure('name','Vertical Trials Part1'); 

MaxLickWindow = max(RZDist); 

for i = 1:round((NumVertStim/2)) 
    
    i;  
    x = VertTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
      
    hold on; 
       
    VertIt = AllVertStim(i);
    
    IsVariant = find(VertVariants == VertIt);
    
    if isempty(IsVariant) == 1  %is default
        
    VertDefaultIt =  VertIt;
    StimTime = Timer(VertDefaultIt);
    
    RZIt = find(VertDefaults == VertIt);
    
     EndRZ = RZEnds(RZIt);
     RZEndTime = Timer(EndRZ)-StimTime;  
     
     StartRZ = RZStarts(RZIt);
     RZStartTime = Timer(StartRZ)-StimTime;  
     
     StartTime = 0; 
     
     RZSpan = [StartTime RZEndTime]; 
     Ys = [y y]; 
     Color = [0 0.75 0]; 
     
    plot(RZSpan, Ys, 'Color', Color , 'LineWidth', 6);
    
     hold on;
     

    else %is variant
             
         VertVariantIt = VertIt; 
       
         StimTime = Timer(VertVariantIt, 1);
         StartWindowIt = VertVariantIt; 
        StartWindowTime = 0; 
        EndWindow = StimTime + FullWindow/1000; 
        EndWindowIt = find(Timer >= EndWindow); 
        EndWindowIt = EndWindowIt(1); 
        EndWindowTime = Timer(EndWindowIt) - StimTime; 
        

        RZSpan = [StartWindowTime EndWindowTime]; 
        Ys = [y y]; 
        Color = [0 0.75 1]; 
        
        plot(RZSpan, Ys, 'Color', Color , 'LineWidth', 6);

    end 
     
 
     Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part1'); 
     title(Title); 
     xlabel(XLabel); 
     ylabel(YLabel); 
     
  hold on; 
    
    for a = 1:SpanLength
               
        LickPresent = VertLicksinSpan(i, a);  
        
        if LickPresent == 1
            
            LickTime = VertTimeofSpan(i, a); 
            plot(LickTime, y, 'k.', 'MarkerSize', 10);
            
        end 
    end 
    
    hold on; 

    if isempty(IsVariant) == 1  %is default
       
     RewardLick = find(Licks(StartRZ:EndRZ) == 1); 
     
     if isempty(RewardLick) == 0
         
     Reward = RewardLick(1); 
     RewardIt = (StartRZ + Reward) - 1; 
     RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
     plot(RewardTime, y, 'r.', 'MarkerSize', 16);
        
     end 
    else 

       RewardLick = find(Licks(StartWindowIt:EndWindowIt) == 1); 
       
       if isempty(RewardLick) == 0
           
       Reward = RewardLick(1); 
       RewardIt = (StartWindowIt + Reward) - 1; 
       RewardTime = Timer(RewardIt)-StimTime;    
       plot(RewardTime, y, 'r.', 'MarkerSize', 16);
          
       end 
    end
    
   
end  

FigureSaveName = 'Vert_Trials_Part1.png'; 
saveas(gcf, FigureSaveName); 
close(VertTrialsOne); 




VertTrialTwo = figure('name','Vert Trials Part2'); 
  
 for i = (round(NumVertStim/2)+1): NumVertStim-1
    
  
    i;  
    x = VertTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
      
    hold on; 
       
    VertIt = AllVertStim(i);
    
    IsVariant = find(VertVariants == VertIt);
    
    if isempty(IsVariant) == 1  %is default
        
    VertDefaultIt =  VertIt;
    StimTime = Timer(VertDefaultIt);
    
    RZIt = find(VertDefaults == VertIt);
    
     EndRZ = RZEnds(RZIt);
     RZEndTime = Timer(EndRZ)-StimTime;  
     
     StartRZ = RZStarts(RZIt);
     RZStartTime = Timer(StartRZ)-StimTime;  
     
     RZSpan = [RZStartTime RZEndTime]; 
     Ys = [y y]; 
     Color = [0 0.75 0]; 
     
    plot(RZSpan, Ys, 'Color', Color , 'LineWidth', 6);
    
     hold on;
     

     else %is variant
             
         VertVariantIt = VertIt; 
       
         StimTime = Timer(VertVariantIt, 1);
         StartWindowIt = VertVariantIt; 
        StartWindowTime = 0; 
        EndWindow = StimTime + FullWindow/1000; 
        EndWindowIt = find(Timer >= EndWindow); 
        EndWindowIt = EndWindowIt(1); 
        EndWindowTime = Timer(EndWindowIt) - StimTime; 
        

        RZSpan = [StartWindowTime EndWindowTime]; 
        Ys = [y y]; 
        Color = [0 0.75 1]; 
        
        plot(RZSpan, Ys, 'Color', Color , 'LineWidth', 6);

    end 
     
 
     Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part2'); 
     title(Title); 
     xlabel(XLabel); 
     ylabel(YLabel); 
     
  hold on; 
    
    for a = 1:SpanLength
               
        LickPresent = VertLicksinSpan(i, a);  
        
        if LickPresent == 1
            
            LickTime = VertTimeofSpan(i, a); 
            plot(LickTime, y, 'k.', 'MarkerSize', 10);
            
        end 
    end 
    
    hold on; 

    if isempty(IsVariant) == 1  %is default
       
     RewardLick = find(Licks(StartRZ:EndRZ) == 1); 
     
     if isempty(RewardLick) == 0
         
     Reward = RewardLick(1); 
     RewardIt = (StartRZ + Reward) - 1; 
     RewardTime = Timer(RewardIt)-StimTime; %time at that reward occurrence
     plot(RewardTime, y, 'r.', 'MarkerSize', 16);
        
     end 
    else 

       RewardLick = find(Licks(StartWindowIt:EndWindowIt) == 1); 
       
       if isempty(RewardLick) == 0
           
       Reward = RewardLick(1); 
       RewardIt = (StartWindowIt + Reward) - 1; 
       RewardTime = Timer(RewardIt)-StimTime;    
       plot(RewardTime, y, 'r.', 'MarkerSize', 16);
          
       end 
    end
   
   
end  


FigureSaveName = 'Vert_Trials_Part2.png'; 
saveas(gcf, FigureSaveName); 
close(VertTrialTwo); 


% 
% RewardTimes = zeros(NumReward, 1); 
% RZStartTimes = zeros(NumReward, 1); 
% 
% for i = 1: NumReward 
%     
%     VertDefaultIt =  StimIts(i);
%     StimTime = Timer(VertDefaultIt);
%     
%     RewardIt = RewardIts(i); 
%     RewardTime = Timer(RewardIt)-StimTime;
%     RewardTimes(i, 1) = RewardTime; 
%     
%     StartRZ = RZStarts(i);
%     RZStartTime = Timer(StartRZ)-StimTime; 
%     RZStartTimes(i, 1) = RZStartTime; 
%     
% end 

% 
% YLabel = 'Average Licks'; 
% 
% AvgRewardTime = mean(RewardTimes); 
% AvgRZStartTime = mean(RZStartTimes); 
% 
% AvgLicksinSpanForVert = smooth(mean(VertLicksinSpan, 1));  
% Height = max(AvgLicksinSpanForVert); 
% x = VertTimeofSpan(1, :); 
% 
% VertAvgLicks = figure('name', 'Average Licks For Vert Stim In Session'); 
% plot(x, AvgLicksinSpanForVert); 
% hold on; 
% y = linspace(0, Height);  
% plot(AvgRewardTime, y, 'r.'); 
% plot(AvgRZStartTime, y, 'g.'); 
% Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Vert Stim In Session'); 
% title(Title); 
% xlabel(XLabel); 
% ylabel(YLabel);
% 
% FigureSaveName = 'Average_Licks_For_Vert_Stim_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertAvgLicks); 
% 
% YLabel = 'Speed (cm/s)'; 
% 
% %avg speed of trials 
% AvgSpeedinSpanForVert = smooth(mean(VertSpeedinSpan, 1)); 
% Height = max(AvgSpeedinSpanForVert); 
% x = VertTimeofSpan(1, :); 
% 
% VertAvgSpeed = figure('name', 'Average Speed For Vert Stim in Session'); 
% plot(x, AvgSpeedinSpanForVert); 
% hold on; 
% y = linspace(0, Height);  
% plot(AvgRewardTime, y, 'r.'); 
% plot(AvgRZStartTime, y, 'g.');
% Title = strcat(MouseName, '-', SeshNum, ':', 'Average Speed For Vert Stim In Session'); 
% title(Title); 
% xlabel(XLabel); 
% ylabel(YLabel);
% 
% FigureSaveName = 'Average_Speed_For_Vert_Stim_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(VertAvgSpeed); 
% 







Trials = (1:NumDiagStim);
YLabel = 'Trial'; 

DiagTrialsOne = figure('name','Diag Trials Part1'); 

for i = 1:round((NumDiagStim/2)) 
    
   
    x = DiagTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
       
    hold on;     
     
    DiagStimIt = AllDiagStim(i); 
    IsVariant = find(DiagDefaults == DiagStimIt); 
    
    if isempty(IsVariant) == 1 %is default 
        
    DefaultDiag = DiagStimIt; 
    DiagStimTime = Timer(DefaultDiag); 
    
    DiagStimDist = TotalDist(DiagStimIt);
    EndDiagStim = find(TotalDist>= DiagStimDist + 55); 
    EndDiagStim = EndDiagStim(1); 
    
    EndDiagStimTime = Timer(EndDiagStim) - DiagStimTime; 
    
    DiagStimSpan = [0 EndDiagStimTime]; 
    Ys = [y y]; 
    
    plot(DiagStimSpan, Ys, 'r', 'LineWidth', 6);
  

    hold on; 
    
    else %is Variant 
        
        VariantDiag = DiagStimIt; 
        DiagStimTime = Timer(VariantDiag); 
        
        DiagWindowSpan = [0 (FullWindow/1000)]; 
        Ys = [y y];
        
        plot(DiagWindowSpan, Ys, 'm', 'LineWidth', 6);
        
    end 
    
        for z = 1:SpanLength
        
        LickPresent = DiagLicksinSpan (i, z);  
        
        if LickPresent == 1
            
            LickTime = DiagTimeofSpan(i, z); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
        end  
    
        hold on; 
        
         Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
        title(Title); 
        xlabel(XLabel); 
        ylabel(YLabel);
    
end 

FigureSaveName = 'Diag_Trials_Part1.png'; 
saveas(gcf, FigureSaveName); 
close(DiagTrialsOne); 



DiagTrialsTwo = figure('name','DiagTrials Part2'); 

for i = round((NumDiagStim/2))+1 : NumDiagStim-1 
   
       x = DiagTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
       
    hold on;     
     
    DiagStimIt = AllDiagStim(i); 
    IsVariant = find(DiagDefaults == DiagStimIt); 
    
    if isempty(IsVariant) == 1 %is default 
        
    DefaultDiag = DiagStimIt; 
    DiagStimTime = Timer(DefaultDiag); 
    
    DiagStimDist = TotalDist(DiagStimIt);
    EndDiagStim = find(TotalDist>= DiagStimDist + 55); 
    EndDiagStim = EndDiagStim(1); 
    
    EndDiagStimTime = Timer(EndDiagStim) - DiagStimTime; 
    
    DiagStimSpan = [0 EndDiagStimTime]; 
    Ys = [y y]; 
    
    plot(DiagStimSpan, Ys, 'r', 'LineWidth', 6);
  

    hold on; 
    
    else %is Variant 
        
        VariantDiag = DiagStimIt; 
        DiagStimTime = Timer(VariantDiag); 
        
        DiagWindowSpan = [0 (FullWindow/1000)]; 
        Ys = [y y];
        
        plot(DiagWindowSpan, Ys, 'm', 'LineWidth', 6);
        
    end 
    
        for z = 1:SpanLength
        
        LickPresent = DiagLicksinSpan (i, z);  
        
        if LickPresent == 1
            
            LickTime = DiagTimeofSpan(i, z); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
        end  
    
        hold on; 
        
         Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
        title(Title); 
        xlabel(XLabel); 
        ylabel(YLabel);
       
end  

FigureSaveName = 'Diag_Trials_Part2.png'; 
saveas(gcf, FigureSaveName); 
close(DiagTrialsTwo); 




% EndDiagStimTimes = zeros(NumDiagStim, 1); 
% 
% for i = 1:NumDiagStim
%     
%     DiagStimIt = DiagStimIts(i); 
%     DiagStimTime = Timer(DiagStimIt); 
%     
%     DiagStimDist = TotalDist(DiagStimIt);
%     EndDiagStim = find(AllDist>= DiagStimDist + 55); 
%     EndDiagStim = EndDiagStim(1); 
%     
%     EndDiagStimTime = Timer(EndDiagStim) - DiagStimTime;
%     EndDiagStimTimes(i, 1) = EndDiagStimTime; 
% 
% end 
% YLabel = 'Average Licks'; 
% 
% AvgEndDiagStimTime = mean(EndDiagStimTimes); 
% AvgLicksinSpanForDiag = smooth(mean(DiagLicksinSpan, 1)); 
% 
% Height = max(AvgLicksinSpanForDiag); 
% x = DiagTimeofSpan(1, :); 
% 
% DiagAvgLicks = figure('name', 'Average Licks For Diag Stim InSession'); 
% plot(x, AvgLicksinSpanForDiag); 
% hold on; 
% y = linspace(0, Height); 
% plot(AvgEndDiagStimTime, y, 'r.'); 
%  Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Diagonal Stim In Session'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
%     
% FigureSaveName = 'Average_Licks_For_Diag_Stim_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagAvgLicks); 
% 
% 
% SeshAvgLicks = figure('name', 'Average Licks For Session');
% plot(x, AvgLicksinSpanForDiag, x, AvgLicksinSpanForVert);
% hold on; 
% plot(0, y, 'k.');
%  Title = strcat(MouseName, '-', SeshNum, ':', 'Average Licks For Session'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
%     
% FigureSaveName = 'Average_Licks_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(SeshAvgLicks); 
% 
% 
% YLabel = 'Speed (cm/s)';
% 
% %avg speed of trials 
% AvgSpeedinSpanForDiag = smooth(mean(DiagSpeedinSpan, 1)); 
% Height = max(AvgSpeedinSpanForDiag); 
% x = DiagTimeofSpan(1, :) ;
% 
% DiagAvgSpeed = figure('name', 'Average Speed For Diag Stim in Session'); 
% plot(x, AvgSpeedinSpanForDiag); 
% hold on; 
% y = linspace(0, Height); 
% plot(AvgEndDiagStimTime, y, 'r.');
%  Title = strcat(MouseName, '-', SeshNum, ':', 'Average Speed For Diagonal Stim In Session'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
%  
% 
% FigureSaveName = 'Average_Speed_For_Diag_Stim_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagAvgSpeed); 
% 
% DiagSeshSpeed = figure('name', 'Average Speed For Session'); 
% plot(x, AvgSpeedinSpanForVert, x, AvgSpeedinSpanForDiag);
% hold on; 
% plot(0, y, 'k.'); 
%  Title = strcat(MouseName, '-', SeshNum, ':', 'Average Speed For Session'); 
%     title(Title); 
%     xlabel(XLabel); 
%     ylabel(YLabel);
% 
%     
% FigureSaveName = 'Average_Speed_In_Session.png'; 
% saveas(gcf, FigureSaveName); 
% close(DiagSeshSpeed); 
% 
% 
% 
% %calc behavioral d-prime 
% 
% Hits = nonzeros(Hits); 
% numHits = length(Hits); 
% HitFrac = numHits/NumReward; 
% 
% 
% FalseAlarm = zeros(NumDiagStim, 1); 
% 
% for i = 1: NumDiagStim 
%  
%     DiagStimIt = DiagStimIts(i);    
%     DiagStimDist = TotalDist(DiagStimIt);
%     EndDiagStim = find(TotalDist>= DiagStimDist + 55); 
%     EndDiagStim = EndDiagStim(1); 
%     
%     LickInDiag = find(Licks(DiagStimIt:EndDiagStim) == 1);  
%     
%     if isempty(LickInDiag) == 0
%         
%         LickIt = LickInDiag(1);
%         FalseAlarm(i, 1) = LickIt; 
%         
%     end                
% end 
% 
% NumFalseAlarm = length(FalseAlarm) 
% FalseAlarmProb = NumFalseAlarm/NumDiagStim; 

cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 

    
end 



   



