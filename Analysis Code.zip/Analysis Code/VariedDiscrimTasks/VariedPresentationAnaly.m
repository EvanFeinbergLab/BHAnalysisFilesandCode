CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents'; 
DataPath = 'D:\Brooke\Data'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 


for i = 3:NumMiceFiles
    
    i; 
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(pwd, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), 1); 
    NameAndDate = cell((NumDateFiles-2), 2); 
    
    for x = 3:NumDateFiles
        
        DateFile = MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
           
    %sort files in order of date 
        
    FirstComma = findstr(DateFilePath, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = findstr(DateFilePath, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = findstr(DateFilePath, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = DateFilePath(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates((x-2), 1) = DateNum; 
    
    DateCell = cellstr(DateNumString); 
    NameCell = cellstr(DateFile); 
    
    NameAndDate((x-2), 1) = DateCell; 
    NameAndDate((x-2), 2) = NameCell;
     
    end
   
    AscendDates = sort(Dates); 
    NumDates = length(Dates); 
    AscendFiles = cell(NumDates, 1); 
    
    for x = 1:NumDates 
        
        FindIt = find(Dates == AscendDates(x));
        AscendFiles(x, 1) = NameAndDate(FindIt, 2); 
    end
    
    AscendFiles = char(AscendFiles);
    ItNums = zeros(NumDates, 1);
     cd(MouseFolderDataPath); 
    
    for x = 1:NumDates 
                  
        FirstChar = AscendFiles(x, 1); 
        SecondChar = AscendFiles(x, 2);
        IsNum = str2num(FirstChar);
        IsNumTwo = str2num(SecondChar);
        
        if isempty(IsNumTwo) == 0
            
            TwoDigits = strcat(FirstChar, SecondChar); 
            IsNum = str2num(TwoDigits); 
            
        end 

        if isempty(IsNum) == 0 
        
            if IsNum ~= x
                
                OldName = AscendFiles(x, :); 
                OldNamePath = strcat(MouseFolderDataPath, '\', OldName); 
                AscendFiles(x, 1) = num2str(x); 
                RevisedName = AscendFiles(x, :);
                RevisedNamePath = strcat(MouseFolderDataPath, '\',RevisedName); 
                movefile(OldNamePath, RevisedName);
            end 
        
        else 
            
        OldName = AscendFiles(x, :); 
        OldNamePath = strcat(MouseFolderDataPath, '\', OldName);  
        ItString = num2str(x); 
        NewName = strcat(ItString, AscendFiles(x, :));
        NewNamePath = strcat(MouseFolderDataPath, '\', NewName); 
       
        movefile(OldNamePath, NewNamePath);            

        end
        
    end 
    end 
end 
    %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = findstr(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRewards = single.empty(500000, 0); 
 AllLicks = single.empty(500000, 0); 
  AllTime = single.empty(500000, 0); 
 AllRZ = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(10*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 10*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,10*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 11);  
Zeros = zeros(1, 11); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 10 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:10)= StimInfo;
     
    StimPos(y, 11) = y; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end 

StimnLick = zeros(movnu, 5); 

StimnLick(:, 1) = StimPos(:, 3); %stim
StimnLick(:, 2) = StimPos(:, 4);%lick
StimnLick(:, 3) = StimPos(:, 5); %reward
StimnLick(:, 4) = Timer(:, 1); 
StimnLick(:, 5) = StimPos(:, 6);
StimnLick(:, 6) = StimPos(:, 1);

Stims = StimnLick(:, 1); 
Licks = StimnLick(:, 2); 
Rewards = StimnLick(:, 3);
Timer = StimnLick(:, 4);
RZDist = StimnLick(:, 5);
Dist= StimnLick(:, 6);
StimSize = StimPos(:, 7); 
StimSide = StimPos(:, 8);
CueSide = StimPos(:, 9);
StimMotion = StimPos(:, 10);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllLicks(1:movnu) = Licks;
    AllReward(1:movnu) = Rewards;
    AllTime(1:movnu) = Timer;
    AllRZ(1:movnu) = RZDist;
    AllDist(1:movnu) = Dist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims; 
    
    AllRewards(StartFill: (StartFill+movnu) - 1) = Rewards;   
    AllLicks(StartFill: (StartFill+movnu) - 1) = Licks;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
    AllRZ(StartFill: (StartFill+movnu) - 1) = RZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = Dist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
RZDist = round(AllRZ)'; 
Stims = AllStims';
Licks = AllLicks';
Rewards = AllRewards';
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

%find deriv/change in value of licks 

derivLicks = diff(Licks); 
NumDiffLicks = length(derivLicks); 

DerivLicks  = abs(derivLicks); 
DerivLicks = [0; DerivLicks]; 
%Licks = DerivLicks; 


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 2));   
NumStim = length(VertStimNum); 
StimIts = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIts(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        StimIts(i, 1) = 0; 
    else 
        StimIts(i, 1) = VertStimNum(i);
    end 
    end 
end 

StimIts = nonzeros(StimIts);   
NumVertStim = length(StimIts); 

%separate 800ms present from 500ms present 

VertVariants = zeros(NumVertStim, 1); 
VertDefaults = zeros(NumVertStim, 1);
StimTypes = zeros(NumVertStim, 1);

LongWindowVert = zeros(NumVertStim, 1);
ShortWindowVert = zeros(NumVertStim, 1);

for i = 1:NumVertStim
    
    StimIt = StimIts(i) ; 
    
    WindowType = StimLength(StimIt:StimIt+10); 
    WindowType = mode(WindowType); 
    
    if WindowType == 1 %WindowLength = 800ms
        
        LongWindowVert(i, 1) = StimIt; 
        
    else if WindowType == 2 %WindowLength = 500 ms
            
            ShortWindowVert(i, 1) = StimIt;
            
        end 
    end
    

end 

LongWindowVert = nonzeros(LongWindowVert); 
ShortWindowVert = nonzeros(ShortWindowVert); 

NumLongVert = length(LongWindowVert)
NumShortVert = length(ShortWindowVert)


    

%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 1));   
NumDiagStim = length(DiagStimNum); 
DiagStimIts = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStimIts(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStimIts(i, 1) = 0; 
    else 
        DiagStimIts(i, 1) = DiagStimNum(i);
    end 
    end 
end 

AllDiagStim = nonzeros(DiagStimIts);
NumDiagStim = length(AllDiagStim) 

LongWindowDiag = zeros(NumDiagStim, 1); 
ShortWindowDiag = zeros(NumDiagStim, 1);

for i = 1:NumDiagStim 
    
    DiagStim = AllDiagStim(i); 
    FindStimType = StimLength(DiagStim:DiagStim+10);  
    FindStimType = mode(FindStimType);      
    
    if FindStimType == 2 %500ms
        
        ShortWindowDiag(i, 1) = DiagStim; 
        
    else if FindStimType == 1 %800ms
        
       LongWindowDiag(i, 1) = DiagStim; 
        
        end 
    end
end 

ShortWindowDiag = nonzeros(ShortWindowDiag); 
LongWindowDiag = nonzeros(LongWindowDiag); 

NumShortDiag = length(ShortWindowDiag) 
NumLongDiag = length(LongWindowDiag) 





%test for # iterations per 1 ms 
  
    VertIt =  StimIts(1); %iteration of each reward
    StimTime = round(Timer(VertIt), 2) ; %time at that reward occurrence 
    BeforeStim = round((StimTime - 0.1), 2); %1 sec before 
    ItBefore = find(Timer >= BeforeStim);   %iteration of 1 ms before reward 
    ItBefore = ItBefore(1); 
    ItPerMs =  VertIt - ItBefore;   
     

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 20; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan;

 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;
 
 StartSpan=   VertIt- (RevAnalysisLength);
 EndSpan = VertIt+ (FwdAnalysisLength);
  
 SpanLength = EndSpan - StartSpan; 
  
  
%peristimulus and reward lick behavior for all vert 

VertLicksinSpan = zeros(SpanLength, NumVertStim-2); 
VertTimeofSpan = zeros(SpanLength,NumVertStim-2); 
VertSpeedinSpan = zeros(SpanLength,NumVertStim-2); 
VertCorridorColor = zeros(NumVertStim-2, 1); 

AllVertStim = [ShortWindowVert; LongWindowVert]; 
AllVertStim = sort(AllVertStim, 'ascend'); 


for i = 2:NumVertStim-1 %ignore first and last trial 
    
    VertStim = AllVertStim(i); 
        
    StimTime = Timer(VertStim); 
   
    StartSpan=   VertStim- (RevAnalysisLength);
    EndSpan =  VertStim+ (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

    VertLicksinSpan(:, i) = Licks((StartSpan+1):EndSpan);
    VertSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
    VertTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
    
    for y = 1:SpanLength
         VertTimeofSpan(y, i) = VertTimeofSpan(y, i) - StimTime; 
    end 
    
    VertTimeofSpan(:, i) ;
    VertCorridorColor(i, 1) = 1; %green
    
end


VertLicksinSpan = VertLicksinSpan';  
[r c] = size(VertLicksinSpan); 
VertTimeofSpan = VertTimeofSpan';  
VertSpeedinSpan = VertSpeedinSpan';


%PresentTime = 0.8; %seconds 

% %peristimulus and reward lick behavior for diag stim 

 RevAnalysisSpan = 10; %seconds  % 2 iterations = 1 millisecond 
 FwdAnalysisSpan = 20; 
 RewardAnalysisSpan = RevAnalysisSpan + FwdAnalysisSpan; 
 
 NumBlocks = 10; %10 blocks per 1000ms
 IterationsPerSpan = NumBlocks*ItPerMs; 
 RewardAnalysisLength = RewardAnalysisSpan*NumBlocks;
 
 RevAnalysisLength = RevAnalysisSpan*ItPerMs*10; %seconds*milliseconds per* iterations per
 FwdAnalysisLength = FwdAnalysisSpan*ItPerMs*10;

DiagLicksinSpan = zeros(SpanLength, NumDiagStim -2); 
DiagTimeofSpan = zeros(SpanLength, NumDiagStim -2); 
DiagSpeedinSpan = zeros(SpanLength, NumDiagStim -2); 

AllDiagStim = [ShortWindowDiag; LongWindowDiag]; 
AllDiagStim = sort(AllDiagStim, 'ascend'); 

for i = 2:NumDiagStim-1
    
    DiagStim = AllDiagStim(i);
    
    DiagStimTime = Timer(DiagStim); 
   
    StartSpan=  DiagStim- (RevAnalysisLength);
    EndSpan =DiagStim + (FwdAnalysisLength); 
    
    SpanLength = EndSpan - StartSpan;   %span of iterations before and after

         DiagLicksinSpan(:, i) = Licks((StartSpan+1):EndSpan);
         DiagSpeedinSpan(:, i) = Velocity((StartSpan+1):EndSpan);
         DiagTimeofSpan(:, i) = Timer((StartSpan+1):EndSpan);  
         
         for y = 1:SpanLength
            
         DiagTimeofSpan(y, i) = DiagTimeofSpan(y, i) - DiagStimTime; 
         
         end 
    
    DiagTimeofSpan(:, i); 
        
end

DiagLicksinSpan = DiagLicksinSpan';
DiagTimeofSpan = DiagTimeofSpan'; 
DiagSpeedinSpan = DiagSpeedinSpan'; 






CurrentDir = pwd; 
FindStart = findstr(CurrentDir, 'BH'); 
SaveString = CurrentDir(FindStart:end); 
MouseName = CurrentDir(FindStart:FindStart+4);
Date = CurrentDir(FindStart+6:end);

AnalyzedPath = strcat(CodePath, '\', 'Analyzed');
cd(AnalyzedPath); 

if exist(MouseName, 'dir') == 0 
    
    mkdir('Analyzed', MouseName); 
    
end 

MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName); 
DatePath = strcat(MousePath, '\', Date); 

if exist(DatePath, 'dir') == 0 
    
    mkdir(MouseName, Date); 
end 

SavePath = strcat(CodePath, '\', 'Analyzed', '\', SaveString); 
cd(SavePath); 

FindSeshNum = findstr(SavePath, '\'); 
FindSeshNum = FindSeshNum(end); 
SeshNumIt = FindSeshNum + 1; 
SeshNum = strcat('Session', SavePath(SeshNumIt)); 


XLabel = 'Peristimulus Time (s)';
YLabel = 'Trial'; 

Trials = (1:NumVertStim);
VertTrialsOne = figure('name','Vertical Trials Part1'); 
 

for i = 1:round((NumVertStim/2)) 
    
    i;    
    x = VertTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
      
    hold on; 
       
    VertIt = AllVertStim(i);    
    
    WindowLength = find(LongWindowVert == VertIt); 
    
    if isempty(WindowLength) == 0
        
        FullWindow = 0.8; 
          Color = [0 0.75 0]; 
        
    else if isempty(WindowLength) == 1
       
            FullWindow = 0.5;
             Color = [0 0.75 1];
            
        end 
    end 
    
    StimTime = Timer(VertIt); 
    StartWindowTime = 0; 
    EndWindowTime = StimTime + FullWindow; 
    EndWindowIt = find(Timer <= EndWindowTime); 
    EndWindowIt = EndWindowIt(end); 
    %EndWindowTime = Timer(EndWindowIt) - StimTime; 
            
     RZSpan = [StartWindowTime FullWindow]; 
     Ys = [y y]; 
               
     plot(RZSpan, Ys, 'Color', Color , 'LineWidth', 6);   
 
     Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part1'); 
     title(Title); 
     xlabel(XLabel); 
     ylabel(YLabel); 
     
  hold on; 
    
    for a = 1:SpanLength
               
        LickPresent = VertLicksinSpan(i, a);  
        
        if LickPresent == 1
            
            LickTime = VertTimeofSpan(i, a); 
            plot(LickTime, y, 'k.', 'MarkerSize', 10);
            
        end 
    end 
    
    hold on; 
     

       RewardLick = find(Licks(VertIt:EndWindowIt) == 1); 
       
       if isempty(RewardLick) == 0
           
       Reward = RewardLick(1); 
       RewardIt = (VertIt + Reward) - 1; 
       RewardTime = Timer(RewardIt)-StimTime;    
       plot(RewardTime, y, 'r.', 'MarkerSize', 14);
          
       end 
 
end  

FigureSaveName = 'Vert_Trials_Part1.png'; 
saveas(gcf, FigureSaveName); 
close(VertTrialsOne); 




VertTrialTwo = figure('name','Vert Trials Part2'); 
  
 for i = (round(NumVertStim/2)+1): NumVertStim-1
    
     
       
    i;    
    x = VertTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
      
    hold on; 
       
    VertIt = AllVertStim(i);    
    
    WindowLength = find(LongWindowVert == VertIt); 
    
    if isempty(WindowLength) == 0
        
        FullWindow = 0.8; 
          Color = [0 0.75 0]; 
        
    else if isempty(WindowLength) == 1
       
            FullWindow = 0.5;
             Color = [0 0.75 1];
            
        end 
    end 
    
    StimTime = Timer(VertIt); 
    StartWindowTime = 0; 
    EndWindowTime = StimTime + FullWindow; 
    EndWindowIt = find(Timer <= EndWindowTime); 
    EndWindowIt = EndWindowIt(end); 
    %EndWindowTime = Timer(EndWindowIt) - StimTime; 
            
     RZSpan = [StartWindowTime FullWindow]; 
     Ys = [y y]; 
               
     plot(RZSpan, Ys, 'Color', Color , 'LineWidth', 6);   
 
     Title = strcat(MouseName, '-', SeshNum, ':', 'Vertical Trials Part1'); 
     title(Title); 
     xlabel(XLabel); 
     ylabel(YLabel); 
     
  hold on; 
    
    for a = 1:SpanLength
               
        LickPresent = VertLicksinSpan(i, a);  
        
        if LickPresent == 1
            
            LickTime = VertTimeofSpan(i, a); 
            plot(LickTime, y, 'k.', 'MarkerSize', 10);
            
        end 
    end 
    
    hold on; 
     

       RewardLick = find(Licks(VertIt:EndWindowIt) == 1); 
       
       if isempty(RewardLick) == 0
           
       Reward = RewardLick(1); 
       RewardIt = (VertIt + Reward) - 1; 
       RewardTime = Timer(RewardIt)-StimTime;    
       plot(RewardTime, y, 'r.', 'MarkerSize', 14);
          
       end 
 
   
end  


FigureSaveName = 'Vert_Trials_Part2.png'; 
saveas(gcf, FigureSaveName); 
close(VertTrialTwo); 



Trials = (1:NumDiagStim);
YLabel = 'Trial'; 

DiagTrialsOne = figure('name','Diag Trials Part1'); 

for i = 1:round((NumDiagStim/2)) 
    
   
    x = DiagTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
       
    hold on;     
     
    DiagStimIt = AllDiagStim(i);
    WindowLength = find(LongWindowDiag == DiagStimIt); 
       
     if isempty(WindowLength) == 0
        
        FullWindow = 0.8; 
          Color = 'r'; 
        
    else if isempty(WindowLength) == 1
       
            FullWindow = 0.5;
             Color = 'm';
            
        end 
    end 
       
     StimTime = Timer(DiagStimIt); 
    StartWindowTime = 0; 
    EndWindow = StimTime + FullWindow; 
    EndWindowIt = find(Timer >= EndWindow); 
    EndWindowIt = EndWindowIt(1); 
    EndWindowTime = Timer(EndWindowIt) - StimTime; 
            
     DiagStimSpan = [StartWindowTime FullWindow]; 
     Ys = [y y];   
    
    plot(DiagStimSpan, Ys, Color, 'LineWidth', 6);       
    
        for z = 1:SpanLength
        
        LickPresent = DiagLicksinSpan (i, z);  
        
        if LickPresent == 1
            
            LickTime = DiagTimeofSpan(i, z); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
        end  
    
        hold on; 
        
         Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
        title(Title); 
        xlabel(XLabel); 
        ylabel(YLabel);
    
end 

FigureSaveName = 'Diag_Trials_Part1.png'; 
saveas(gcf, FigureSaveName); 
close(DiagTrialsOne); 



DiagTrialsTwo = figure('name','DiagTrials Part2'); 

for i = round((NumDiagStim/2))+1 : NumDiagStim-1 
   
 
    x = DiagTimeofSpan(1, :); 
    y = i; 
    plot(x, y); 
       
    hold on;     
     
    DiagStimIt = AllDiagStim(i);
    WindowLength = find(LongWindowDiag == DiagStimIt); 
       
     if isempty(WindowLength) == 0
        
        FullWindow = 0.8; 
          Color = 'r'; 
        
    else if isempty(WindowLength) == 1
       
            FullWindow = 0.5;
             Color = 'm';
            
        end 
    end 
       
     StimTime = Timer(DiagStimIt); 
    StartWindowTime = 0; 
    EndWindow = StimTime + FullWindow; 
    EndWindowIt = find(Timer >= EndWindow); 
    EndWindowIt = EndWindowIt(1); 
    EndWindowTime = Timer(EndWindowIt) - StimTime; 
            
     DiagStimSpan = [StartWindowTime FullWindow]; 
     Ys = [y y];   
    
    plot(DiagStimSpan, Ys, Color, 'LineWidth', 6);       
    
        for z = 1:SpanLength
        
        LickPresent = DiagLicksinSpan (i, z);  
        
        if LickPresent == 1
            
            LickTime = DiagTimeofSpan(i, z); 
            plot(LickTime, y, 'k.', 'MarkerSize', 8);
            
        end 
        end  
    
        hold on; 
        
         Title = strcat(MouseName, '-', SeshNum, ':', 'Diagonal Trials Part1'); 
        title(Title); 
        xlabel(XLabel); 
        ylabel(YLabel);
    
       
end  

FigureSaveName = 'Diag_Trials_Part2.png'; 
saveas(gcf, FigureSaveName); 
close(DiagTrialsTwo); 





cd(AnalysisPath); 
AccessPath = strcat(AnalysisPath, '\', 'FolderAccessed'); 
savepath AccessPath.txt; 

    
end 



   



