CodePath = 'C:\Users\Feinberg Lab- Matlab\Documents'; 
DataPath = 'D:\Brooke\Data'; 
cd(DataPath); 
        
MiceFiles = dir(DataPath); 
NumMiceFiles = length(MiceFiles);   
PathsToAnalyze = cell.empty; 



for i = 3:NumMiceFiles
    

    %Check if file has been accessed        
   
    cd(DataPath);
    MouseFolder = MiceFiles(i).name; 
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
        
    addpath(MouseFolder); 
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath); 
    NumDateFiles = length(MouseFolderFiles); 
    Dates = zeros((NumDateFiles-2), (NumMiceFiles-2)); 
    
    for x = 3:NumDateFiles 
        
        DateFile =  MouseFolderFiles(x).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile); 
        cd(DateFilePath); 
  
        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt');
       NumStamps = length(AccessStamp); 
       
       if isempty(AccessStamp) == 0 
       
       for z = 1:NumStamps
           
           StampName = AccessStamp(z).name; 
           PrimeStamp = findstr(StampName, 'Prime'); 
       end 
       
       end 
           
        if isempty(AccessStamp) == 1| isempty(PrimeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           

        end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess; 
        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
        
     end 
    
     PathsToAnalyze; 

    end
   
end 
end 

 %check if file has been accessed yet 
for i = 3:NumMiceFiles
    
    cd(DataPath);
    MouseFolder = MiceFiles(i).name;
    BHfile = findstr(MouseFolder, 'BH'); 
    
    if isempty(BHfile) == 0
    
    MouseFolderDataPath = strcat(DataPath, '\', MouseFolder); 
    cd(MouseFolderDataPath); 
    MouseFolderFiles = dir(MouseFolderDataPath);
    NumDateFiles = length(MouseFolderFiles); 
    
    for i = 1:NumDateFiles
    
        DateFile = MouseFolderFiles(i).name; 
        DateFilePath = strcat(MouseFolderDataPath, '\', DateFile);
        cd(DateFilePath);

        PathsToAccess = cell.empty; 
               
       AccessStamp = dir('*.txt'); 
       
       if isempty(AccessStamp) == 0 
           
           StampName = AccessStamp.name; 
           AnalyzeStamp = findstr(StampName, 'Access'); 
       end        
     
     if DateFilePath(end) ~= '.'
           
     if isempty(AccessStamp) == 1 | isempty(AnalyzeStamp) == 1
                   
             PathToAccess = [DateFilePath] ; 
             PathsToAccess = cellstr(PathToAccess);                           
     end 
        
     if isempty(PathsToAnalyze) == 1
        
         PathsToAnalyze = PathsToAccess;        
     else 
        
        PathsToAnalyze = [PathsToAnalyze; PathsToAccess]; 
     end 
    
       end 
    
    end
end 
end 

 PathsToAnalyze; 
 NumPathsToAnalyze = length(PathsToAnalyze); 
 
 for z = 1: NumPathsToAnalyze
     

AnalysisPath = char(PathsToAnalyze(z)) 
cd(AnalysisPath); 

 
NumDataFiles = length(dir('*.dat'));

TotalFrames = zeros(NumDataFiles, 1); 

 AllStims = single.empty(500000, 0); 
 AllRewards = single.empty(500000, 0); 
 AllLicks = single.empty(500000, 0); 
  AllTime = single.empty(500000, 0); 
 AllRZ = single.empty(500000, 0);
  AllDist = single.empty(500000, 0); 
 AllStimSizes = single.empty(500000, 0);
  AllStimSide = single.empty(500000, 0);
AllCueSide = single.empty(500000, 0);
 AllStimMotion = single.empty(500000, 0);
 
   
   AllFiles = dir('*.dat'); 
  StartFile = AllFiles(1).name; 
  FileIt = str2num(StartFile(1)); 
  
  if FileIt == 0 
      
      StartIt = 1; 
      
  else if FileIt == 1
      
      StartIt = 2; 
      
      end 
  end 

for x = StartIt:NumDataFiles
    
    FileIt = num2str(x-1);
    
    Dat = 'Licks&Position.dat'; 
    Encoder = strcat(AnalysisPath, '\', FileIt, Dat);  

movfile = fopen(Encoder);
movpath = dir(Encoder); 
movbytsize = movpath.bytes;

movnu = movbytsize/(10*4+8);

if rem(movnu, 1) == 0 

TotalFrames(x, 1) = movnu; 
%red stamp, PCO it, eye it, elapsed time, eye track, stim & position, movie

fseek(movfile, 10*4 ,'bof');
Timer = zeros(movnu, 1);

for y = 1:movnu

    Time = fread(movfile, 1 , 'double', 0, 'ieee-be'); %
    Timer(y, 1)= Time; 
    fseek(movfile,10*4,'cof');
   
end

Timer = round(Timer, 2);

%read stim info and mouse position:
%Total Dist traveled,  Rand Dist Generated  
%Stim, Lick?, Reward?, Dist at Lick 
%Variant Stims:
%2/1 (Small or Large), 2/1 (Left or Right Stim), 2/1/0 (Left, Right, or No Cue),
%1/2 (Immobile or Mobile Stim -- mouses reference point) 

frewind(movfile);
fseek(movfile, 0 ,'bof');
StimPos = zeros(movnu, 11);  
Zeros = zeros(1, 11); 

for y = 1:movnu
    
    Stiminfo = fread(movfile, 10 ,'single',0,'ieee-be');  
    StimInfo = Stiminfo';
    StimPos(y, 1:10)= StimInfo;
     
    StimPos(y, 11) = y; 
    
    fseek(movfile, 8,'cof'); %places cof at end of next cam data so continue with next wheel frame
    
end 

StimnLick = zeros(movnu, 5); 

StimnLick(:, 1) = StimPos(:, 3); %stim
StimnLick(:, 2) = StimPos(:, 4);%lick
StimnLick(:, 3) = StimPos(:, 5); %reward
StimnLick(:, 4) = Timer(:, 1); 
StimnLick(:, 5) = StimPos(:, 6);
StimnLick(:, 6) = StimPos(:, 1);

Stims = StimnLick(:, 1); 
Licks = StimnLick(:, 2); 
Rewards = StimnLick(:, 3);
Timer = StimnLick(:, 4);
RZDist = StimnLick(:, 5);
Dist= StimnLick(:, 6);
StimSize = StimPos(:, 7); 
StimSide = StimPos(:, 8);
CueSide = StimPos(:, 9);
StimMotion = StimPos(:, 10);


if x == StartIt
    
    AllStims(1:movnu) = Stims;
    AllLicks(1:movnu) = Licks;
    AllReward(1:movnu) = Rewards;
    AllTime(1:movnu) = Timer;
    AllRZ(1:movnu) = RZDist;
    AllDist(1:movnu) = Dist;
    AllStimSizes(1:movnu) = StimSize;
    AllStimSide(1:movnu) = StimSide;
    AllCueSide(1:movnu) = CueSide;
    AllStimMotion(1:movnu) = StimMotion;
    
else if x > StartIt
    
    AllStimLengths = length(AllStims);  
    StartFill = AllStimLengths+1; 
    AllStims(StartFill: (StartFill+movnu) - 1) = Stims; 
    
    AllRewards(StartFill: (StartFill+movnu) - 1) = Rewards;   
    AllLicks(StartFill: (StartFill+movnu) - 1) = Licks;
    AllTime(StartFill: (StartFill+movnu) - 1) = Timer;
    AllRZ(StartFill: (StartFill+movnu) - 1) = RZDist;
    AllDist(StartFill: (StartFill+movnu) - 1) = Dist;
    AllStimSizes(StartFill: (StartFill+movnu) - 1) = StimSize;
    AllStimSide(StartFill: (StartFill+movnu) - 1) = StimSide;
    AllCueSide(StartFill: (StartFill+movnu) - 1) = CueSide;
    AllStimMotion(StartFill: (StartFill+movnu) - 1) = StimMotion;
     
    end
end
%    AllStims; 
%     length(Stims) 
%     length(AllStims)
fclose('all'); 
end

end 

StimLength = AllStimSizes'; 
StimSide = AllStimSide'; 
CueSide = AllCueSide'; 
StimMotion = AllStimMotion'; 
RZDist = round(AllRZ)'; 
Stims = AllStims';
Licks = AllLicks';
Rewards = AllRewards';
Timer = AllTime';
TotalDist = AllDist';
[r c] = size(TotalDist); 


TotalLength = length(Stims); 
Velocity = zeros(TotalLength, 1);

for i = 2:(TotalLength-1) 
    
%instant running speed 

DeltaDist = TotalDist((i+1), 1) - TotalDist((i-1), 1); 
DeltaTime = Timer((i+1), 1)- Timer((i-1), 1); 
Velocity(i, 1) = DeltaDist / DeltaTime; 

end

%find deriv/change in value of licks 

derivLicks = diff(Licks); 
NumDiffLicks = length(derivLicks); 

DerivLicks  = abs(derivLicks); 
DerivLicks = [0; DerivLicks]; 
%Licks = DerivLicks; 


%finds occurences of  vertical stimuli
VertStimNum = find((Stims(:, 1) == 2));   
NumStim = length(VertStimNum); 
StimIts = zeros(NumStim, 1); 

for i = 1:NumStim 
    
    if i == 1 
        StimIts(i, 1) = VertStimNum(i);  

    else
        if VertStimNum(i)-VertStimNum(i-1) < 10
        StimIts(i, 1) = 0; 
    else 
        StimIts(i, 1) = VertStimNum(i);
    end 
    end 
end 

StimIts = nonzeros(StimIts);   
NumVertStim = length(StimIts); 

%separate 800ms present from 500ms present 

VertVariants = zeros(NumVertStim, 1); 
VertDefaults = zeros(NumVertStim, 1);
StimTypes = zeros(NumVertStim, 1);

LongWindowVert = zeros(NumVertStim, 1);
ShortWindowVert = zeros(NumVertStim, 1);

for i = 1:NumVertStim
    
    StimIt = StimIts(i) ; 
    
    WindowType = StimLength(StimIt:StimIt+10); 
    WindowType = mode(WindowType); 
    
    if WindowType == 1 %WindowLength = 800ms
        
        LongWindowVert(i, 1) = StimIt; 
        
    else if WindowType == 2 %WindowLength = 500 ms
            
            ShortWindowVert(i, 1) = StimIt;
            
        end 
    end
    

end 

LongWindowVert = nonzeros(LongWindowVert); 
ShortWindowVert = nonzeros(ShortWindowVert); 

NumLongVert = length(LongWindowVert)
NumShortVert = length(ShortWindowVert)

%Lick analysis for vert 

LongVertHits = zeros(NumLongVert); 

for i = 1:NumLongVert 
    i; 
    VertIt = LongWindowVert(i); 
    StimTime = Timer(VertIt); 
    EndWindow = StimTime + 0.8; 
    EndWindowIt = find(Timer <= EndWindow); 
    EndWindowIt = EndWindowIt(end);   
    
    Licked = find(Licks(VertIt:EndWindowIt) == 1);
    
    if isempty(Licked) == 0
        
        LongVertHits(i, 1) = VertIt; 
        
    end 
    
end 

 LongVertHits = nonzeros(LongVertHits); 
 NumLongVHits = length(LongVertHits); 
 
 
 ShortVertHits = zeros(NumShortVert); 

for i = 1:NumShortVert 
    
    VertIt = ShortWindowVert(i); 
    StimTime = Timer(VertIt); 
    EndWindow = StimTime + 0.5; 
   EndWindowIt = find(Timer <= EndWindow); 
    EndWindowIt = EndWindowIt(end); 
    
    Licked = find(Licks(VertIt:EndWindowIt) == 1);
    
    if isempty(Licked) == 0
        
        ShortVertHits(i, 1) = VertIt; 
        
    end 
    
end 

 ShortVertHits = nonzeros(ShortVertHits);
 NumShortVHits = length(ShortVertHits); 
 
 
 

%finds occurences of  diagonal stimuli
DiagStimNum = find((Stims(:, 1) == 1));   
NumDiagStim = length(DiagStimNum); 
DiagStimIts = zeros(NumDiagStim, 1); 

for i = 1:NumDiagStim 
    
    if i == 1 
        DiagStimIts(i, 1) = DiagStimNum(i);  

    else
        if DiagStimNum(i)-DiagStimNum(i-1) < 10
        DiagStimIts(i, 1) = 0; 
    else 
        DiagStimIts(i, 1) = DiagStimNum(i);
    end 
    end 
end 

AllDiagStim = nonzeros(DiagStimIts);
NumDiagStim = length(AllDiagStim) 



LongWindowDiag = zeros(NumDiagStim, 1); 
ShortWindowDiag = zeros(NumDiagStim, 1);

for i = 1:NumDiagStim 
    
    DiagStim = AllDiagStim(i); 
    FindStimType = StimLength(DiagStim:DiagStim+10);  
    FindStimType = mode(FindStimType);      
    
    if FindStimType == 2 %500ms
        
        ShortWindowDiag(i, 1) = DiagStim; 
        
    else if FindStimType == 1 %800ms
        
       LongWindowDiag(i, 1) = DiagStim; 
        
        end 
    end
end 

ShortWindowDiag = nonzeros(ShortWindowDiag); 
LongWindowDiag = nonzeros(LongWindowDiag); 

NumShortDiag = length(ShortWindowDiag) 
NumLongDiag = length(LongWindowDiag) 


%lick analysis for diag stim 
ShortDiagFAs = zeros(NumShortDiag); 

for i = 1:NumShortDiag 
    
    DiagIt = ShortWindowDiag(i); 
    StimTime = Timer(DiagIt); 
    EndWindow = StimTime + 0.5; 
    EndWindowIt = find(Timer <= EndWindow); 
    EndWindowIt = EndWindowIt(end); 
    
    Licked = find(Licks(DiagIt:EndWindowIt) == 1);
    
    if isempty(Licked) == 0
        
        ShortDiagFAs(i, 1) = DiagIt; 
        
    end 
    
end 

 ShortDiagFAs = nonzeros(ShortDiagFAs);
 NumShortDFAs = length(ShortDiagFAs); 

 
 LongDiagFAs = zeros(NumLongDiag); 

for i = 1:NumLongDiag 
    
    DiagIt = LongWindowDiag(i); 
    StimTime = Timer(DiagIt); 
    EndWindow = StimTime + 0.5; 
    EndWindowIt = find(Timer <= EndWindow); 
    EndWindowIt = EndWindowIt(end); 
    
    Licked = find(Licks(DiagIt:EndWindowIt) == 1);
    
    if isempty(Licked) == 0
        
        LongDiagFAs(i, 1) = DiagIt; 
        
    end 
    
end 

 LongDiagFAs = nonzeros(LongDiagFAs);
 NumLongDFAs = length(LongDiagFAs);
 
 



%calc behavioral d-prime for short windows
 
ShortFAFrac = NumShortDFAs/NumShortDiag;  
ShortHitFrac = NumShortVHits/NumShortVert;  


if ShortFAFrac == 0
    ShortFAFrac = 0.01
end
if ShortFAFrac == 1
    ShortFAFrac = 0.99
end



if ShortHitFrac == 0
    ShortHitFrac = 0.01
end
if ShortHitFrac == 1
    ShortHitFrac = 0.99
end


ShortHitNormInv = norminv(ShortHitFrac,0,1)
ShortFANormInv = norminv(ShortFAFrac,0,1)

ShortDPrime = ShortHitNormInv - ShortFANormInv




%calc behavioral d-prime for variants

LongHitFrac = NumLongVHits/NumLongVert;
LongFAFrac = NumLongDFAs/NumLongDiag;

if LongFAFrac == 0
    LongFAFrac = 0.01
end
if LongFAFrac == 1
    LongFAFrac = 0.99
end


if LongHitFrac == 0
    LongHitFrac = 0.01
end
if LongHitFrac == 1
    LongHitFrac = 0.99
end

LongHitNormInv = norminv(LongHitFrac,0,1)
LongFANormInv = norminv(LongFAFrac,0,1)


LongDPrime = LongHitNormInv - LongFANormInv



%Calc d prime for all trials


TotalTrials = NumDiagStim + NumVertStim; 
TotalHitFrac = (NumLongVHits + NumShortVHits)/NumVertStim; 
TotalFAFrac = (NumLongDFAs + NumShortDFAs)/NumDiagStim; 


if TotalFAFrac == 0
    TotalFAFrac = 0.01
end
if TotalFAFrac == 1
    TotalFAFrac = 0.99
end


if TotalHitFrac == 0
    TotalHitFrac = 0.01
end
if TotalHitFrac == 1
    TotalHitFrac = 0.99
end

TotalHitNormInv = norminv(TotalHitFrac,0,1)
TotalFANormInv = norminv(TotalFAFrac,0,1)


TotalDPrime = TotalHitNormInv - TotalFANormInv



%save data for mouse on consecutive days 

FindStart = findstr(AnalysisPath, 'BH'); 
Date = AnalysisPath(FindStart+6:end);  
MouseName = AnalysisPath(FindStart:FindStart+4);
SaveString = AnalysisPath(FindStart:end); 
MousePath = strcat(CodePath, '\', 'Analyzed', '\', MouseName);  

DefaultFAStr = num2str(DefaultFAFrac); 
DefaultHitStr = num2str(DefaultHitFrac); 

VariantFAStr = num2str(VariantFAFrac); 
VariantHitStr = num2str(VariantHitFrac); 

TotalFAStr = num2str(TotalFAFrac); 
TotalHitStr = num2str(TotalHitFrac); 

cd(MousePath); 
fileID = fopen('AllDPrime.txt','a');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',TotalTrials, '-append');
dlmwrite('AllDPrime.txt',LongHitFrac, '-append');
dlmwrite('AllDPrime.txt',LongFAFrac,'-append');
dlmwrite('AllDPrime.txt',LongDPrime,'-append');
dlmwrite('AllDPrime.txt',ShortHitFrac, '-append');
dlmwrite('AllDPrime.txt',ShortFAFrac,'-append');
dlmwrite('AllDPrime.txt',ShortDPrime,'-append');
dlmwrite('AllDPrime.txt',TotalHitFrac, '-append');
dlmwrite('AllDPrime.txt',TotalFAFrac,'-append');
dlmwrite('AllDPrime.txt',TotalDPrime,'-append');
fclose(fileID);

cd(AnalysisPath); 
fileID = fopen('AllDPrime.txt','w');
formatSpec = '%s\n';
fprintf(fileID, formatSpec , Date);
dlmwrite('AllDPrime.txt',TotalTrials, '-append');
dlmwrite('AllDPrime.txt',LongHitFrac, '-append');
dlmwrite('AllDPrime.txt',LongFAFrac,'-append');
dlmwrite('AllDPrime.txt',LongDPrime,'-append');
dlmwrite('AllDPrime.txt',ShortHitFrac, '-append');
dlmwrite('AllDPrime.txt',ShortFAFrac,'-append');
dlmwrite('AllDPrime.txt',ShortDPrime,'-append');
dlmwrite('AllDPrime.txt',TotalHitFrac, '-append');
dlmwrite('AllDPrime.txt',TotalFAFrac,'-append');
dlmwrite('AllDPrime.txt',TotalDPrime,'-append');
fclose(fileID);

 end 
 
 
 %open cummulative data files for analysis 

cd(CodePath);
AnalyzedPath = strcat(CodePath, '\', 'Analyzed'); 
MiceAnalysisFolders = dir(AnalyzedPath); 
NumMiceAnalyFiles = length(MiceAnalysisFolders);

OverlayedDPrimes = figure('name', 'All DPrimes');
TrueNegFracs = zeros(10, (NumMiceAnalyFiles-3));
b = 0; 

for i = 3:NumMiceAnalyFiles
    
    MouseAnalyFolder = MiceAnalysisFolders(i).name;
    BHFile = findstr(MouseAnalyFolder, 'BH'); 
    
    if isempty(BHFile) == 0
        
        b = b+1; 
        if b == 1           
            FoldersToAnalyze = MouseAnalyFolder;             
        else  
            FoldersToAnalyze = [FoldersToAnalyze; MouseAnalyFolder]; 
        end
        
    end 
    
end 

NumAnalyFolders = length(FoldersToAnalyze);

AllDefaultDPrimes = zeros(10, (NumAnalyFolders)); 
AllVariantDPrimes = zeros(10, (NumAnalyFolders)); 

AllTotalDPrimes = zeros(10, (NumAnalyFolders)); 
AllTotalTrials = zeros(10, (NumAnalyFolders));
AllTotalFAFrac = zeros(10, (NumAnalyFolders));
AllTotalHitFrac = zeros(10, (NumAnalyFolders));

Dates = zeros(10, (NumAnalyFolders)); 
 
MouseNames = cell(NumAnalyFolders, 1);

for i = 1:NumAnalyFolders

    MouseAnalyFolder = FoldersToAnalyze(i, :); 
    MouseFolderAnalyPath = strcat(AnalyzedPath, '\', MouseAnalyFolder); 
    cd(MouseFolderAnalyPath); 
    DPrimeFileCreated = dir('*.txt'); 
    FoldersPresent = dir(MouseFolderAnalyPath);  
    NumFolders = length(FoldersPresent);  
    NumDateFolders = zeros(NumFolders, 1); 
     
     if i == 1
        
        MouseNames  = cellstr(MouseAnalyFolder); 
        
    else 
        
        MouseName = cellstr(MouseAnalyFolder); 
        MouseNames = [MouseNames MouseName]; 
        
    end
   
    for x = 3:NumFolders
        
        FolderName =  FoldersPresent(x).name;  
        AMFolders = length(findstr(FolderName, 'AM'));  
        PMFolders = length(findstr(FolderName, 'PM'));
        
        NumDateFolders(x, 1) = AMFolders + PMFolders; 
        
    end 
    
    NumDateFolders = sum(NumDateFolders); 
    
    if isempty(DPrimeFileCreated) == 0
        
        fileID = fopen('AllDPrime.txt','r');
        FirstChars = zeros(NumDateFolders*11, 1);
        DPrimeDates = cell(NumDateFolders, 1); 
        DPrimeData = zeros(NumDateFolders*11, 1);
        a = 0; 
        
        for x = 1:(NumDateFolders*11)
            
        x;  
        LineRead = fgetl(fileID); 
        LineLength = length(LineRead);
        
        if LineLength > 11
            
            a = a + 1; 
            FirstChars(x, 1) = str2num(LineRead(1)); 
            LineRead = cellstr(LineRead); 
            DPrimeDates(a, 1) = LineRead; 
        
        else
            
            LineRead = char(LineRead(1, :)); 
            NumRead = str2num(LineRead);
            if NumRead == 0 
                
                NumRead = 0.01; 
                
            end 
            DPrimeData(x, 1) = NumRead; 
            
        end 
            
        end 
        
        DPrimeDates ; 
        
        DPrimeData = nonzeros(DPrimeData); 
        DPrimeData = reshape(DPrimeData, 10, []);                            
        
    end
    
    NumPrimeDates = length(DPrimeDates);
   
    
%sort files in order of date 
        
    for x = 1:NumPrimeDates 
        
        x; 
     PrimeDate = DPrimeDates(x, :); 
     PrimeDate = char(PrimeDate); 
     PrimeDate = strcat(PrimeDate); 
    FirstComma = findstr(PrimeDate, ','); 
    StartDateString = FirstComma(1) + 2; 
    
    FindEnd = findstr(PrimeDate, 'PM');
    
    if isempty(FindEnd) == 1
         FindEnd = findstr(PrimeDate, 'AM');
    end 
    
    EndDateString = FindEnd-5; 
    DateString = PrimeDate(StartDateString:EndDateString); 
    
    Minutes= DateString(end-1:end); 
    Hour = DateString(end-3:end-2); 
    
    if Hour(1) == ' ' 
        
        Hour(1) = '0'; 
        DayYr = DateString(end-11:end-4);
        
    else 
        DayYr = DateString(end-12:end-5);
        
    end 
    
    Time = strcat(Hour, ':', Minutes); 
    Month = DateString(1:3); 
    DayYr = strcat(DayYr(1:3), DayYr(5:end)); 
    Date = strcat(Month, '.', DayYr); 
    Date = [Date, ' ', Time];
    format = 'mmm.dd,yyyy HH:MM'; 
    DateNum = datenum(Date);
    DateNumString = num2str(DateNum); 
    
    Dates(x, i) = DateNum; 
    
     
    end
    
    
    FirstChars = nonzeros(FirstChars);
    NumFirstChars = length(FirstChars);     
    
    Trials = DPrimeData(1, :);
    Trials = Trials';
    
    DefaultHitFracs = DPrimeData(2, :); 
    DefaultHitFracs = DefaultHitFracs'; 
    
    DefaultFAFracs = DPrimeData(3, :); 
    DefaultFAFracs = DefaultFAFracs' ;
    
    VariantHitFracs = DPrimeData(5, :); 
    VariantHitFracs = VariantHitFracs'; 
    
    VariantFAFracs = DPrimeData(6, :); 
    VariantFAFracs = VariantFAFracs' ;
    
    TotalHitFracs = DPrimeData(8, :); 
    TotalHitFracs = TotalHitFracs'; 
    
    TotalFAFracs = DPrimeData(9, :); 
    TotalFAFracs = TotalFAFracs' ;
    
        
    DefaultDPrimes = DPrimeData(4, :); 
    DefaultDPrimes =  DefaultDPrimes';
    
    VariantDPrimes = DPrimeData(7, :); 
    VariantDPrimes =  VariantDPrimes';
       
    TotalDPrimes = DPrimeData(10, :); 
    TotalDPrimes =  TotalDPrimes';
    


    
    for x = 2:NumFirstChars 
        
        
        SameDay = FirstChars(x,1) - FirstChars((x-1),1); 
       
       if SameDay == 0 
           
           AvgFAFrac = mean([TotalFAFracs(x-1) TotalFAFracs(x)]); 
           AvgHitFrac = mean([HitFracs(x-1) HitFracs(x)]); 
           
           AvgFANorm = norminv(AvgFAFrac); 
           AvgHitNorm = norminv(AvgHitFrac);
           
           AvgDPrime = AvgHitNorm-AvgFANorm; 
           
           TotalDPrimes(x) = AvgDPrime; 
           TotalDPrimes(x-1) = 0; 
           
           AvgTrials = mean([Trials(x-1) Trials(x)]);  
           
           Trials(x) = AvgTrials; 
           Trials(x-1) = 0; 
           
           HitFracs(x) = AvgHitFrac; 
           HitFracs(x-1) = 0; 
           
           TotalFAFracs(x) = AvgFAFrac; 
           TotalFAFracs(x-1) = 0; 
           
           Dates((x-1), i) = 0; 
           
       end 
    end
    
    
    
    Trials = nonzeros(Trials); 
    NumTrials = length(Trials); 
    AllTrials(1:NumTrials, i) = Trials; 
    
    DefaultDPrimes = nonzeros(DefaultDPrimes); 
    NumDefaultPrimes = length(DefaultDPrimes);
    AllDefaultDPrimes(1:NumDefaultPrimes, i) = DefaultDPrimes; 
    
    VariantDPrimes = nonzeros(VariantDPrimes); 
    NumVariantPrimes = length(VariantDPrimes);
    AllVariantDPrimes(1:NumDefaultPrimes, i) = VariantDPrimes; 

    TotalDPrimes = nonzeros(TotalDPrimes); 
    NumTotalPrimes = length(TotalDPrimes);
    AllTotalDPrimes(1:NumTotalPrimes, i) = TotalDPrimes; 
    

    
    %plot total d primes 
    
    if NumTotalPrimes == 1
        
      plot(TotalDPrimes, 'o');  
    
    else if i < 8
    
    plot(TotalDPrimes,  'LineWidth', 2); 
   
    else 
    plot(TotalDPrimes, '--',  'LineWidth', 2); 
        
        end 
    end 

    hold on; 
    
   legend(MouseNames, 'Location', 'southeast'); 
     
    NumTotalPrimes = length(TotalDPrimes);    

    end 


% cd(AnalyzedPath); 
% FigureSaveName = 'Behavioral_DPrimes_as_of_7/20.png'; 
% FigureSave = strcat(pwd, '\', FigureSaveName); 
% saveas(gcf, FigureSaveName); 
% %close(VertTrialsOne); 


NumMiceFolders = 0; 

for i = 1:NumMiceAnalyFiles
    
    FolderName = MiceAnalysisFolders(i).name;
    BHFolder = findstr(FolderName, 'BH'); 
    
    if isempty(BHFolder) == 0
        
       NumMiceFolders = NumMiceFolders +1; 
       
    end 
    
end 

NumMiceFolders; 

AllIndivDPrimes = figure('name', 'All Indiv DPrimes Variants'); 

for i = 1:(NumMiceFolders)

    subplot(2, 3, i); 
    
    IndivDefaultPrimes = AllDefaultDPrimes(:, i); 
    IndivDefaultPrimes = nonzeros(IndivDefaultPrimes); 
     
    IndivVariantPrimes = AllVariantDPrimes(:, i); 
    IndivVariantPrimes = nonzeros(IndivVariantPrimes); 
         
    IndivTotalPrimes = AllTotalDPrimes(:, i); 
    IndivTotalPrimes = nonzeros(IndivTotalPrimes); 
    
    MouseDates = nonzeros(Dates(:, i)); 
    NumDays = length(MouseDates) ; 
    RelativeDays = zeros(NumDays, 1); 
    
    for x = 1:NumDays
    
    RelativeDayNum = MouseDates(x, 1) - MouseDates(1, 1); 
    RelativeDays(x, 1) =  RelativeDayNum; 
    
    end 
           
    MouseName = MouseNames(1, i); 
    
    plot(RelativeDays,  IndivDefaultPrimes, '-o', RelativeDays,  IndivVariantPrimes, '-o', RelativeDays,  IndivTotalPrimes, '-o');
    title(MouseName); 
    hold on;  
 
   if i == 2
       
      legend('Default DPrime', 'Variant DPrime', 'Total DPrime', 'Location','northoutside', 'Orientation','horizontal'); 
       
   end 
    
end 
